﻿using System;
using System.Windows.Forms;

using System.Diagnostics;
using System.IO;
using GHelper;
using ds30Loader;

namespace Simple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDownload_Click(object sender, EventArgs e)
        {

            this.Cursor = Cursors.WaitCursor;

            //---------------------------------------------------------------------	
            // Base path
            //---------------------------------------------------------------------	
            string strBasePath = Path.GetDirectoryName( Process.GetCurrentProcess().MainModule.FileName );
            if ( strBasePath.EndsWith(Path.DirectorySeparatorChar.ToString()) == false ) {
                strBasePath += Path.DirectorySeparatorChar;
            }


            //---------------------------------------------------------------------	
			// Init ports
            //---------------------------------------------------------------------	
            clsds30LoaderPorts.Init( strBasePath, 0 );


            //---------------------------------------------------------------------	
            // Init device database
            //---------------------------------------------------------------------	
            clsDeviceDb.ImportDeviceDB( strBasePath + "devices.xml" );


            //---------------------------------------------------------------------	
            // Get device object
            //---------------------------------------------------------------------	
            clsDevice objDevice = clsDeviceDb.DeviceGet( "PIC18F2550" );

            if ( objDevice == null ) {
                MessageBox.Show( "Unknown device, download aborted.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                this.Cursor = Cursors.Default;
                return;
            }


            //---------------------------------------------------------------------	
            // Parse hex file
            //---------------------------------------------------------------------	
            clsHex18F objHex = new clsHex18F( "serlcd.hex" );	           
            {
                bool bParseResult = false;
                clsParseSettings objParseSettings = new clsParseSettings();                

                objParseSettings.device = objDevice;            
                objHex.ParseHexFile( objParseSettings, false, 0, ref bParseResult );

                if ( bParseResult == false ) {
                    MessageBox.Show( "Parse of hex file failed, download aborted.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                    this.Cursor = Cursors.Default;
                    return;
                }
            }

            
            //---------------------------------------------------------------------	
            // Download
            //---------------------------------------------------------------------	
            {
                bool bDownloadResult = false;
                clsDownloadSettings objDownloadSettings = new clsDownloadSettings();

                objDownloadSettings.portName = "COM5";
                objDownloadSettings.writeProgram = true;
                objDownloadSettings.baudRate = 115200;

                clsds30Loader.Download( objDevice, objHex, objDownloadSettings, 0, ref bDownloadResult );

                if ( bDownloadResult == false ) {
                    MessageBox.Show( "Download failed", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                    this.Cursor = Cursors.Default;
                    return;
                } else {
                    MessageBox.Show( "Download completed successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                }
            }
            
            this.Cursor = Cursors.Default;
        }
    }
}
