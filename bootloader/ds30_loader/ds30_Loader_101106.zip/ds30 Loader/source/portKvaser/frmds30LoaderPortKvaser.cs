﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using canlibCLSNET;

namespace ds30Loader
{
    public partial class frmds30LoaderPortKvaser : Form
    {
        //---------------------------------------------------------------------
        // Variables
        //---------------------------------------------------------------------	
        private clsds30LoaderPortKvaser objParentPort = null;

        public frmds30LoaderPortKvaser(clsds30LoaderPortKvaser pobjParentPort)
        {
            InitializeComponent();

            objParentPort = pobjParentPort;

            lblVersion.Text = clsds30LoaderPortKvaser.strVersion;
            lblManufacturer.Text = "Kvaser AB";
            short sVersion = Canlib.canGetVersion();
            lblDrvVersion.Text = ((sVersion & 0xF00) >> 8).ToString() + "." + ((sVersion & 0xF0) >> 4).ToString() + (sVersion & 0xF).ToString();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            // Close window
            this.Close();
        }

        private void frmds30LoaderPortIxxat_Load(object sender, EventArgs e)
        {

        }
    }
}
