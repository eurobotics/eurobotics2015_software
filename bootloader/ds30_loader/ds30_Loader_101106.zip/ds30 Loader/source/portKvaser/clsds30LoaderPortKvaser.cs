﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader
//
// Copyright:		Copyright © 2010, Mikael Gustafsson
//
// Developed by:    Fabien Pieraldi
//
// Version:			0.9.1 october 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			0.9.1 Bugfix: ReadText() fixed
//                  0.9.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 

using System;
using System.Collections;
using System.Threading;
using System.IO;

using canlibCLSNET;

using GHelper;
using ds30Loader;

namespace ds30Loader
{

    //-------------------------------------------------------------------------
    // Class: clsds30LoaderPortKvaser
    //-------------------------------------------------------------------------
    public class clsds30LoaderPortKvaser : clsPortBase, IPort, IPortCAN
    {
        //---------------------------------------------------------------------
        // Variables
        //---------------------------------------------------------------------	
        private int iBaudRate = 0;
        private string strPortName = string.Empty;
        private Boolean bIsOpen = false;
        private Hashtable htPortNames = null;             //channel name as key, index as value
        private bool bValidPortName = false;
        private int iOutBufferCount = 0;

        private int iHandle;
        private int iDeviceID;

        private static Mutex mut;

        //   Thread that handles the message reception.
        private Thread trdRx = null;

        private Queue queRx = null;

        public event clsPortBase.DataReceivedDelegate DataReceived;

        private const string strAppName = "ds30Loader";
        static public string strVersion = "0.9.1";

        //---------------------------------------------------------------------
        // Constructor()
        //---------------------------------------------------------------------	
        public clsds30LoaderPortKvaser()
        {
            Init();
            clsKvaserBitRates.Init();
        }// Constructor()


        //---------------------------------------------------------------------
        // Constructor()
        //---------------------------------------------------------------------	
        public clsds30LoaderPortKvaser(string pstrPortname, int piBaudrate)
        {
            Init();
            Setup(pstrPortname, piBaudrate);
        }// Constructor()


        //---------------------------------------------------------------------
        // Destructor()
        //---------------------------------------------------------------------	
        ~clsds30LoaderPortKvaser()
        {
            Close();
        }// Destructor()


        //---------------------------------------------------------------------
        // Event: DataReceived
        //---------------------------------------------------------------------
        protected internal void OnDataReceived()
        {
            // ChangedEvent will be null if no client has hooked up a delegate to the event.
            if (DataReceived != null)
            {
                DataReceived(this, null);
            }
        }//Event: ChangesMade	


        //---------------------------------------------------------------------
        // Property: allowCustomBaudRate
        //---------------------------------------------------------------------
        public bool allowCustomBaudRate
        {
            get
            {
                return false;
            }
            set
            {
            }
        }//Property: allowCustomBaudRate 	 



        //---------------------------------------------------------------------
        // Property: baudrate
        //---------------------------------------------------------------------
        public int baudrate
        {
            get
            {
                return iBaudRate;
            }
            set
            {
                if (isOpen == true)
                {
                    throw new Exception("Port is open\n");
                }
                iBaudRate = value;
            }
        }//Property: baudrate 	 


        //---------------------------------------------------------------------
        // Property: debugMode
        //---------------------------------------------------------------------
        public bool debugMode { get; set; }


        //---------------------------------------------------------------------
        // Property: dtrEnable
        //---------------------------------------------------------------------
        public bool dtrEnable { get; set; }


        //---------------------------------------------------------------------
        // Property: echoVerification
        //---------------------------------------------------------------------
        public bool echoVerification { get; set; }


        //---------------------------------------------------------------------
        // Property: hasWindow
        //---------------------------------------------------------------------
        public bool hasWindow
        {
            get
            {
                return true;
            }
        }//Property: hasWindow


        //---------------------------------------------------------------------
        // Property: inBufferCount
        //---------------------------------------------------------------------
        public int inBufferCount
        {
            get
            {
                return queRx.Count;
            }
        }//Property: inBufferCount       		


        //---------------------------------------------------------------------
        // Property: isOpen
        //---------------------------------------------------------------------
        public bool isOpen
        {
            get
            {
                return bIsOpen;
            }
        }//Property: isOpen  


        //---------------------------------------------------------------------
        // Property: localID
        //---------------------------------------------------------------------
        public uint localID { get; set; }


        //---------------------------------------------------------------------
        // Property: outBufferCount
        //---------------------------------------------------------------------
        public int outBufferCount
        {
            get
            {
                return iOutBufferCount;
            }
        }//Property: outBufferCount  


        //---------------------------------------------------------------------
        // Property: portName
        //---------------------------------------------------------------------
        public string portName
        {
            get
            {
                return strPortName;
            }
            set
            {
                if (isOpen == true)
                {
                    throw new Exception("Port is open\n");
                }
                string strPortName = value;

                if (htPortNames.Contains(strPortName) == false)
                {
                    bValidPortName = false;
                    return;
                }

                iDeviceID = (int)htPortNames[strPortName];

                if (debugMode)
                {
                    clsDebugTextbox.OutputInfo("Port name set to " + value, 0);
                }
                this.strPortName = value;
                bValidPortName = true;
            }
        }//Property: portName        


        //---------------------------------------------------------------------
        // Property: portType
        //---------------------------------------------------------------------
        public PortType portType
        {
            get
            {
                return PortType.CAN;
            }
        }// Property: portType 


        //---------------------------------------------------------------------
        // Property: remoteID
        //---------------------------------------------------------------------
        public uint remoteID { get; set; }


        //---------------------------------------------------------------------
        // Property: rtsEnable
        //---------------------------------------------------------------------
        public bool rtsEnable { get; set; }
  

		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		new public static bool supportsWindows{ get {return true;} }
  

		//---------------------------------------------------------------------
		// Property: supportsLinux
		//---------------------------------------------------------------------
		new public static bool supportsLinux{ get {return false;} }
  

		//---------------------------------------------------------------------
		// Property: supportsMac
		//---------------------------------------------------------------------
		new public static bool supportsMac{ get {return false;} }
	        
   
		//---------------------------------------------------------------------
		// Property: version
		//---------------------------------------------------------------------
		public string version
		{
			get {
				return strVersion;
			}	
        }//Property: version 


        //---------------------------------------------------------------------
        // Close()
        //---------------------------------------------------------------------	
        public bool Close()
        {
            if (isOpen == false)
            {
                return !bIsOpen;
            }

            Canlib.canBusOff(iHandle);
            Canlib.canClose(iHandle);
            bIsOpen = false;

            // Stop RX thread
            trdRx.Abort();
            trdRx = null;

            mut.Close();
            mut = null;

            Canlib.canUnloadLibrary();

            queRx.Clear();

            return !bIsOpen;
        }// Close()


        //---------------------------------------------------------------------
        // EmptyBuffers()
        //---------------------------------------------------------------------	
        public void EmptyBuffers(bool bRx, bool bTx)
        {
        }// EmptyBuffers()


        //---------------------------------------------------------------------
        // GetBaudRates()
        // Description: enumerates available baud rates
        //---------------------------------------------------------------------	
        public ArrayList GetBaudRates()
        {
            return clsKvaserBitRates.lstBitRates;
        }// GetBaudRates()


        //---------------------------------------------------------------------
        // Init()
        //---------------------------------------------------------------------
        private bool Init()
        {
            ResetCounters();
            htPortNames = new Hashtable(11);
            queRx = new Queue(11);
            debugMode = false;
            object DevDescr;
            object CardNo;
            object ChannelNo;
            int NumberOfChannel;
            string strCanError;

            Canlib.canInitializeLibrary();
            Thread.Sleep(50);

            Canlib.canStatus iCanResult = Canlib.canGetNumberOfChannels(out NumberOfChannel);
            if (iCanResult == Canlib.canStatus.canOK)
            {
                for (int iIter = 0; iIter < NumberOfChannel; iIter++)
                {
                    Canlib.canGetChannelData(iIter, Canlib.canCHANNELDATA_DEVDESCR_ASCII, out DevDescr);
                    Canlib.canGetChannelData(iIter, Canlib.canCHANNELDATA_CARD_NUMBER, out CardNo);
                    Canlib.canGetChannelData(iIter, Canlib.canCHANNELDATA_CHAN_NO_ON_CARD, out ChannelNo);
                    strPortName = (DevDescr.ToString() + " " + CardNo.ToString() + " Channel " + ChannelNo.ToString()).Trim(new char[] { '\0' });
                    htPortNames.Add(strPortName, iIter);
                }
            }
            else
            {
                Canlib.canGetErrorText(iCanResult, out strCanError);
                clsDebugTextbox.OutputError("Init() = " + strCanError, 0);
                return false;
            }

            return true;
        }// Init()


        //---------------------------------------------------------------------
        // EchoClearQueue()
        //---------------------------------------------------------------------	
        public void EchoClearQueue()
        {
        }// EchoRead()		


        //---------------------------------------------------------------------
        // Open()
        //---------------------------------------------------------------------	
        public bool Open()
        {
            Canlib.canStatus iCanResult;
            string strCanError;

            if (isOpen == true || bValidPortName == false)
            {
                return bIsOpen;
            }

            Canlib.canInitializeLibrary();
            Thread.Sleep(50);

            iHandle = Canlib.canOpenChannel(iDeviceID, Canlib.canOPEN_ACCEPT_VIRTUAL);
            if (iHandle < 0)
            {
                clsDebugTextbox.OutputError("Init access not granted.", 0);
                return false;
            }

            clsKvaserBitRate objBitRate = clsKvaserBitRates.GetBitRate(baudrate);

            iCanResult = Canlib.canSetBusParamsC200(iHandle, objBitRate.Btr0, objBitRate.Btr1);
            if (iCanResult != Canlib.canStatus.canOK)
            {
                Canlib.canGetErrorText(iCanResult, out strCanError);
                clsDebugTextbox.OutputError("Open() = " + strCanError, 0);
                return false;
            }

            iCanResult = Canlib.canSetAcceptanceFilter(iHandle, (int)localID, (int)0x7FF, 0);
            if (iCanResult != Canlib.canStatus.canOK)
            {
                Canlib.canGetErrorText(iCanResult, out strCanError);
                clsDebugTextbox.OutputError("Open() = " + strCanError, 0);
                return false;
            }

            iCanResult = Canlib.canBusOn(iHandle);
            if (iCanResult != Canlib.canStatus.canOK)
            {
                Canlib.canGetErrorText(iCanResult, out strCanError);
                clsDebugTextbox.OutputError("Open() = " + strCanError, 0);
                return false;
            }

            mut = new Mutex(false);

            bIsOpen = true;

            // Start the receive thread
            trdRx = new Thread(new ThreadStart(RXThread));
            trdRx.Start();

            Thread.Sleep(50);

            //
            return (bIsOpen);
        }// Open()	


        //---------------------------------------------------------------------
        // OpenWindow()
        //---------------------------------------------------------------------	
        public void OpenWindow(System.Windows.Forms.Form pwndOwner)
        {
            frmds30LoaderPortKvaser wndSettings = new frmds30LoaderPortKvaser(this);
            wndSettings.ShowDialog(pwndOwner);
        }// OpenWindow()

        //---------------------------------------------------------------------
        // ReadByte()
        //---------------------------------------------------------------------	
        public bool ReadByte(ref int iByte)
        {
            if (inBufferCount < 1) return false;
            iByte = (byte)queRx.Dequeue();
            ++iBytesReceived;
            return true;
        }// ReadByte()	


        //---------------------------------------------------------------------
        // ReadBytes()
        //---------------------------------------------------------------------	
        public bool ReadBytes(ref byte[] iBytes, int iCount)
        {
            if (inBufferCount < iCount) return false;

            for (int iIter = 0; iIter < iCount; iIter++)
            {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
        }// ReadBytes()


        //---------------------------------------------------------------------
        // ReadBytes()
        //---------------------------------------------------------------------	
        public bool ReadBytes(ref int[] iBytes, int iCount)
        {
            if (inBufferCount < iCount) return false;

            for (int iIter = 0; iIter < iCount; iIter++)
            {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
        }// ReadBytes()


        //---------------------------------------------------------------------
        // ReadInt16()
        //---------------------------------------------------------------------	
        public bool ReadInt16(ref int iInteger)
        {
            if (inBufferCount < 2) return false;
            iInteger = (byte)queRx.Dequeue() + (((byte)queRx.Dequeue()) << 8);
            iBytesReceived += 2;
            return true;
        }// ReadInt16()


        //---------------------------------------------------------------------
        // ReadText()
        //---------------------------------------------------------------------	
        public string ReadText(ref bool pbResult)
        {
            pbResult = false;
            
            int iCount = inBufferCount;

            if (inBufferCount == 0)
            {                
                return string.Empty;
            }

            byte[] bBytes = new byte[iCount];
            if (ReadBytes(ref bBytes, iCount) == false)
            {
                return string.Empty;
            }

            pbResult = true;
            System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
            return enc.GetString(bBytes);
        }// ReadText()


        //---------------------------------------------------------------------
        // RXThread()
        //---------------------------------------------------------------------
        public void RXThread()
        {
            byte[] msgData = new byte[8];
            int msgID;
            int msgDLC;
            int msgFlag;
            long msgTime;

            while (true)
            {
                if (mut != null)
                {
                    mut.WaitOne();
                    Canlib.canStatus iCanResult = Canlib.canRead(iHandle, out msgID, msgData, out msgDLC, out msgFlag, out msgTime);
                    mut.ReleaseMutex();
                    if ( iCanResult == Canlib.canStatus.canOK)
                    {
                        if (msgFlag == Canlib.canMSG_STD)
                        {
                            for (int iIter = 0; iIter < msgDLC; iIter++)
                            {
                                queRx.Enqueue(msgData[iIter]);
                            }
                            OnDataReceived();
                        }
                    }
                }
                Thread.Sleep(10);
            }
        }// RXThread()


        //---------------------------------------------------------------------
        // SendByte()
        //---------------------------------------------------------------------		
        public bool SendByte(byte bByte)
        {

            string strCanError;
            if (isOpen == false)
            {
                return false;
            }

            byte[] bBytes = new byte[1];

            bBytes[0] = bByte;
            mut.WaitOne();
            Canlib.canStatus iCanResult = Canlib.canWrite(iHandle, (int)remoteID, bBytes, 1, Canlib.canMSG_STD);
            Canlib.canGetErrorText(iCanResult, out strCanError);
            mut.ReleaseMutex();
            if (debugMode) clsDebugTextbox.OutputInfo("SendByte() = " + strCanError, 0);
            ++iBytesSent;

            return (iCanResult == Canlib.canStatus.canOK);
        }// SendByte()


        //---------------------------------------------------------------------
        // SendByte()
        //---------------------------------------------------------------------	
        public bool SendByte(int iByte)
        {
            return SendByte(Convert.ToByte(iByte));
        }// SendByte()	


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes(ref byte[] bBytes, int iOffset, int iCount)
        {
            if (isOpen == false)
            {
                return false;
            }

            for (int iIter = 0; iIter < iCount; iIter++)
            {
                if (!SendByte(bBytes[iOffset + iIter]))
                    return false;
            }
            return true;
        }// SendBytes()


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes(ref byte[] bBytes, int iOffset, int iCount, int iDLC)
        {
            int iBytesLeft = iCount;
            int iBytesToSend;
            int iIter;
            int iSentBytes = 0;
            string strCanError;
            byte[] byMsgData = new byte[8];

            while (iBytesLeft > 0)
            {
                iBytesToSend = Math.Min(iBytesLeft, iDLC);

                for (iIter = 0; iIter < iBytesToSend; iIter++)
                {
                    byMsgData[iIter] = bBytes[iSentBytes + iIter];
                }
                // Write the CAN message into the transmit FIFO
                mut.WaitOne();
                Canlib.canStatus iCanResult = Canlib.canWrite(iHandle, (int)remoteID, byMsgData, iBytesToSend, Canlib.canMSG_STD);
                Canlib.canGetErrorText(iCanResult, out strCanError);
                mut.ReleaseMutex();
                if (debugMode) clsDebugTextbox.OutputInfo("SendBytes() = " + strCanError, 0);

                iSentBytes += iBytesToSend;
                iBytesLeft -= iBytesToSend;
            }
            iBytesSent += iCount;

            return true;
        }// SendBytes()


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes(ref int[] iBytes, int iOffset, int iCount)
        {
            byte[] bBytes = new byte[iCount];
            for (int iIter = 0; iIter < iCount; iIter++)
            {
                bBytes[iIter] = (byte)iBytes[iIter];
            }

            return SendBytes(ref bBytes, 0, iCount);
        }// SendBytes()		


        //---------------------------------------------------------------------
        // SendText()
        //---------------------------------------------------------------------	
        public bool SendText(string pstrText)
        {
            char[] characters = pstrText.ToCharArray();
            byte[] bBytes = new byte[characters.Length];

            for (int iIter = 0; iIter < characters.Length; iIter++)
            {
                bBytes[iIter] = Convert.ToByte(characters[iIter]);
            }

            return SendBytes(ref bBytes, 0, bBytes.Length);
        }// SendText()


        //---------------------------------------------------------------------
        // Setup()
        //---------------------------------------------------------------------	
        public void Setup(string pstrPortname, int piBaudrate)
        {
            portName = pstrPortname;
            baudrate = piBaudrate;
        }// Setup()	


        //---------------------------------------------------------------------
        // GetPorts()
        // Description: enumerates available ports
        //---------------------------------------------------------------------	
        static public ArrayList GetPorts(ref bool pbSuccess)
        {
            pbSuccess = false;

            string strPortName;
            object DevDescr;
            object CardNo;
            object ChannelNo;
            int NumberOfChannel;
            ArrayList lstPorts = new ArrayList(11);

            Canlib.canInitializeLibrary();
            Thread.Sleep(50);

            if (Canlib.canGetNumberOfChannels(out NumberOfChannel) == Canlib.canStatus.canOK)
            {
                for (int iIter = 0; iIter < NumberOfChannel; iIter++)
                {
                    Canlib.canGetChannelData(iIter, Canlib.canCHANNELDATA_DEVDESCR_ASCII, out DevDescr);
                    Canlib.canGetChannelData(iIter, Canlib.canCHANNELDATA_CARD_NUMBER, out CardNo);
                    Canlib.canGetChannelData(iIter, Canlib.canCHANNELDATA_CHAN_NO_ON_CARD, out ChannelNo);
                    strPortName = (DevDescr.ToString() + " " + CardNo.ToString() + " Channel " + ChannelNo.ToString()).Trim(new char[] { '\0' });
                    lstPorts.Add(strPortName);
                }
            }
            else
            {
                //clsDebugTextbox.OutputError("No device found\n");
                Canlib.canUnloadLibrary();
                return null;
            }

            Canlib.canUnloadLibrary();

            pbSuccess = true;
            return lstPorts;
        }// GetPorts()

    }// Class: clsds30LoaderPortKvaser
}

