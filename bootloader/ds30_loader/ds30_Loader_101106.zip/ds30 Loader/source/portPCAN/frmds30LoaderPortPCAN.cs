﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

/// <summary>
/// Inclusion of PEAK PCAN-Basic namespace
/// </summary>
using Peak.Can.Basic;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: frmds30LoaderPortPCAN
	//-------------------------------------------------------------------------
    public partial class frmds30LoaderPortPCAN : Form
    {
        private clsds30LoaderPortPCAN objParentPort = null;

        
        //---------------------------------------------------------------------
		// Constructor
		//---------------------------------------------------------------------
        public frmds30LoaderPortPCAN( clsds30LoaderPortPCAN pobjParentPort )
        {
            InitializeComponent();
            
            objParentPort = pobjParentPort;
            
            lblVersion.Text = clsds30LoaderPortPCAN.strVersion;

            cboDlc.Items.Add( "1" );
            cboDlc.Items.Add( "8" );
            cboDlc.Text = objParentPort.txDlc.ToString();
        }// Constructor
        

		//---------------------------------------------------------------------
		// Apply
        // Description: update SJW
		//---------------------------------------------------------------------
        private void Apply()
        {
            try {
                objParentPort.txDlc = int.Parse( cboDlc.Text );
            } catch {
                MessageBox.Show( "Failed to parse Tx DLC. DLC is " + objParentPort.txDlc.ToString() );
            }
        }// Apply


		//---------------------------------------------------------------------
		// btnClose_Click
		//---------------------------------------------------------------------
        private void btnClose_Click(object sender, EventArgs e)
        {
            //
            Apply();

            // Save settings
            clsSettingsPortPCAN objSettings = new clsSettingsPortPCAN();
            objSettings.txDLC = objParentPort.txDlc;
            objParentPort.SaveSettings( objSettings );

            //
            this.Close();
        }// btnClose_Click

    }// Class: frmds30LoaderPortPCAN
}
