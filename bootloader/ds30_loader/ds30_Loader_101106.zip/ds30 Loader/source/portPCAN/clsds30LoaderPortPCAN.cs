﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader
//
// Copyright:		Copyright © 2010, Mikael Gustafsson
//
// Version:			0.9.0 october 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			0.9.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
  

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using System.Text;

using GHelper;
using ds30Loader;

using Peak.Can.Basic;
using TPCANHandle = System.Byte;

namespace ds30Loader
{

	//-------------------------------------------------------------------------
	// Class: clsds30LoaderPortPCAN
	//-------------------------------------------------------------------------
	public class clsds30LoaderPortPCAN : clsPortBase, IPort, IPortCAN
	{
        //---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
        private int                         iBaudRate           = 0;
        private string                      strPortName         = string.Empty;
        private Boolean                     bIsOpen             = false;
        private ArrayList                   lstPortNames        = null;             //channel name as key, index as value
        private bool                        bValidPortName      = false;
        private Queue                       queRx               = null;
        private int                         iOutBufferCount     = 0;
        private Thread                      trdRx               = null; 
        private const string                strAppName          = "ds30Loader";

        private AutoResetEvent              m_ReceiveEvent;                         //receive-Event        
        private TPCANHandle                 m_PcanHandle;                           //saves the handle of a PCAN hardware		

        static private Hashtable            htBaudRates;
        static private ArrayList            lstBaudRates;
        static public string                strVersion          = "0.9.0";
        
        static private TPCANHandle[]        m_HandlesArray      = {                 /// Handles of the current available PCAN-Hardware
            PCANBasic.PCAN_ISABUS1,
            PCANBasic.PCAN_ISABUS2,
            PCANBasic.PCAN_ISABUS3,
            PCANBasic.PCAN_ISABUS4,
            PCANBasic.PCAN_ISABUS5,
            PCANBasic.PCAN_ISABUS6,
            PCANBasic.PCAN_ISABUS7,
            PCANBasic.PCAN_ISABUS8,
            PCANBasic.PCAN_DNGBUS1,
            PCANBasic.PCAN_PCIBUS1,
            PCANBasic.PCAN_PCIBUS2,
            PCANBasic.PCAN_PCIBUS3,
            PCANBasic.PCAN_PCIBUS4,
            PCANBasic.PCAN_PCIBUS5,
            PCANBasic.PCAN_PCIBUS6,
            PCANBasic.PCAN_PCIBUS7,
            PCANBasic.PCAN_PCIBUS8,
            PCANBasic.PCAN_USBBUS1,
            PCANBasic.PCAN_USBBUS2,
            PCANBasic.PCAN_USBBUS3,
            PCANBasic.PCAN_USBBUS4,
            PCANBasic.PCAN_USBBUS5,
            PCANBasic.PCAN_USBBUS6,
            PCANBasic.PCAN_USBBUS7,
            PCANBasic.PCAN_USBBUS8,
            PCANBasic.PCAN_PCCBUS1,
            PCANBasic.PCAN_PCCBUS2
        };        

		//
		public event clsPortBase.DataReceivedDelegate DataReceived;


		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public clsds30LoaderPortPCAN() 
		{
            Init();

            // Load settings first
            bool bLoadSettingsResult = false;
            clsSettingsPortPCAN objSettings = clsds30LoaderPortPCAN.LoadSettings( ref bLoadSettingsResult );
            if ( bLoadSettingsResult == false ) {
                objSettings = new clsSettingsPortPCAN();
            }
            
            // Apply settings
            txDlc = objSettings.txDLC;
		}// Constructor()

        
        //---------------------------------------------------------------------
        // Constructor()
        //---------------------------------------------------------------------	
        public clsds30LoaderPortPCAN( string pstrPortname, int piBaudrate )
        {
            Init();

            Setup( pstrPortname, piBaudrate );
        }// Constructor()
	

		//---------------------------------------------------------------------
		// Destructor()
		//---------------------------------------------------------------------	
        ~clsds30LoaderPortPCAN() 
		{
            Close();
		}// Destructor()
		
        
		//---------------------------------------------------------------------
		// Event: DataReceived
		//---------------------------------------------------------------------
		protected internal void OnDataReceived()
		{
			// ChangedEvent will be null if no client has hooked up a delegate to the event.
			if ( DataReceived != null ) {
				DataReceived( this, null );
			}
		}//Event: ChangesMade	


		//---------------------------------------------------------------------
		// Property: allowCustomBaudRate
		//---------------------------------------------------------------------
		public bool allowCustomBaudRate
		{
			get {
				return false;
			} set {
			}
        }//Property: allowCustomBaudRate 	 
        
        
        //---------------------------------------------------------------------
		// Property: baudrate
		//---------------------------------------------------------------------
		public int baudrate
		{
			get {
				return iBaudRate;
			} set {
                if ( isOpen == true ) {
                    throw new Exception( "Port is open" );
                }
				iBaudRate = value;
			}
        }//Property: baudrate 	 
        

 		//---------------------------------------------------------------------
		// Property: debugMode
		//---------------------------------------------------------------------
		public bool debugMode{ get; set; }
  

		//---------------------------------------------------------------------
		// Property: dtrEnable
		//---------------------------------------------------------------------
		public bool dtrEnable{ get; set; }
          
   
		//---------------------------------------------------------------------
		// Property: echoVerification
		//---------------------------------------------------------------------
		public bool echoVerification { get; set; }
            		

		//---------------------------------------------------------------------
		// Property: hasWindow
		//---------------------------------------------------------------------
		public bool hasWindow
		{
			get {
				return true;
			}
        }//Property: hasWindow


		//---------------------------------------------------------------------
		// Property: inBufferCount
		//---------------------------------------------------------------------
		public int inBufferCount
		{
			get {
				return queRx.Count;
			}
        }//Property: inBufferCount        		
		
		
		//---------------------------------------------------------------------
		// Property: isOpen
		//---------------------------------------------------------------------
		public bool isOpen
		{
			get {
				return bIsOpen;
			}
        }//Property: isOpen              		
            		

		//---------------------------------------------------------------------
		// Property: localID
		//---------------------------------------------------------------------
		public uint localID { get; set; }


		//---------------------------------------------------------------------
		// Property: outBufferCount
		//---------------------------------------------------------------------
		public int outBufferCount
		{
			get {
				return iOutBufferCount;
			}
        }//Property: outBufferCount  
        
        		
		//---------------------------------------------------------------------
		// Property: portName
		//---------------------------------------------------------------------
		public string portName
		{
			get {
                return strPortName;
            }
			set {
                if ( isOpen == true ) {
                    throw new Exception( "Port is open" );
                }
                string strPortName = value;
                
                string strTemp = strPortName.Substring( strPortName.IndexOf('(')+1, 2 );
                m_PcanHandle = Convert.ToByte( strTemp, 16 );

                if ( lstPortNames.Contains(strPortName) == false ) {
                    bValidPortName = false;
                    return;
                }
                strPortName = value;
                bValidPortName = true;
            }
        }//Property: portName        
 

        //---------------------------------------------------------------------
        // Property: portType
        //---------------------------------------------------------------------
        public PortType portType { 
            get {
                return PortType.CAN;
            }
        }// Property: portType
            		

		//---------------------------------------------------------------------
		// Property: remoteID
		//---------------------------------------------------------------------
		public uint remoteID { get; set; }
  

		//---------------------------------------------------------------------
		// Property: rtsEnable
		//---------------------------------------------------------------------
		public bool rtsEnable{ get; set; }
  

		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		new public static bool supportsWindows{ get {return true;} }
  

		//---------------------------------------------------------------------
		// Property: supportsLinux
		//---------------------------------------------------------------------
		new public static bool supportsLinux{ get {return false;} }
  

		//---------------------------------------------------------------------
		// Property: supportsMac
		//---------------------------------------------------------------------
		new public static bool supportsMac{ get {return false;} }
  

		//---------------------------------------------------------------------
		// Property: txDlc
		//---------------------------------------------------------------------
		public int txDlc{ get; set; }
	        
   
		//---------------------------------------------------------------------
		// Property: version
		//---------------------------------------------------------------------
		public string version
		{
			get {
				return strVersion;
			}	
        }//Property: version 
		

        //---------------------------------------------------------------------
        // Close()
        //---------------------------------------------------------------------	
        public bool Close()
        {
		    if ( isOpen == false ) {
                return !bIsOpen;
            }

            // Releases a current connected PCAN-Basic channel
            TPCANStatus status = PCANBasic.Uninitialize( m_PcanHandle );

            // Stop RX thread            
            if ( trdRx != null ) {
                trdRx.Abort();
                trdRx.Join();
                trdRx = null;
            }
            
            bIsOpen = false;

            queRx.Clear();

            return ( !bIsOpen );
        }// Close()  


		//---------------------------------------------------------------------
		// EchoClearQueue()
		//---------------------------------------------------------------------	
		public void EchoClearQueue() 
		{
		}// EchoRead()


		//---------------------------------------------------------------------
		// EmptyBuffers()
		//---------------------------------------------------------------------	
		public void EmptyBuffers( bool bRx, bool bTx ) 
		{			
		}// EmptyBuffers()


        /// <summary>
        /// Gets the formated text for a CPAN-Basic channel handle
        /// </summary>
        /// <param name="handle">PCAN-Basic Handle to format</param>
        /// <returns>The formatted text for a channel</returns>
        static private string FormatChannelName( TPCANHandle handle )
        {
            TPCANDevice devDevice;
            byte byChannel;

            // Gets the owner device and channel for a 
            // PCAN-Basic handle
            //
            devDevice = (TPCANDevice)(handle >> 4);
            byChannel = (byte)(handle & 0xF);

            // Constructs the PCAN-Basic Channel name and return it
            //
            return string.Format("{0} {1} ({2:X2}h)", devDevice, byChannel, handle);
        }//FormatChannelName()


        //---------------------------------------------------------------------
        // Init()
        //---------------------------------------------------------------------
        private bool Init()
        {
            ResetCounters();
            queRx = new Queue( 11 );

            debugMode = false;

            m_ReceiveEvent = new System.Threading.AutoResetEvent( false );  //creates the event used for signalize incomming messages 

            localID = 0x7ff;
            remoteID = 1;
            txDlc = 1;

            // Ports
            bool bGetPortsResult = false;
            lstPortNames = GetPorts( ref bGetPortsResult );
            if ( bGetPortsResult == false ) {
                lstPortNames = new ArrayList( 11 );
            }

            // Baud rates
            if ( htBaudRates == null ) htBaudRates = new Hashtable( 11 );
            if ( htBaudRates.Count == 0 ) {
                htBaudRates.Add( 1000000, TPCANBaudrate.PCAN_BAUD_1M );
                htBaudRates.Add(  500000, TPCANBaudrate.PCAN_BAUD_500K );
                htBaudRates.Add(  250000, TPCANBaudrate.PCAN_BAUD_250K );
                htBaudRates.Add(  125000, TPCANBaudrate.PCAN_BAUD_125K );
                htBaudRates.Add(  100000, TPCANBaudrate.PCAN_BAUD_100K );
                htBaudRates.Add(   50000, TPCANBaudrate.PCAN_BAUD_50K );
                htBaudRates.Add(   20000, TPCANBaudrate.PCAN_BAUD_20K );
                htBaudRates.Add(   10000, TPCANBaudrate.PCAN_BAUD_10K );
                htBaudRates.Add(    5000, TPCANBaudrate.PCAN_BAUD_5K );
            }
            if ( lstBaudRates == null ) lstBaudRates = new ArrayList( 11 );
            if ( lstBaudRates.Count == 0 ) {
                foreach ( int iBaudRate in htBaudRates.Keys ) {
                    lstBaudRates.Add( iBaudRate );
                }
            }
            
            return true;
        }// Init()
		
        
        //-------------------------------------------------------------------------
        // LoadSettings()
        // Description: 
        //-------------------------------------------------------------------------
        static public clsSettingsPortPCAN LoadSettings( ref bool pbResult ) 
        {
            pbResult = true;
            clsSettingsPortPCAN objSettings = null;

            //-----------------------------------------------------------------
			// Filename
            //-----------------------------------------------------------------			
            string strPath = Application.StartupPath;
			string strFilename = strPath + Path.DirectorySeparatorChar + "settingsPortPCAN.xml";


			//-----------------------------------------------------------------
			// No previous settings
			//-----------------------------------------------------------------
			if ( File.Exists(strFilename) == false ) {
                objSettings = new clsSettingsPortPCAN();

			
			//-----------------------------------------------------------------
			// Load settings
			//-----------------------------------------------------------------            
            } else { 
                XmlSerializer xmlSerializer = new XmlSerializer( typeof( clsSettingsPortPCAN ) );
                TextReader textReader = new StreamReader( strFilename );
                bool bLoadSettingsFailed = false;
                try {                
                    objSettings = (clsSettingsPortPCAN)xmlSerializer.Deserialize( textReader );
                } catch {
                    clsDebugTextbox.OutputResult( false );
                    objSettings = new clsSettingsPortPCAN();
                    bLoadSettingsFailed = true;

                }
                if ( textReader != null ) {
                    textReader.Close();
                }
                if ( bLoadSettingsFailed == false ) {
                    //clsDebugTextbox.OutputResult( true );
                }
            } 


			//-----------------------------------------------------------------
			// Finished
			//-----------------------------------------------------------------
            pbResult = ( objSettings != null );
            return objSettings;
		}//LoadSettings()

        
        //---------------------------------------------------------------------
        // GetBaudRates()
        // Description: enumerates available baud rates
        //---------------------------------------------------------------------	
        public ArrayList GetBaudRates()
        {
            return lstBaudRates;
        }// GetBaudRates()


        /// <summary>
        /// Help Function used to get an error as text
        /// </summary>
        /// <param name="error">Error code to be translated</param>
        /// <returns>A text with the translated error</returns>
        private string GetFormatedError( TPCANStatus error )
        {
            StringBuilder strTemp;

            // Creates a buffer big enough for a error-text
            //
            strTemp = new StringBuilder( 256 );
            // Gets the text using the GetErrorText API function
            // If the function success, the translated error is returned. If it fails,
            // a text describing the current error is returned.
            //
            if ( PCANBasic.GetErrorText(error, 0, strTemp) != TPCANStatus.PCAN_ERROR_OK ) {
                return string.Format("An error occurred. Error-code's text ({0:X}) couldn't be retrieved", error);
            } else {
                return strTemp.ToString();
            }
        }//GetFormatedError


        //---------------------------------------------------------------------
        // GetPorts()
        // Description: enumerates available ports
        //---------------------------------------------------------------------	
        static public ArrayList GetPorts( ref bool pbSuccess )
        {
            pbSuccess = false;
            ArrayList lstPorts = new ArrayList( 11 );   
            UInt32 iBuffer;
            TPCANStatus stsResult;

            try {
                for ( int i = 0; i < m_HandlesArray.Length; i++ ) {
                    // Includes all no-Plug&Play Handles
                    if ( m_HandlesArray[i] <= PCANBasic.PCAN_DNGBUS1 ) {
                        //lstPorts.Add( FormatChannelName( m_HandlesArray[i]) );
                    } else {
                        // Checks for a Plug&Play Handle and, according with the return value, includes it
                        // into the list of available hardware channels.
                        stsResult = PCANBasic.GetValue( m_HandlesArray[i], TPCANParameter.PCAN_CHANNEL_CONDITION, out iBuffer, sizeof(UInt32) );
                        if ( (stsResult == TPCANStatus.PCAN_ERROR_OK) && (iBuffer == PCANBasic.PCAN_CHANNEL_AVAILABLE) ) {
                            lstPorts.Add( FormatChannelName( m_HandlesArray[i]) );
                        }
                    }
                }
            } catch {
                return null;
            }

            pbSuccess = true;
            return lstPorts;
        }// GetPorts()


        //---------------------------------------------------------------------
        // Open()
        //---------------------------------------------------------------------	
        public bool Open()        
        {
            if ( isOpen == true || bValidPortName == false ) {
                return bIsOpen;
            }

            TPCANStatus stsResult;

            // Connects a selected PCAN-Basic channel
            stsResult = PCANBasic.Initialize(
                m_PcanHandle,
                (TPCANBaudrate)htBaudRates[baudrate], 
                TPCANType.PCAN_TYPE_DNG,    //only used by non PnP devices
                0,                          //only used by non PnP devices
                0                           //only used by non PnP devices
            );

            if ( stsResult != TPCANStatus.PCAN_ERROR_OK ) {
                return false;
            } 
            
            // Sets the custom filter
            stsResult = PCANBasic.FilterMessages(
                m_PcanHandle,
                localID,
                localID,
                TPCANMode.PCAN_MODE_STANDARD
            );
            if ( stsResult != TPCANStatus.PCAN_ERROR_OK ) {
                return false;
            }

            // Create and start the tread to read CAN Message using SetRcvEvent()
            System.Threading.ThreadStart threadDelegate = new System.Threading.ThreadStart( RXThread );
            trdRx = new System.Threading.Thread( threadDelegate );
            trdRx.Start();     

            // Sets the connection status of the main-form
            bIsOpen = ( stsResult == TPCANStatus.PCAN_ERROR_OK );

            return ( bIsOpen );    
        }// Open()

					
		//---------------------------------------------------------------------
		// OpenWindow()
		//---------------------------------------------------------------------	
		public void OpenWindow( System.Windows.Forms.Form pwndOwner ) 
		{
		    frmds30LoaderPortPCAN wndSettings = new frmds30LoaderPortPCAN( this );
            wndSettings.ShowDialog( pwndOwner );
		}// OpenWindow()		
	

		//---------------------------------------------------------------------
		// ReadByte()
		//---------------------------------------------------------------------	
		public bool ReadByte(ref int iByte) 
		{	
            if ( inBufferCount < 1 ) return false;
            iByte = (byte)queRx.Dequeue();
            ++iBytesReceived;
			return true;		
		}// ReadByte()	
		
						
		//---------------------------------------------------------------------
		// ReadBytes()
		//---------------------------------------------------------------------	
		public bool ReadBytes( ref byte []iBytes, int iCount ) 
		{
            if ( inBufferCount < iCount ) return false;

		    for ( int iIter = 0; iIter < iCount; iIter++ ) {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
		}// ReadBytes()
        
        
        //---------------------------------------------------------------------
		// ReadBytes()
		//---------------------------------------------------------------------	
		public bool ReadBytes( ref int []iBytes, int iCount ) 
		{
            if ( inBufferCount < iCount ) return false;

		    for ( int iIter = 0; iIter < iCount; iIter++ ) {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
		}// ReadBytes()
		
						
		//---------------------------------------------------------------------
		// ReadInt16()
		//---------------------------------------------------------------------	
		public bool ReadInt16( ref int iInteger ) 
		{
            if ( inBufferCount < 2 ) return false;
            iInteger = (byte)queRx.Dequeue() + (((byte)queRx.Dequeue())<<8);
            iBytesReceived += 2;
			return true;	
		}// ReadInt16()
		
				
		//---------------------------------------------------------------------
		// ReadText()
		//---------------------------------------------------------------------	
		public string ReadText( ref bool pbResult ) 
		{
			pbResult = false;
            
            int iCount = inBufferCount;
            
            if ( inBufferCount == 0 ) {                
                return string.Empty;
            }
            
            byte[] bBytes = new byte[ iCount ];
            if ( ReadBytes(ref bBytes, iCount) == false ) {
                return string.Empty;                
            }

            pbResult = true;
            System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
            return enc.GetString( bBytes );
		}// ReadText()


        //---------------------------------------------------------------------
        // RXThread()
        //---------------------------------------------------------------------		
        public void RXThread() 
        {
            UInt32 iBuffer;
            TPCANStatus stsResult;

            iBuffer = Convert.ToUInt32( m_ReceiveEvent.SafeWaitHandle.DangerousGetHandle().ToInt32() );
            
            // Sets the handle of the Receive-Event.
            stsResult = PCANBasic.SetValue( m_PcanHandle, TPCANParameter.PCAN_RECEIVE_EVENT, ref iBuffer, sizeof(UInt32) );

            if( stsResult != TPCANStatus.PCAN_ERROR_OK ) {
			    MessageBox.Show(GetFormatedError(stsResult),"Error!",MessageBoxButtons.OK,MessageBoxIcon.Error);
			    return;
		    }
  
            TPCANMsg CANMsg;
            TPCANTimestamp CANTimeStamp;
            while ( true ) {
                // Waiting for Receive-Event
                m_ReceiveEvent.WaitOne();


                // We read at least one time the queue looking for messages.
                // If a message is found, we look again trying to find more.
                // If the queue is empty or an error occurr, we get out from
                // the dowhile statement.
                do {
                    // We execute the "Read" function of the PCANBasic   
                    stsResult = PCANBasic.Read( m_PcanHandle, out CANMsg, out CANTimeStamp );

                    // A message was received, we process the message(s)
                    if ( stsResult == TPCANStatus.PCAN_ERROR_OK ) {
                        for ( int iByte = 0; iByte < CANMsg.LEN; iByte++ ) {
                            queRx.Enqueue( CANMsg.DATA[iByte] );
                        }
                    }
                } while ( !Convert.ToBoolean(stsResult & TPCANStatus.PCAN_ERROR_QRCVEMPTY) );
                OnDataReceived();
            }
        }// RXThread()
      

        //-------------------------------------------------------------------------
		// SaveSettings()
		// Description: 
		//-------------------------------------------------------------------------
		public void SaveSettings( clsSettingsPortPCAN pobjSettings)
		{	            
            clsSettingsPortPCAN objSettings = new clsSettingsPortPCAN();

            //-----------------------------------------------------------------
			// Filename
            //-----------------------------------------------------------------			
            string strPath = Application.StartupPath;
			string strFilename = strPath + Path.DirectorySeparatorChar + "settingsPortPCAN.xml";
 
            
            //-----------------------------------------------------------------
            // Serialize
            //-----------------------------------------------------------------           
            XmlSerializer xmlSerializer = new XmlSerializer( typeof(clsSettingsPortPCAN) );
            TextWriter textWriter = new StreamWriter( strFilename );
            xmlSerializer.Serialize( textWriter, pobjSettings );
            textWriter.Close();
		}//SaveSettings()    


        //---------------------------------------------------------------------
        // SendByte()
        //---------------------------------------------------------------------		
        public bool SendByte( byte bByte )
        {
            byte[] bBytes = new byte [1];
            bBytes[0] = bByte;

            return SendBytes( ref bBytes, 0, 1 );
        }// SendByte()


		//---------------------------------------------------------------------
		// SendByte()
		//---------------------------------------------------------------------	
		public bool SendByte( int iByte ) 
		{
			return SendByte( Convert.ToByte(iByte) );
		}// SendByte()	


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes( ref byte[] bBytes, int iOffset, int iCount )
        {
            return SendBytes( ref bBytes, iOffset, iCount, txDlc );
        }// SendBytes()


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes(ref byte[] bBytes, int iOffset, int iCount, int iDlc)
        {
            int iBytesLeft = iCount;
            int iBytesToSend;
            int iIter;
            int iSentBytes=0;
            bool bAllOk = true;
            TPCANMsg CANMsg = new TPCANMsg();
            TPCANStatus stsResult;

            CANMsg.DATA = new byte[8];

            while ( iBytesLeft > 0 ) {
                iBytesToSend = Math.Min( iBytesLeft, iDlc ); 

                CANMsg.ID = remoteID;
                CANMsg.LEN = (byte)iBytesToSend;
                CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD;

                for ( iIter = 0; iIter < iBytesToSend; iIter++ ) {
                    CANMsg.DATA[iIter] = bBytes[iSentBytes+iIter];
                }

                // The message is sent to the configured hardware
                stsResult = PCANBasic.Write( m_PcanHandle, ref CANMsg );
                
                iSentBytes += iBytesToSend;
                iBytesLeft -= iBytesToSend;
                
                bAllOk &= ( stsResult == TPCANStatus.PCAN_ERROR_OK );
            }

            iBytesSent += iCount;
            return bAllOk;
        }// SendBytes()
		

		//---------------------------------------------------------------------
		// SendBytes()
		//---------------------------------------------------------------------	
		public bool SendBytes( ref int[] iBytes, int iOffset, int iCount ) 
		{
			byte [] bBytes = new byte [ iCount ];
			for ( int iIter = 0; iIter < iCount; iIter++ ) {
				bBytes[ iIter ] = (byte)iBytes[ iIter ];
			}
			
			return SendBytes( ref bBytes, 0, iCount );
		}// SendBytes()		
							
						
		//---------------------------------------------------------------------
		// SendText()
		//---------------------------------------------------------------------	
		public bool SendText( string pstrText ) 
		{
            char[] characters = pstrText.ToCharArray();
            byte[] bBytes = new byte[characters.Length];
            
            for ( int iIter = 0; iIter < characters.Length; iIter++ ) {
                bBytes[iIter] = Convert.ToByte( characters[iIter] );
            }

            return SendBytes( ref bBytes, 0, bBytes.Length );
		}// SendText()
	

		//---------------------------------------------------------------------
		// Setup()
		//---------------------------------------------------------------------	
		public void Setup( string pstrPortname, int piBaudrate ) 
		{
            portName = pstrPortname;
            baudrate = piBaudrate;           
		}// Setup()	

	}// Class: clsds30LoaderPortPCAN
}
