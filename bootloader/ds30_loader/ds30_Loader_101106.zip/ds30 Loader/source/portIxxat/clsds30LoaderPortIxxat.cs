﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader
//
// Copyright:		Copyright © 2010, Mikael Gustafsson
//
// Developed by:    Fabien Pieraldi
//
// Version:			1.0.1 october 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			1.0.1 Get multiple Can message with one RxEvent (speed improvment)
//                        Modify Wait RxEvent
//                        Bugfix: Check for null in Close()
//                        Bugfix: ReadText() fixed
//                  1.0.0 Modify Stop RX thread in PortClose()
//                        Modify loop in RXThread()
//                        Added window with some information about the driver
//                        Bugfix: Always use the first Can interface when multiples card plugged 
//                  0.9.1 Added ReadText()
//                  0.9.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
  

using System;
using System.Collections;
using System.Threading;
using System.IO;

using Ixxat.Vci3;
using Ixxat.Vci3.Bal;
using Ixxat.Vci3.Bal.Can;

using GHelper;
using ds30Loader;

namespace ds30Loader
{

	//-------------------------------------------------------------------------
	// Class: clsds30LoaderPortIxxat
	//-------------------------------------------------------------------------
	public class clsds30LoaderPortIxxat : clsPortBase, IPort, IPortCAN
	{
        //---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
        private int iBaudRate = 0;
        private string strPortName = string.Empty;
        private Boolean bIsOpen = false;
        private Hashtable htPortNames = null;             //channel name as key, index as value
        private bool bValidPortName = false;
        private int iOutBufferCount = 0;

        //   Reference to the used VCI device.
        private IVciDevice m_IXXAT_Device;

        //   Reference to the CAN controller.
        private ICanControl m_IXXAT_CanCtl;

        //   Reference to the CAN message communication channel.
        private ICanChannel m_IXXAT_CanChn;

        //   Reference to the message writer of the CAN message channel.
        private ICanMessageWriter m_IXXAT_Writer;

        //   Reference to the message reader of the CAN message channel.
        private ICanMessageReader m_IXXAT_Reader;

        //   Event that's set if at least one message was received.
        private AutoResetEvent mRxEvent;

        //   Thread that handles the message reception.
        private Thread trdRx = null;

        private Queue queRx = null;

        public event clsPortBase.DataReceivedDelegate DataReceived;

        private const string strAppName = "ds30Loader";
        static public string strVersion = "1.0.1";

		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public clsds30LoaderPortIxxat() 
		{
            Init();
            clsIxxatBitRates.Init();
		}// Constructor()

        
        //---------------------------------------------------------------------
        // Constructor()
        //---------------------------------------------------------------------	
        public clsds30LoaderPortIxxat( string pstrPortname, int piBaudrate )
        {
            Init();
            Setup( pstrPortname, piBaudrate );
        }// Constructor()
	

		//---------------------------------------------------------------------
		// Destructor()
		//---------------------------------------------------------------------	
        ~clsds30LoaderPortIxxat() 
		{
            Close();
            DisposeVciObject_IXXAT(m_IXXAT_Device);
		}// Destructor()
		
        
		//---------------------------------------------------------------------
		// Event: DataReceived
		//---------------------------------------------------------------------
		protected internal void OnDataReceived()
		{
			// ChangedEvent will be null if no client has hooked up a delegate to the event.
			if ( DataReceived != null ) {
				DataReceived( this, null );
			}
		}//Event: ChangesMade	


		//---------------------------------------------------------------------
		// Property: allowCustomBaudRate
		//---------------------------------------------------------------------
		public bool allowCustomBaudRate
		{
			get {
				return false;
			} set {
			}
        }//Property: allowCustomBaudRate 	 



        //---------------------------------------------------------------------
        // Property: baudrate
        //---------------------------------------------------------------------
        public int baudrate
        {
            get
            {
                return iBaudRate;
            }
            set
            {
                if (isOpen == true)
                {
                    throw new Exception("Port is open\n");
                }
                iBaudRate = value;
            }
        }//Property: baudrate 	 
	    
    
        //---------------------------------------------------------------------
        // Property: debugMode
        //---------------------------------------------------------------------
        public bool debugMode { get; set; }
   

		//---------------------------------------------------------------------
		// Property: dtrEnable
		//---------------------------------------------------------------------
		public bool dtrEnable{ get; set; }
          
   
		//---------------------------------------------------------------------
		// Property: echoVerification
		//---------------------------------------------------------------------
		public bool echoVerification { get; set; }            		
            	

		//---------------------------------------------------------------------
		// Property: hasWindow
		//---------------------------------------------------------------------
		public bool hasWindow
		{
			get {
				return true;
			}
        }//Property: hasWindow


        //---------------------------------------------------------------------
        // Property: inBufferCount
        //---------------------------------------------------------------------
        public int inBufferCount
        {
            get
            {
                return queRx.Count;
            }
        }//Property: inBufferCount       		


        //---------------------------------------------------------------------
        // Property: isOpen
        //---------------------------------------------------------------------
        public bool isOpen
        {
            get
            {
                return bIsOpen;
            }
        }//Property: isOpen  
            		

		//---------------------------------------------------------------------
		// Property: localID
		//---------------------------------------------------------------------
		public uint localID { get; set; }
              		

		//---------------------------------------------------------------------
		// Property: outBufferCount
		//---------------------------------------------------------------------
		public int outBufferCount
		{
			get {
                return iOutBufferCount;
			}
        }//Property: outBufferCount  
        
        		
		//---------------------------------------------------------------------
		// Property: portName
		//---------------------------------------------------------------------
		public string portName
		{
            get
            {
                return strPortName;
            }
            set
            {
                if (isOpen == true)
                {
                    throw new Exception("Port is open\n");
                }
                string strPortName = value;

                if (htPortNames.Contains(strPortName) == false)
                {
                    bValidPortName = false;
                    return;
                }

                m_IXXAT_Device = (IVciDevice)htPortNames[strPortName];

                if (debugMode)
                {
                    clsDebugTextbox.OutputInfo("Port name set to " + value, 0);
                }
                this.strPortName = value;
                bValidPortName = true;
            }
        }//Property: portName        
 

        //---------------------------------------------------------------------
        // Property: portType
        //---------------------------------------------------------------------
        public PortType portType { 
            get {
                return PortType.CAN;
            }
        }// Property: portType 
            		

		//---------------------------------------------------------------------
		// Property: remoteID
		//---------------------------------------------------------------------
		public uint remoteID { get; set; }


		//---------------------------------------------------------------------
		// Property: rtsEnable
		//---------------------------------------------------------------------
		public bool rtsEnable{ get; set; }
  

		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		new public static bool supportsWindows{ get {return true;} }
  

		//---------------------------------------------------------------------
		// Property: supportsLinux
		//---------------------------------------------------------------------
		new public static bool supportsLinux{ get {return false;} }
  

		//---------------------------------------------------------------------
		// Property: supportsMac
		//---------------------------------------------------------------------
		new public static bool supportsMac{ get {return false;} }
	        
   
		//---------------------------------------------------------------------
		// Property: version
		//---------------------------------------------------------------------
		public string version
		{
			get {
				return strVersion;
			}	
        }//Property: version 
		

        //---------------------------------------------------------------------
        // Close()
        //---------------------------------------------------------------------	
        public bool Close()
        {
            if (isOpen == false)
            {
                return !bIsOpen;
            }

            try
            {
                DisposeVciObject_IXXAT(m_IXXAT_CanCtl);
                DisposeVciObject_IXXAT(m_IXXAT_Reader);
                DisposeVciObject_IXXAT(m_IXXAT_Writer);
                DisposeVciObject_IXXAT(m_IXXAT_CanChn);
                bIsOpen = false;
            }
            catch
            {
                clsDebugTextbox.OutputError("Dispose Can socket failed !\n");
                bIsOpen = true;
            }

            // Stop RX thread
            if (trdRx != null)
            {
                trdRx.Abort();
                trdRx = null;
            }

            queRx.Clear();

            return !bIsOpen;
        }// Close()


		//---------------------------------------------------------------------
		// EmptyBuffers()
		//---------------------------------------------------------------------	
		public void EmptyBuffers( bool bRx, bool bTx ) 
		{			
		}// EmptyBuffers()

        
        //---------------------------------------------------------------------
        // GetBaudRates()
        // Description: enumerates available baud rates
        //---------------------------------------------------------------------	
        public ArrayList GetBaudRates()
        {
            return clsIxxatBitRates.lstBitRates;
        }// GetBaudRates()


        //---------------------------------------------------------------------
        // Init()
        //---------------------------------------------------------------------
        private void Init()
        {
            ResetCounters();
            htPortNames = new Hashtable(11);
            queRx = new Queue(11);
            debugMode = false;

            IVciDeviceManager IXXAT_deviceManager = null;
            IVciDeviceList IXXAT_deviceList = null;
            IEnumerator IXXAT_deviceEnum = null;

            //ArrayList lstPorts = new ArrayList(11);

            try
            {
                // Get device manager from VCI server
                IXXAT_deviceManager = VciServer.GetDeviceManager();

                // Get the list of installed VCI devices
                IXXAT_deviceList = IXXAT_deviceManager.GetDeviceList();

                // Get enumerator for the list of devices
                IXXAT_deviceEnum = IXXAT_deviceList.GetEnumerator();

                // Get first device
                while (IXXAT_deviceEnum.MoveNext())
                {
                    m_IXXAT_Device = IXXAT_deviceEnum.Current as IVciDevice;
                    strPortName = (m_IXXAT_Device.Description + " " + m_IXXAT_Device.UniqueHardwareId).Trim( new char[] {'\0'});
                    htPortNames.Add(strPortName, m_IXXAT_Device);
                };
                m_IXXAT_Device = (IVciDevice)htPortNames[strPortName];

            }
            catch
            {
                clsDebugTextbox.OutputError("Error: No VCI device installed\n");
            }
            finally
            {
                // Dispose device manager ; it's no longer needed.
                DisposeVciObject_IXXAT(IXXAT_deviceManager);

                // Dispose device list ; it's no longer needed.
                DisposeVciObject_IXXAT(IXXAT_deviceList);

                // Dispose device list ; it's no longer needed.
                DisposeVciObject_IXXAT(IXXAT_deviceEnum);
            }


        }// Init()
					

		//---------------------------------------------------------------------
		// EchoClearQueue()
		//---------------------------------------------------------------------	
		public void EchoClearQueue() 
		{
		}// EchoRead()		


        //---------------------------------------------------------------------
        // Open()
        //---------------------------------------------------------------------	
        public bool Open()
        {
            IBalObject IXXAT_bal = null;

            if (isOpen == true || bValidPortName == false)
            {
                return bIsOpen;
            }

            try {
                // Open bus access layer
                IXXAT_bal = m_IXXAT_Device.OpenBusAccessLayer();

                // Open a message channel for the CAN controller
                m_IXXAT_CanChn = IXXAT_bal.OpenSocket(0, typeof(ICanChannel)) as ICanChannel;

                // Initialize the message channel
                m_IXXAT_CanChn.Initialize(1024, 128, false);

                // Get a message reader object
                m_IXXAT_Reader = m_IXXAT_CanChn.GetMessageReader();

                // Initialize message reader
                m_IXXAT_Reader.Threshold = 1;

                // Create and assign the event that's set if at least one message was received.
                mRxEvent = new AutoResetEvent(false);
                m_IXXAT_Reader.AssignEvent(mRxEvent);

                // Get a message writer object
                m_IXXAT_Writer = m_IXXAT_CanChn.GetMessageWriter();

                // Initialize message writer
                m_IXXAT_Writer.Threshold = 1;

                // Activate the message channel
                m_IXXAT_CanChn.Activate();

                // Open the CAN controller
                m_IXXAT_CanCtl = IXXAT_bal.OpenSocket(0, typeof(ICanControl)) as ICanControl;

                // Initialize the CAN controller
                clsIxxatBitRate objBitRate = clsIxxatBitRates.GetBitRate( baudrate  );
                CanBitrate objBitRates = new CanBitrate(objBitRate.Btr0,objBitRate.Btr1);
                m_IXXAT_CanCtl.InitLine(CanOperatingModes.Standard, objBitRates);

                // Set the acceptance filter
                m_IXXAT_CanCtl.SetAccFilter(CanFilter.Std, (uint)(localID<<1), (uint)0xFFF);

                // Start the CAN controller
                m_IXXAT_CanCtl.StartLine();

                // Start the receive thread
                trdRx = new Thread(new ThreadStart(RXThread));
                trdRx.Start();

                Thread.Sleep(50);

                bIsOpen = true;
            
            } catch {
                clsDebugTextbox.OutputError("Error: Initializing socket failed\n");
                bIsOpen = false;
            
            } finally {
                // Dispose bus access layer
                DisposeVciObject_IXXAT(IXXAT_bal);
            }

            //
            return (bIsOpen);
        }// Open()	
		
						
		//---------------------------------------------------------------------
		// OpenWindow()
		//---------------------------------------------------------------------	
		public void OpenWindow( System.Windows.Forms.Form pwndOwner ) 
		{
            frmds30LoaderPortIxxat wndSettings = new frmds30LoaderPortIxxat(this, m_IXXAT_Device);
            wndSettings.ShowDialog(pwndOwner);
		}// OpenWindow()

        //---------------------------------------------------------------------
        // ReadByte()
        //---------------------------------------------------------------------	
        public bool ReadByte(ref int iByte)
        {
            if (inBufferCount < 1) return false;
            iByte = (byte)queRx.Dequeue();
            ++iBytesReceived;
            return true;
        }// ReadByte()	


        //---------------------------------------------------------------------
        // ReadBytes()
        //---------------------------------------------------------------------	
        public bool ReadBytes(ref byte[] iBytes, int iCount)
        {
            if (inBufferCount < iCount) return false;

            for (int iIter = 0; iIter < iCount; iIter++)
            {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
        }// ReadBytes()


        //---------------------------------------------------------------------
        // ReadBytes()
        //---------------------------------------------------------------------	
        public bool ReadBytes(ref int[] iBytes, int iCount)
        {
            if (inBufferCount < iCount) return false;

            for (int iIter = 0; iIter < iCount; iIter++)
            {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
        }// ReadBytes()


        //---------------------------------------------------------------------
        // ReadInt16()
        //---------------------------------------------------------------------	
        public bool ReadInt16(ref int iInteger)
        {
            if (inBufferCount < 2) return false;
            iInteger = (byte)queRx.Dequeue() + (((byte)queRx.Dequeue()) << 8);
            iBytesReceived += 2;
            return true;
        }// ReadInt16()
  		
						
		//---------------------------------------------------------------------
		// ReadText()
		//---------------------------------------------------------------------	
		public string ReadText( ref bool pbResult ) 
		{
			pbResult = false;
            
            int iCount = inBufferCount;
            
            if ( inBufferCount == 0 ) {
                return string.Empty;
            }
            
            byte[] bBytes = new byte[ iCount ];
            if ( ReadBytes(ref bBytes, iCount) == false ) {
                return string.Empty;                
            }

            pbResult = true;
            System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
            return enc.GetString( bBytes );
		}// ReadText()


        //---------------------------------------------------------------------
        // RXThread()
        //---------------------------------------------------------------------
        public void RXThread()
        {
            CanMessage canMessage;

            while (true) {
                // Wait 100 ms for a message reception
                if (mRxEvent.WaitOne(100,false))
                {
                    // read a CAN message from the receive FIFO
                    while (m_IXXAT_Reader.ReadMessage(out canMessage))
                    {
                        switch (canMessage.FrameType)
                        {
                            // show data frames
                            case CanMsgFrameType.Data:
                                {
                                    if (!canMessage.RemoteTransmissionRequest)
                                    {
                                        // Store received data in rx queue
                                        for (int iIter = 0; iIter < canMessage.DataLength; iIter++)
                                        {
                                            queRx.Enqueue(canMessage[iIter]);
                                        }
                                        OnDataReceived();
                                    }
                                    else
                                    {
                                        if (debugMode) clsDebugTextbox.OutputInfo("Remote frame", 0);
                                    }
                                    break;
                                }

                            // show informational frames
                            case CanMsgFrameType.Info:
                                {
                                    switch ((CanMsgInfoValue)canMessage[0])
                                    {
                                        case CanMsgInfoValue.Start:
                                            if (debugMode) clsDebugTextbox.OutputInfo("CAN started...",0);
                                            break;
                                        case CanMsgInfoValue.Stop:
                                            if (debugMode) clsDebugTextbox.OutputInfo("CAN stopped...",0);
                                            break;
                                        case CanMsgInfoValue.Reset:
                                            if (debugMode) clsDebugTextbox.OutputInfo("CAN reseted...", 0);
                                            break;
                                    }
                                    break;
                                }

                            // show error frames
                            case CanMsgFrameType.Error:
                                {
                                    switch ((CanMsgError)canMessage[0])
                                    {
                                        case CanMsgError.Stuff:
                                            if (debugMode) clsDebugTextbox.OutputInfo("stuff error...", 0);
                                            break;
                                        case CanMsgError.Form:
                                            if (debugMode) clsDebugTextbox.OutputInfo("form error...", 0);
                                            break;
                                        case CanMsgError.Acknowledge:
                                            if (debugMode) clsDebugTextbox.OutputInfo("acknowledgment error...", 0);
                                            break;
                                        case CanMsgError.Bit:
                                            if (debugMode) clsDebugTextbox.OutputInfo("bit error...", 0);
                                            break;
                                        case CanMsgError.Crc:
                                            if (debugMode) clsDebugTextbox.OutputInfo("CRC error...", 0);
                                            break;
                                        case CanMsgError.Other:
                                            if (debugMode) clsDebugTextbox.OutputInfo("other error...", 0);
                                            break;
                                    }
                                    break;
                                }
                        }
                    }
                }
            };
        }// RXThread()


        //---------------------------------------------------------------------
        // SendByte()
        //---------------------------------------------------------------------		
        public bool SendByte(byte bByte)
        {
            if (isOpen == false)
            {
                return false;
            }

            CanMessage canMsg = new CanMessage();
            try
            {
                canMsg.TimeStamp = 0;
                canMsg.Identifier = remoteID;
                canMsg.FrameType = CanMsgFrameType.Data;
                canMsg.DataLength = 1;
                canMsg.SelfReceptionRequest = false;  // don't show this message in the console window
                canMsg[0] = bByte;
                // Write the CAN message into the transmit FIFO
                m_IXXAT_Writer.SendMessage(canMsg);
                ++iBytesSent;
            }
            catch
            {
                return false;
            }
            return true;
        }// SendByte()


		//---------------------------------------------------------------------
		// SendByte()
		//---------------------------------------------------------------------	
		public bool SendByte( int iByte ) 
		{
			return SendByte( Convert.ToByte(iByte) );
		}// SendByte()	


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes(ref byte[] bBytes, int iOffset, int iCount)
        {
            if (isOpen == false)
            {
                return false;
            }

            for (int iIter = 0; iIter < iCount; iIter++)
            {
                if (!SendByte(bBytes[iOffset + iIter]))
                    return false;
            }
            return true;
        }// SendBytes()


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes(ref byte[] bBytes, int iOffset, int iCount, int iDLC)
        {
            int iBytesLeft = iCount;
            int iBytesToSend;
            int iIter;
            int iSentBytes = 0;

            CanMessage canMsg = new CanMessage();

            try
            {
                while (iBytesLeft > 0)
                {
                    iBytesToSend = Math.Min(iBytesLeft, iDLC);

                    canMsg.TimeStamp = 0;
                    canMsg.Identifier = remoteID;
                    canMsg.FrameType = CanMsgFrameType.Data;
                    canMsg.DataLength = (byte)iBytesToSend;
                    canMsg.SelfReceptionRequest = false;  // don't show this message in the console window
                    for (iIter = 0; iIter < iBytesToSend; iIter++)
                    {
                        canMsg[iIter] = bBytes[iSentBytes + iIter];
                    }
                    // Write the CAN message into the transmit FIFO
                    m_IXXAT_Writer.SendMessage(canMsg);

                    iSentBytes += iBytesToSend;
                    iBytesLeft -= iBytesToSend;
                }
                iBytesSent += iCount;
            }
            catch
            {
                return false;
            }
            return true;
        }// SendBytes()

		
		//---------------------------------------------------------------------
		// SendBytes()
		//---------------------------------------------------------------------	
		public bool SendBytes( ref int[] iBytes, int iOffset, int iCount ) 
		{
			byte [] bBytes = new byte [ iCount ];
			for ( int iIter = 0; iIter < iCount; iIter++ ) {
				bBytes[ iIter ] = (byte)iBytes[ iIter ];
			}
			
			return SendBytes( ref bBytes, 0, iCount );
		}// SendBytes()		
	

		//---------------------------------------------------------------------
		// SendText()
		//---------------------------------------------------------------------	
		public bool SendText( string pstrText ) 
		{
            char[] characters = pstrText.ToCharArray();
            byte[] bBytes = new byte[characters.Length];
            
            for ( int iIter = 0; iIter < characters.Length; iIter++ ) {
                bBytes[iIter] = Convert.ToByte( characters[iIter] );
            }

            return SendBytes( ref bBytes, 0, bBytes.Length );
		}// SendText()
	

		//---------------------------------------------------------------------
		// Setup()
		//---------------------------------------------------------------------	
		public void Setup( string pstrPortname, int piBaudrate ) 
		{
            portName = pstrPortname;
            baudrate = piBaudrate;
		}// Setup()	


        //---------------------------------------------------------------------
        // GetPorts()
        // Description: enumerates available ports
        //---------------------------------------------------------------------	
        static public ArrayList GetPorts( ref bool pbSuccess )
        {
            pbSuccess = false;

			IVciDeviceManager IXXAT_deviceManager = null;
            IVciDeviceList IXXAT_deviceList = null;
            IEnumerator IXXAT_deviceEnum = null;
            IVciDevice IXXAT_Device;

            string strPortName;
            ArrayList lstPorts = new ArrayList( 11 );

            try {
                // Get device manager from VCI server
                IXXAT_deviceManager = VciServer.GetDeviceManager();

                // Get the list of installed VCI devices
                IXXAT_deviceList = IXXAT_deviceManager.GetDeviceList();

                // Get enumerator for the list of devices
                IXXAT_deviceEnum = IXXAT_deviceList.GetEnumerator();

                // Get first device
                while ( IXXAT_deviceEnum.MoveNext() ) {
                    IXXAT_Device = IXXAT_deviceEnum.Current as IVciDevice;
                    strPortName = (IXXAT_Device.Description + " " + IXXAT_Device.UniqueHardwareId).Trim( new char[] {'\0'});
                    lstPorts.Add(strPortName);
                };
            
            } catch {
                //clsDebugTextbox.OutputError("Error: No VCI device installed\n");
                return null;
            } finally {
                // Dispose device manager ; it's no longer needed.
                DisposeVciObject_IXXAT(IXXAT_deviceManager);

                // Dispose device list ; it's no longer needed.
                DisposeVciObject_IXXAT(IXXAT_deviceList);

                // Dispose device list ; it's no longer needed.
                DisposeVciObject_IXXAT(IXXAT_deviceEnum);
            }
            
            pbSuccess = true;
            return lstPorts;
        }// GetPorts()


        //---------------------------------------------------------------------
        // DisposeVciObject_IXXAT()
        //---------------------------------------------------------------------
        static void DisposeVciObject_IXXAT( object obj )
        {
            if (null != obj)
            {
                IDisposable dispose = obj as IDisposable;
                if (null != dispose)
                {
                    dispose.Dispose();
                    obj = null;
                }
            }
        }// DisposeVciObject_IXXAT()

	}// Class: clsds30LoaderPortIxxat
}
