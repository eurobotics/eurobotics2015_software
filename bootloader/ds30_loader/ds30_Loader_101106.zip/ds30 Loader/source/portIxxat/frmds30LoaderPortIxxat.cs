﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Ixxat.Vci3;
using Ixxat.Vci3.Bal;
using Ixxat.Vci3.Bal.Can;

namespace ds30Loader
{
    public partial class frmds30LoaderPortIxxat : Form
    {
        //---------------------------------------------------------------------
        // Variables
        //---------------------------------------------------------------------	
        private clsds30LoaderPortIxxat objParentPort = null;

        //   Reference to the used VCI device.
        private IVciDevice IXXAT_Device = null;

        public frmds30LoaderPortIxxat(clsds30LoaderPortIxxat pobjParentPort, IVciDevice pIXXAT_Device)
        {
            InitializeComponent();

            objParentPort = pobjParentPort;
            IXXAT_Device = pIXXAT_Device;

            lblVersion.Text = clsds30LoaderPortIxxat.strVersion;

            lblManufacturer.Text = IXXAT_Device.Manufacturer.ToString();
            lblDrvVersion.Text = IXXAT_Device.DriverVersion.ToString();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            // Close window
            this.Close();
        }

        private void frmds30LoaderPortIxxat_Load(object sender, EventArgs e)
        {

        }
    }
}
