﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  

using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using GHelper;

namespace ds30Loader
{
    //-------------------------------------------------------------------------
    // Class: clsVectorBitRates
    //-------------------------------------------------------------------------
    static public class clsIxxatBitRates
    {
        //---------------------------------------------------------------------
        // Variables
        //---------------------------------------------------------------------
        static private Hashtable htBitRates = null;
        static private bool bIsInitialized = false;
        static public ArrayList lstBitRates = null;

        //---------------------------------------------------------------------
        // Constructor()
        // Description:
        //---------------------------------------------------------------------
        static clsIxxatBitRates()
        {
        }// Constructor()	  		


        //---------------------------------------------------------------------
        // Init()
        // Description:
        //---------------------------------------------------------------------
        static public void Init()
        {
            if (bIsInitialized == true) return;

            bool bImportDbSuccess = false;
            ImportDB("ixxatBitRates.xml", ref bImportDbSuccess);
            if (bImportDbSuccess == false)
            {
                InitInternalDb();
            }

            //
            lstBitRates = new ArrayList(htBitRates.Count);
            foreach (clsIxxatBitRate objIxxatBitRate in htBitRates.Values)
            {
                lstBitRates.Add( (int)objIxxatBitRate.bitRate);
            }

            lstBitRates.Sort();

            bIsInitialized = true;
        }// Constructor()	


        //-------------------------------------------------------------------------
        // ExportDB()
        // Description: 
        //-------------------------------------------------------------------------
        static public void ExportDB(string pstrFileName)
        {
            // 
            clsIxxatBitRate[] lstBitRates = new clsIxxatBitRate[htBitRates.Count];
            int iIndex = 0;
            foreach (clsIxxatBitRate objVectorBitRate in htBitRates.Values)
            {
                lstBitRates[iIndex++] = objVectorBitRate;
            }

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(clsIxxatBitRate[]));
            TextWriter textWriter = new StreamWriter(pstrFileName);

            xmlSerializer.Serialize(textWriter, lstBitRates);
            textWriter.Close();
        }//ExportDB()  


        //-------------------------------------------------------------------------
        // GetBitRate()
        // Description: 
        //-------------------------------------------------------------------------
        static public clsIxxatBitRate GetBitRate(int piBitRate)
        {
            string strBitRate = piBitRate.ToString();
            if (htBitRates.Contains(strBitRate))
            {
                return (clsIxxatBitRate)htBitRates[strBitRate];
            }

            return null;
        }//ExportDB()  


        //-------------------------------------------------------------------------
        // ImportDB()
        // Description: 
        //-------------------------------------------------------------------------
        static private void ImportDB(string pstrFileName, ref bool pbSuccess)
        {
            pbSuccess = false;
            // Check file existence
            if (File.Exists(pstrFileName) == false)
            {
                return;
            }

            clsDebugTextbox.OutputInfo("Loading external Ixxat bit rates database...", 0);

            // Setup serialization objects
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(clsIxxatBitRate[]));
            TextReader textReader = new StreamReader(pstrFileName);
            clsIxxatBitRate[] lstObjBitRates = null;

            // Serialize
            try
            {
                lstObjBitRates = (clsIxxatBitRate[])xmlSerializer.Deserialize(textReader);
            }
            catch
            {
                clsDebugTextbox.OutputResult(false);
                textReader.Close();
                return;
            }
            finally
            {
                textReader.Close();
            }

            // Apply
            htBitRates = new Hashtable(lstObjBitRates.Length);
            if (lstObjBitRates != null)
            {
                foreach (clsIxxatBitRate objIxxatBitRate in lstObjBitRates)
                {
                    htBitRates.Add(objIxxatBitRate.bitRate.ToString(), objIxxatBitRate);
                }
            }

            //
            pbSuccess = true;
            clsDebugTextbox.OutputResult(true);
        }//ImportDB()  


        //---------------------------------------------------------------------
        // InitInternalDb()
        // Description: 
        //---------------------------------------------------------------------
        static public void InitInternalDb()
        {
            htBitRates = new Hashtable(11);

            htBitRates.Clear();
            clsIxxatBitRate objBitRate = null;
            objBitRate = new clsIxxatBitRate(10000, 0x31, 0x1C); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(20000, 0x18, 0x1C); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(50000, 0x09, 0x1C); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(100000, 0x04, 0x1C); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(125000, 0x03, 0x1C); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(250000, 0x01, 0x1C); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(500000, 0x00, 0x1C); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(800000, 0x00, 0x16); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);
            objBitRate = new clsIxxatBitRate(1000000, 0x00, 0x14); htBitRates.Add(objBitRate.bitRate.ToString(), objBitRate);

        }// InitInternalDb()  

    }// Class: clsVectorBitRates
}
