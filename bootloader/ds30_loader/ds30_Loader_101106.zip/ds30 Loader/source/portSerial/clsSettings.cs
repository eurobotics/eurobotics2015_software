﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader GUI.
//
//    ds30 Loader GUI is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader GUI is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader GUI.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace ds30Loader
{
    //---------------------------------------------------------------------------
    // Class: clsSettingsPortSerial
    //---------------------------------------------------------------------------
    [XmlRoot("ds30LoaderPortSerialSettings")]
    public class clsSettingsPortSerial
    {
		//---------------------------------------------------------------------
		// Constructor
        //---------------------------------------------------------------------
        public clsSettingsPortSerial() 
        {
	        humanPortNames = false;
        }// Constructor

        
		//---------------------------------------------------------------------
		// Settings
        //---------------------------------------------------------------------
        public bool humanPortNames { get; set; }
    }// Class: settings
}
