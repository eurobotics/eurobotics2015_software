﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GHelper;

namespace ds30Loader
{
    public partial class frmds30LoaderPortSerial : Form
    {
		//---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
        private clsds30LoaderPortSerial objParentPort = null;


		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
        public frmds30LoaderPortSerial( clsds30LoaderPortSerial pobjParentPort )
        {
            InitializeComponent();
            
            objParentPort = pobjParentPort;

            lblVersion.Text = clsds30LoaderPortSerial.strVersion;

            if ( clsMisc.HostIsWindows() ) {
                // Load settings first
                bool bLoadSettingsResult = false;
                clsSettingsPortSerial objSettings = clsds30LoaderPortSerial.LoadSettings( ref bLoadSettingsResult );
                if ( bLoadSettingsResult == false ) {
                    objSettings = new clsSettingsPortSerial();
                }
                // Apply
                chkHuman.Checked = objSettings.humanPortNames;
            } else {
                chkHuman.Checked = false;
                chkHuman.Enabled = false;
            }
        }// Constructor()


		//---------------------------------------------------------------------
		// btnClose_Click()
		//---------------------------------------------------------------------	
        private void btnClose_Click(object sender, EventArgs e)
        {
            // Save settings
            clsSettingsPortSerial objSettings = new clsSettingsPortSerial();
            objSettings.humanPortNames = chkHuman.Checked;
            objParentPort.SaveSettings( objSettings );

            // Close window
            this.Close();
        }// btnClose_Click()
    }
}
