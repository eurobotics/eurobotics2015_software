﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader serial port
//
// Copyright:		Copyright © 2010, Mikael Gustafsson
//
// Version:			1.0.2 april 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			1.0.2 Fixed dtrEnable and rtsEnable
//                  1.0.1 Added ReadText()
//                  1.0.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
  

using System;
using System.IO.Ports;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

using GHelper;
using ds30Loader;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsds30LoaderPortSerial
	//-------------------------------------------------------------------------
	public class clsds30LoaderPortSerial : clsPortBase, IPort
	{
        //---------------------------------------------------------------------
		// Win32 API
        // These are used to retrieve user friendly port names
        // With help from http://www.pinvoke.net/
		//---------------------------------------------------------------------	
        // Mono has problem with this line
        //private static readonly Guid GUID_DEVCLASS_PORTS = new Guid("{0x4d36e978, 0xe325, 0x11ce, {0xbf, 0xc1, 0x08, 0x00, 0x2b, 0xe1, 0x03, 0x18}}");
        private static Guid GUID_DEVCLASS_PORTS;
        
        [DllImport("setupapi.dll", CharSet = CharSet.Auto)]
        static private extern IntPtr SetupDiGetClassDevs(
            ref Guid ClassGuid,
            [MarshalAs(UnmanagedType.LPTStr)] string Enumerator,
            IntPtr hwndParent,
            UInt32 Flags
        );
 
        [StructLayout(LayoutKind.Sequential)]
        private struct SP_DEVINFO_DATA
        {
            public UInt32 cbSize;
            public Guid ClassGuid;
            public UInt32 DevInst;
            public IntPtr Reserved;
        }  

        [DllImport("setupapi.dll", CharSet=CharSet.Auto, SetLastError = true)]
        public static extern bool SetupDiDestroyDeviceInfoList( IntPtr hDevInfo );

        [DllImport("setupapi.dll", SetLastError=true)]
        static extern private bool SetupDiEnumDeviceInfo(IntPtr DeviceInfoSet, uint MemberIndex, ref SP_DEVINFO_DATA DeviceInfoData);
        
        [DllImport("setupapi.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool SetupDiGetDeviceRegistryProperty(
            IntPtr DeviceInfoSet,
            ref SP_DEVINFO_DATA DeviceInfoData,
            uint Property,
            out UInt32 PropertyRegDataType,
            byte[] PropertyBuffer,
            uint PropertyBufferSize,
            out UInt32 RequiredSize
        );


		//---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
		public SerialPort objPort;
        private Queue queByteSend;
        static private ArrayList lstBaudRates = new ArrayList{ 9600,14400,19200,28800,38400,57600,115200,128000,230400,256000,460800,512000,921600,102400,1843200,2048000 };		
        static public string strVersion = "1.0.2";

        public event clsPortBase.DataReceivedDelegate DataReceived;

		
		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public clsds30LoaderPortSerial() 
		{
            Init();

            string strPath = Application.StartupPath;
			string strSettingsFilename = strPath + Path.DirectorySeparatorChar + "clsSettingsPortSerial.xml"; 
		}// Constructor()


        //---------------------------------------------------------------------
        // Constructor()
        //---------------------------------------------------------------------	
        public clsds30LoaderPortSerial( string pstrPortname, int piBaudrate )
        {
            Init();
            Setup( pstrPortname, piBaudrate );
        }// Constructor()
	

		//---------------------------------------------------------------------
		// Destructor()
        // Description: close port
		//---------------------------------------------------------------------	
		~clsds30LoaderPortSerial() 
		{
            Close();
		}// Destructor()        
		

		//---------------------------------------------------------------------
		// Event: DataReceived
		//---------------------------------------------------------------------
		protected internal void OnDataReceived()
		{
			// ChangedEvent will be null if no client has hooked up a delegate to the event.
			if ( DataReceived != null ) {
				DataReceived( this, null );
			}
		}//Event: ChangesMade	


		//---------------------------------------------------------------------
		// Property: allowCustomBaudRate
		//---------------------------------------------------------------------
		public bool allowCustomBaudRate
		{
			get {
				return true;
			} set {
			}
        }//Property: allowCustomBaudRate 	 
        

		//---------------------------------------------------------------------
		// Property: baudrate
		//---------------------------------------------------------------------
		public int baudrate
		{
			get {
				return objPort.BaudRate;
			} set {
				objPort.BaudRate = value;
			}
        }//Property: baudrate 	        


		//---------------------------------------------------------------------
		// Property: dtrEnable
		//---------------------------------------------------------------------
		public bool dtrEnable
		{
			get {
				return objPort.DtrEnable;
			} set {
                objPort.DtrEnable = value;
            }
        }//Property: dtrEnable          
         
   
		//---------------------------------------------------------------------
		// Property: echoVerification
		//---------------------------------------------------------------------
		public bool echoVerification { get; set; }
            		            		

		//---------------------------------------------------------------------
		// Property: hasWindow
		//---------------------------------------------------------------------
		public bool hasWindow
		{
			get {
                return true;
			}
        }//Property: hasWindow
        
        
        //---------------------------------------------------------------------
		// Property: inBufferCount
		//---------------------------------------------------------------------
		public int inBufferCount
		{
			get {
				if ( objPort.IsOpen == true ) {
                    if ( echoVerification == true ) {
                        bool bEchoReadSuccess = false;
                        EchoRead( ref bEchoReadSuccess );
                        if ( queByteSend.Count > 0 ) {
					        return 0;
                        } else {
                            return objPort.BytesToRead;
                        }
                    } else {
                        return objPort.BytesToRead;
                    }
				} else {
					return -1;
				}
			}
        }//Property: inBufferCount        		
		
		
		//---------------------------------------------------------------------
		// Property: isOpen
		//---------------------------------------------------------------------
		public bool isOpen
		{
			get {
				return objPort.IsOpen;
			}
        }//Property: isOpen 
              		

		//---------------------------------------------------------------------
		// Property: outBufferCount
		//---------------------------------------------------------------------
		public int outBufferCount
		{
			get {
				if ( objPort.IsOpen == true ) {
					return objPort.BytesToWrite;
				} else {
					return -1;
				}
			}
        }//Property: outBufferCount  
       
        		
		//---------------------------------------------------------------------
		// Property: portName
		//---------------------------------------------------------------------
		public string portName
		{
			get {
				return objPort.PortName;
			} set {
				if ( objPort.IsOpen == false ) {
                    if ( value.Contains(")") ) {
                        objPort.PortName = value.Substring( value.IndexOf("COM"), value.IndexOf(')') - value.IndexOf("COM") );
                    } else {
					    objPort.PortName = value;
                    }
				}
			}
        }//Property: portName 	
 

        //---------------------------------------------------------------------
        // Property: portType
        //---------------------------------------------------------------------
        public PortType portType { 
            get {
                return PortType.Serial;
            }
        }// Property: portType
	        
   
		//---------------------------------------------------------------------
		// Property: rtsEnable
		//---------------------------------------------------------------------
		public bool rtsEnable
		{
			get {
				return objPort.RtsEnable;
			} set {
                objPort.RtsEnable = value;
            }
        }//Property: rtsEnable  
  

		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		new public static bool supportsWindows{ get {return true;} }
  

		//---------------------------------------------------------------------
		// Property: supportsLinux
		//---------------------------------------------------------------------
		new public static bool supportsLinux{ get {return true;} }
  

		//---------------------------------------------------------------------
		// Property: supportsMac
		//---------------------------------------------------------------------
		new public static bool supportsMac{ get {return true;} }
	        
   
		//---------------------------------------------------------------------
		// Property: version
		//---------------------------------------------------------------------
		public string version
		{
			get {
				return strVersion;
			}	
        }//Property: version  	

		//---------------------------------------------------------------------
		// Close()
		//---------------------------------------------------------------------	
		public bool Close() 
		{
			if ( objPort.IsOpen == false ) return true;
			try {
				objPort.DataReceived -= new SerialDataReceivedEventHandler( objPort_DataReceived );
                objPort.Close();
			} catch {				
				return false;
			} 
			return !objPort.IsOpen;
		}// Close()
		
				

		//---------------------------------------------------------------------
		// EchoClearQueue()
		//---------------------------------------------------------------------	
		public void EchoClearQueue() 
		{
            queByteSend.Clear();
		}// EchoRead()		
				

		//---------------------------------------------------------------------
		// EchoInject()
		//---------------------------------------------------------------------	
		public void EchoInject( byte bByte) 
		{
            queByteSend.Enqueue( bByte );
		}// EchoInject()		


		//---------------------------------------------------------------------
		// EchoRead()
		//---------------------------------------------------------------------	
		public void EchoRead( ref bool bSuccess ) 
		{
            bSuccess = true;
            byte bSent, bEcho;
            while (queByteSend.Count > 0 && objPort.BytesToRead > 0 ) {
                bSent = (byte)queByteSend.Dequeue();
                bEcho = Convert.ToByte( objPort.ReadByte() );
                if ( bSent != bEcho ) {
                    clsDebugTextbox.OutputError( "echo verification failed ( "+ queByteSend.Count.ToString() + ") 0x" + bSent.ToString("X2") + "/0x" + bEcho.ToString("X2"), 0 );
                    bSuccess = false;
                    return;
                }
            }
		}// EchoRead()	
		
	
		//---------------------------------------------------------------------
		// EmptyBuffers()
		//---------------------------------------------------------------------	
		public void EmptyBuffers( bool bRx, bool bTx ) 
		{
			if ( objPort.IsOpen == true ) {
				// Rx
                if ( bRx == true ) {              
                    objPort.DiscardInBuffer();
                    int iRxDiscardTries=0;
                    while ( objPort.BytesToRead > 0 && iRxDiscardTries++ < 3 ) {
                        objPort.DiscardInBuffer();
                        clsDebugTextbox.OutputWarning( "Uart rx buffer not empty as expected (is device sending data?)", 0 );
                    }
                }

                // Tx
				if ( bTx == true ) {
                    objPort.DiscardOutBuffer();
                }
			}
		}// EmptyBuffers()
		
						
		//---------------------------------------------------------------------
		// GetBaudRates()
		//---------------------------------------------------------------------	
		public ArrayList GetBaudRates() 
		{
			return lstBaudRates;
		}// GetBaudRates()	


        //---------------------------------------------------------------------
        // Init()
        //---------------------------------------------------------------------
        public void Init()
        {
            // Create port object
            objPort = new SerialPort();
            queByteSend = new Queue( 9 );

            // Default settings
            objPort.PortName = "COM1";
            objPort.BaudRate = 9600;
            objPort.DataBits = 8;
            objPort.Parity = Parity.None;
            objPort.StopBits = StopBits.One;

            //
            objPort.ErrorReceived += new SerialErrorReceivedEventHandler( objPortErrorOccured );
                        
            //
            ResetCounters();            
            //ListPorts();
        }// Init()
		
        
        //-------------------------------------------------------------------------
        // LoadSettings()
        // Description: 
        //-------------------------------------------------------------------------
        static public clsSettingsPortSerial LoadSettings( ref bool pbResult ) 
        {
            pbResult = true;
            clsSettingsPortSerial objSettings = null;

            //-----------------------------------------------------------------
			// Filename
            //-----------------------------------------------------------------			
            string strPath = Application.StartupPath;
			string strFilename = strPath + Path.DirectorySeparatorChar + "settingsPortSerial.xml";


			//-----------------------------------------------------------------
			// No previous settings
			//-----------------------------------------------------------------
			if ( File.Exists(strFilename) == false ) {
                objSettings = new clsSettingsPortSerial();

			
			//-----------------------------------------------------------------
			// Load settings
			//-----------------------------------------------------------------            
            } else {            
                //clsDebugTextbox.OutputInfo( "Loading serial port settings...", 0 );

                XmlSerializer xmlSerializer = new XmlSerializer( typeof( clsSettingsPortSerial ) );
                TextReader textReader = new StreamReader( strFilename );
                bool bLoadSettingsFailed = false;
                try {                
                    objSettings = (clsSettingsPortSerial)xmlSerializer.Deserialize( textReader );
                } catch {
                    clsDebugTextbox.OutputResult( false );
                    objSettings = new clsSettingsPortSerial();
                    bLoadSettingsFailed = true;

                }
                if ( textReader != null ) {
                    textReader.Close();
                }
                if ( bLoadSettingsFailed == false ) {
                    //clsDebugTextbox.OutputResult( true );
                }
            } 


			//-----------------------------------------------------------------
			// Finished
			//-----------------------------------------------------------------
            pbResult = ( objSettings != null );
            return objSettings;
		}//LoadSettings()  
		
		
		//---------------------------------------------------------------------
		// objPortErrorOccured()
		//---------------------------------------------------------------------			
		private void objPortErrorOccured( object sender, SerialErrorReceivedEventArgs e )
		{
			// Frame: the hardware detected a framing error
			// Overrun: a character-buffer overrun has occurred. The next character is lost
			// RXOver: an input buffer overflow has occurred. There is either no room in the input buffer, or a character was received after the end-of-file (EOF) character
			// RXParity: the hardware detected a parity error
			// TXFull: the application tried to transmit a character, but the output buffer was full
			
            switch ( e.EventType ) {
			    case SerialError.Frame:
				    clsDebugTextbox.OutputError( "The hardware detected a framing error." );
                    break;

			    case SerialError.Overrun:
				    clsDebugTextbox.OutputError( "A character-buffer overrun has occurred. The next character is lost." );
                    break;

			    case SerialError.RXOver:
				    clsDebugTextbox.OutputError( "An input buffer overflow has occurred. There is either no room in the input buffer, or a character was received after the end-of-file (EOF) character." );
                    break;

			    case SerialError.RXParity:
				    clsDebugTextbox.OutputError( "The hardware detected a parity error." );
                    break;

			    case SerialError.TXFull:
				    clsDebugTextbox.OutputError( "The application tried to transmit a character, but the output buffer was full." );
                    break;
			}
		}// objPortErrorOccured()	


        //---------------------------------------------------------------------
        // GetPorts()
        // Description: enumerates available ports
        //---------------------------------------------------------------------	
        static public ArrayList GetPorts( ref bool pbSuccess )
        {
            ArrayList lstLocalPorts = new ArrayList( 11 );
            pbSuccess = false;

            // Load settings first
            bool bLoadSettingsResult = false;
            clsSettingsPortSerial objSettings = LoadSettings( ref bLoadSettingsResult );
            if ( bLoadSettingsResult == false ) {
                objSettings = new clsSettingsPortSerial();
            }
            
            
            if ( objSettings.humanPortNames == false ) {
                {
                    string[] strPorts = System.IO.Ports.SerialPort.GetPortNames();
                    foreach ( string strPort in strPorts ) {
                        lstLocalPorts.Add( strPort );
                    }
                }
     
                // Usb ports on Mac            
                {
                    if ( clsMisc.HostIsWindows() == false ) {
                        string[] strFilenames = Directory.GetFiles( "/dev", "*usbserial*");
			            foreach ( string strPort in strFilenames ) {
				            lstLocalPorts.Add( strPort );
			            }
                    }
                }

                pbSuccess = true;
            } else {
                lstLocalPorts = GetPortsHuman( ref pbSuccess );
            }
            return lstLocalPorts;
        }// GetPorts()

				
		//---------------------------------------------------------------------
		// GetPortsHuman()
		//---------------------------------------------------------------------			
        static private ArrayList GetPortsHuman( ref bool pbSuccess )
        {
            string Result = string.Empty;
            uint nDevice = 0;
            uint nBytes = 300;
            byte[] retval = new byte[nBytes];
            uint RequiredSize = 0;
            uint PropertyRegDataType = 0;
            IntPtr hDeviceInfo = (IntPtr)0;

            ArrayList lstLocalPorts = new ArrayList( 11 );
            pbSuccess = true;

            GUID_DEVCLASS_PORTS = new Guid( "{0x4d36e978, 0xe325, 0x11ce, {0xbf, 0xc1, 0x08, 0x00, 0x2b, 0xe1, 0x03, 0x18}}" );

            try {
                SP_DEVINFO_DATA devInfoData = new SP_DEVINFO_DATA();
                devInfoData.cbSize = (uint)Marshal.SizeOf(typeof(SP_DEVINFO_DATA));

                hDeviceInfo = SetupDiGetClassDevs(
                    ref GUID_DEVCLASS_PORTS, 
                    null, 
                    IntPtr.Zero, 
                    2);//DIGCF.DIGCF_PRESENT

                while (SetupDiEnumDeviceInfo(hDeviceInfo, nDevice++, ref devInfoData))
                {
                    if ( SetupDiGetDeviceRegistryProperty(
                            hDeviceInfo, 
                            ref devInfoData, 
                            0xC,//SPDRP.SPDRP_FRIENDLYNAME
                            out PropertyRegDataType, 
                            retval, 
                            nBytes, 
                            out RequiredSize)
                    ) {
                        string strPortHuman = System.Text.Encoding.Unicode.GetString( retval );
                        if ( strPortHuman.ToUpper().Contains("COM") ) {
                            lstLocalPorts.Add( strPortHuman );
                        }

                    } // if (PInvoke.SetupDiGetDeviceRegistryProperty( ... SPDRP_FRIENDLYNAME ...            
                
                } // while (PInvoke.SetupDiEnumDeviceInfo(hDeviceInfo, nDevice++, ref devInfoData))
            } catch {
                pbSuccess = false;
            } finally {
                SetupDiDestroyDeviceInfoList( hDeviceInfo );
            }

            return lstLocalPorts; 
        }// GetPortsHuman()
		
				
		//---------------------------------------------------------------------
		// Open()
		//---------------------------------------------------------------------	
		public bool Open() 
		{
			if ( objPort.IsOpen == true ) return true;
			try {
				objPort.Open();
                objPort.DataReceived +=new SerialDataReceivedEventHandler(objPort_DataReceived);
			} catch {				
				//return false;
			}
			return objPort.IsOpen;
		}// Open()
	
		
						
		//---------------------------------------------------------------------
		// OpenWindow()
		//---------------------------------------------------------------------	
		public void OpenWindow( System.Windows.Forms.Form pwndOwner ) 
		{	
            frmds30LoaderPortSerial wndSettings = new frmds30LoaderPortSerial( this );
            wndSettings.ShowDialog( pwndOwner );		
		}// OpenWindow()
		
		
		//---------------------------------------------------------------------
		// ReadByte()
		//---------------------------------------------------------------------	
		public bool ReadByte(ref int iByte) 
		{
            // Handle echo
            if ( echoVerification == true ) {
                bool bReadEchoSuccess = false;
                EchoRead( ref bReadEchoSuccess );
                if ( bReadEchoSuccess == false || queByteSend.Count > 0) {
                    return false;
                }
            }

            //
			objPort.ReadTimeout = 3000;
			
			try {
				iByte = objPort.ReadByte();
                ++iBytesReceived;
			} catch ( TimeoutException ) {
				clsDebugTextbox.OutputError( "receive timeout" );
				return false;
			} catch {
				clsDebugTextbox.OutputError( "receive exception" );
				return false;
			}		
			
			return true;		
		}// ReadByte()

		
        //---------------------------------------------------------------------
		// ReadBytes()
		//---------------------------------------------------------------------	
		public bool ReadBytes( ref byte []iBytes, int iCount ) 
		{
            // Handle echo
            if ( echoVerification == true ) {
                bool bReadEchoSuccess = false;
                EchoRead( ref bReadEchoSuccess );
                if ( bReadEchoSuccess == false || queByteSend.Count > 0 ) {
                    return false;
                }
            }

			objPort.ReadTimeout = 1000 + iCount / (baudrate / 8) * 2;
			
			byte [] bBytes = new byte [ iCount ];
			
			try {
				objPort.Read(bBytes, 0, iCount );
                iBytesReceived += iCount;
			} catch ( TimeoutException ) {
				clsDebugTextbox.OutputError( "receive timed out" );
				return false;
			} catch {
				clsDebugTextbox.OutputError( "receive exception" );
				return false;
			}
			
			for ( int iIter = 0; iIter < iCount; iIter++ ) {
				iBytes[ iIter ] = bBytes[ iIter ];
			}	
			return true;		
		}// ReadBytes()
		
				
		//---------------------------------------------------------------------
		// ReadBytes()
		//---------------------------------------------------------------------	
		public bool ReadBytes( ref int []iBytes, int iCount ) 
		{
            // Handle echo
            if ( echoVerification == true ) {
                bool bReadEchoSuccess = false;
                EchoRead( ref bReadEchoSuccess );
                if ( bReadEchoSuccess == false || queByteSend.Count > 0 ) {
                    return false;
                }
            }

			objPort.ReadTimeout = 1000 + iCount / (baudrate / 8) * 2;
			
			byte [] bBytes = new byte [ iCount ];
			
			try {
				objPort.Read(bBytes, 0, iCount );
                iBytesReceived += iCount;
			} catch ( TimeoutException ) {
				clsDebugTextbox.OutputError( "receive timed out" );
				return false;
			} catch {
				clsDebugTextbox.OutputError( "receive exception" );
				return false;
			}
			
			for ( int iIter = 0; iIter < iCount; iIter++ ) {
				iBytes[ iIter ] = (int)bBytes[ iIter ];
			}	
			return true;		
		}// ReadBytes()
		
						
		//---------------------------------------------------------------------
		// ReadInt16()
		//---------------------------------------------------------------------	
		public bool ReadInt16( ref int iInteger ) 
		{
			int [] bBytes = new int[ 2 ];
			if ( ReadBytes(ref bBytes, 2) == false ) {
				return false;
			}
			
			iInteger = (bBytes[0] << 8) + bBytes[1];
			return true;
		}// ReadInt16()						
  		
						
		//---------------------------------------------------------------------
		// ReadText()
		//---------------------------------------------------------------------	
		public string ReadText( ref bool pbResult ) 
		{
			if ( objPort.BytesToRead == 0 ) {
                pbResult = false;
                return string.Empty;
            }

            pbResult = true;
            return objPort.ReadExisting();
		}// ReadText()
      

        //-------------------------------------------------------------------------
		// SaveSettings()
		// Description: 
		//-------------------------------------------------------------------------
		public void SaveSettings( clsSettingsPortSerial pobjSettings)
		{	            
            clsSettingsPortSerial objSettings = new clsSettingsPortSerial();

            //-----------------------------------------------------------------
			// Filename
            //-----------------------------------------------------------------			
            string strPath = Application.StartupPath;
			string strFilename = strPath + Path.DirectorySeparatorChar + "settingsPortSerial.xml";
 
            
            //-----------------------------------------------------------------
            // Serialize
            //-----------------------------------------------------------------           
            XmlSerializer xmlSerializer = new XmlSerializer( typeof(clsSettingsPortSerial) );
            TextWriter textWriter = new StreamWriter( strFilename );
            xmlSerializer.Serialize( textWriter, pobjSettings );
            textWriter.Close();
		}//SaveSettings()      
		
				
		//---------------------------------------------------------------------
		// SendByte()
		//---------------------------------------------------------------------	
		public bool SendByte( byte bByte ) 
		{
			if ( isOpen == false ) {
				return false;
			}

			byte[] cCByteArray = new byte[1];
			cCByteArray[0] = bByte;		
			try {
				objPort.Write( cCByteArray, 0, 1 );                
                ++iBytesSent;
			} catch {
				return false;
			}
            
            if ( echoVerification == true ) {
                queByteSend.Enqueue( bByte );
            }
			return true;
		}// SendByte()			
				
						
		//---------------------------------------------------------------------
		// SendByte()
		//---------------------------------------------------------------------	
		public bool SendByte( int iByte ) 
		{
			return SendByte( Convert.ToByte(iByte) );
		}// SendByte()	
		
		
		//---------------------------------------------------------------------
		// SendBytes()
		//---------------------------------------------------------------------	
		public bool SendBytes( ref byte[] bBytes, int iOffset, int iCount ) 
		{
			if ( isOpen == false ) {
				return false;
			}
			
			try {
				objPort.Write( bBytes, iOffset, iCount );
                iBytesSent += iCount;
			} catch {
				return false;
			}
            
            if ( echoVerification == true ) {
                for ( int iIter = 0; iIter < iCount; iIter++ ) {
                    queByteSend.Enqueue( bBytes[iIter] );
                }
            }
			return true;
		}// SendBytes()		
				
		
		//---------------------------------------------------------------------
		// SendBytes()
		//---------------------------------------------------------------------	
		public bool SendBytes( ref int[] iBytes, int iOffset, int iCount ) 
		{
			byte [] bBytes = new byte [ iCount ];
			for ( int iIter = 0; iIter < iCount; iIter++ ) {
				bBytes[ iIter ] = (byte)iBytes[ iIter ];
			}
			
			return SendBytes( ref bBytes, iOffset, iCount );
		}// SendBytes()		
							
						
		//---------------------------------------------------------------------
		// SendText()
		//---------------------------------------------------------------------	
		public bool SendText( string pstrText ) 
		{
            try {
                objPort.Write( pstrText );
            } catch {
                return false;
            }
            return true;
		}// SendText()	
		

		//---------------------------------------------------------------------
		// Setup()
		//---------------------------------------------------------------------	
		public void Setup( string pstrPortname, int piBaudrate ) 
		{
			if ( isOpen == true ) return;
			
			try {
				portName = pstrPortname;
			} catch {
				clsDebugTextbox.OutputError( "Error setting port to " + pstrPortname, 0 );
			}
			
			try {
				baudrate = piBaudrate;
			} catch {			
				clsDebugTextbox.OutputError( "Error setting baudrate to " + piBaudrate.ToString(), 0 );
			}
		}// Setup()		

        
        //---------------------------------------------------------------------
		// objPort_DataReceived()
		//---------------------------------------------------------------------
        void objPort_DataReceived( object sender, EventArgs e )
        {
            OnDataReceived();
        }// objPort_DataReceived()        

	}// Class: clsds30LoaderPortSerial
}
