﻿namespace ds30_Loader_GUI
{
    partial class frmInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpDevice = new System.Windows.Forms.GroupBox();
            this.grpHex = new System.Windows.Forms.GroupBox();
            this.grpBootloader = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // grpDevice
            // 
            this.grpDevice.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpDevice.Location = new System.Drawing.Point(0, 0);
            this.grpDevice.Name = "grpDevice";
            this.grpDevice.Size = new System.Drawing.Size(200, 107);
            this.grpDevice.TabIndex = 0;
            this.grpDevice.TabStop = false;
            this.grpDevice.Text = "Device";
            // 
            // grpHex
            // 
            this.grpHex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpHex.Location = new System.Drawing.Point(0, 113);
            this.grpHex.Name = "grpHex";
            this.grpHex.Size = new System.Drawing.Size(200, 100);
            this.grpHex.TabIndex = 0;
            this.grpHex.TabStop = false;
            this.grpHex.Text = "Hex-file";
            // 
            // grpBootloader
            // 
            this.grpBootloader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpBootloader.Location = new System.Drawing.Point(0, 229);
            this.grpBootloader.Name = "grpBootloader";
            this.grpBootloader.Size = new System.Drawing.Size(200, 100);
            this.grpBootloader.TabIndex = 0;
            this.grpBootloader.TabStop = false;
            this.grpBootloader.Text = "Bootloader (default)";
            // 
            // frmInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(201, 339);
            this.ControlBox = false;
            this.Controls.Add(this.grpBootloader);
            this.Controls.Add(this.grpHex);
            this.Controls.Add(this.grpDevice);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmInfo";
            this.ShowInTaskbar = false;
            this.Text = "Info";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpDevice;
        private System.Windows.Forms.GroupBox grpHex;
        private System.Windows.Forms.GroupBox grpBootloader;
    }
}