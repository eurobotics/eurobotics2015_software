﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using ds30Loader;
using System.IO;
using System.Collections;
using System.Diagnostics;

namespace ds30_Loader_GUI
{
    //---------------------------------------------------------------------------
    // Class: frmAbout
    //---------------------------------------------------------------------------
    partial class frmAbout : Form
    {
        private clsSettings objSettings = null;
        //private clsLatestVersionInfo objLatestVersionInfo = null;


        //-----------------------------------------------------------------------
        // Constructor()
        //-----------------------------------------------------------------------
        public frmAbout( ref clsSettings pobjSettings )
        {
            //
            InitializeComponent();

            //
            objSettings  = pobjSettings;

            //
            chkCheckVerStart.Checked = objSettings.CheckVerStart;
            
            // Base path
            string strBasePath = Application.StartupPath;
            if ( strBasePath.EndsWith(Path.DirectorySeparatorChar.ToString()) == false ) {
                strBasePath += Path.DirectorySeparatorChar;
            }

            // Base
            {
                ListViewItem objListViewItem;
                string [] strFiles = new string [3] { "ds30 Loader GUI.exe", "ds30 Loader.dll", "GHelper.dll" };
                FileVersionInfo fileInfo = null;

                foreach ( string strFileName in strFiles ) {
                    try {
                        fileInfo = FileVersionInfo.GetVersionInfo( strFileName );
                    } catch {
                        fileInfo = null;
                    } finally {
                        objListViewItem = lstBase.Items.Add( Path.GetFileName(strFileName) );
                        if ( fileInfo != null ) {
                            objListViewItem.SubItems.Add( fileInfo.ProductVersion );
                        } else {
                            objListViewItem.SubItems.Add( "?" );
                        }
                        objListViewItem.SubItems.Add( "-" );
                    }
                }

                // Resize columns
                foreach ( ColumnHeader header in lstBase.Columns ) {
                    header.AutoResize( header.Index == 0 ? ColumnHeaderAutoResizeStyle.ColumnContent : ColumnHeaderAutoResizeStyle.HeaderSize );
                }
            }

            // Read plugins            
            {
                ListViewItem objListViewItem;
                string [] strPortFiles = clsds30LoaderPorts.GetPortFiles( strBasePath );
                FileVersionInfo fileInfo = null;

                foreach ( string strFileName in strPortFiles ) {
                    try {
                        fileInfo = FileVersionInfo.GetVersionInfo( strFileName );
                    } catch {
                        fileInfo = null;
                    } finally {
                        objListViewItem = lstPorts.Items.Add( Path.GetFileName(strFileName) );
                        if ( fileInfo != null ) {
                            objListViewItem.SubItems.Add( fileInfo.ProductVersion );
                        } else {
                            objListViewItem.SubItems.Add( "?" );
                        }
                        objListViewItem.SubItems.Add( "-" );
                    }
                }

                // Apply current settings
                /*if ( objSettings.EnabledPorts != null ) {
                    foreach ( string strEnabledPort in objSettings.EnabledPorts ) {
                        foreach ( ListViewItem item in lstPorts.Items ) {
                            if ( item.Text == strEnabledPort ) {
                                item.Checked = true;
                            }
                        }
                    }
                }*/

                // Resize columns
                foreach ( ColumnHeader header in lstPorts.Columns ) {                    
                    header.AutoResize( header.Index == 0 ? ColumnHeaderAutoResizeStyle.ColumnContent : ColumnHeaderAutoResizeStyle.HeaderSize );
                }
            }
        }// Constructor()
        
        
        //---------------------------------------------------------------------
		// CheckLatestVersion()
		// Description:
		//---------------------------------------------------------------------
        public void CheckLatestVersion()		
        {   
            /*if ( objLatestVersionInfo.CheckLatestVersion() == false ) {
                lblLVds30Loader.Text = "unknown";
                lblLVds30LoaderGUI.Text = "unknown";
                btnDownload.Enabled = false;
                btnUpdate.Enabled = false;
                txtMessage.Text = objLatestVersionInfo.latestVersionInfo;

            } else {
                lblLVds30Loader.Text = objLatestVersionInfo.verds30Loader.ToString();
                lblLVds30LoaderGUI.Text = objLatestVersionInfo.verds30LoaderGUI.ToString();                

                // A new version is availible
                bool bNewGuiAvailable = frmDS30Loader.verGUI < objLatestVersionInfo.verds30LoaderGUI;
                bool bNewEngineAvailable = new Version(clsds30Loader.strVersion) < objLatestVersionInfo.verds30Loader;

                if ( bNewGuiAvailable || bNewEngineAvailable ) {
                    this.Text = "A new version is available";
                    btnDownload.Enabled = objLatestVersionInfo.allowDownload;
                    btnUpdate.Enabled = objLatestVersionInfo.allowUpdate;
                    
                    if ( bNewGuiAvailable ) {
                        lblLVds30LoaderGUI.BackColor = Color.LightGreen;
                    }

                    if ( bNewEngineAvailable ) {
                        lblLVds30Loader.BackColor = Color.LightGreen;
                    }

                    txtMessage.Text = objLatestVersionInfo.latestVersionInfo;
                
                // This is the latest version
                } else {
                    this.Text = txtMessage.Text = "This is the latest version";
                    btnDownload.Enabled = false;
                    btnUpdate.Enabled = false;
                }
            }*/
        }// CheckLatestVersion()


        //-----------------------------------------------------------------------
        // btnVisitHomepage_Click()
        //-----------------------------------------------------------------------
        private void btnVisitHomepage_Click(object sender, EventArgs e)
        {
            frmDS30Loader.VisitHomepage();
        }// btnVisitHomepage_Click()


        //-----------------------------------------------------------------------
        // btnClose_Click()
        //-----------------------------------------------------------------------
        private void btnClose_Click(object sender, EventArgs e)
        {
            // Count enabled ports
            /*int iEnabledItems = 0;
            for ( int iPort = 0; iPort < lstPorts.Items.Count; iPort++ ) {
                if ( lstPorts.Items[iPort].Checked ) {
                    ++iEnabledItems;
                }    
            }*/

            // Resize enabled ports string array
            /*objSettings.EnabledPorts = new string [iEnabledItems];

            //
            iEnabledItems = 0;
            for ( int iPort = 0; iPort < lstPorts.Items.Count; iPort++ ) {
                if ( lstPorts.Items[iPort].Checked ) {
                    objSettings.EnabledPorts[iEnabledItems++] = lstPorts.Items[iPort].Text;
                }    
            }*/

            this.Close();
        }// btnClose_Click(


        //-----------------------------------------------------------------------
        // btnClose_Click()
        //-----------------------------------------------------------------------
        private void chkCheckVerStart_CheckedChanged(object sender, EventArgs e)
        {
            objSettings.CheckVerStart = chkCheckVerStart.Checked;
        }// btnClose_Click()

    }// Class: frmAbout
}
