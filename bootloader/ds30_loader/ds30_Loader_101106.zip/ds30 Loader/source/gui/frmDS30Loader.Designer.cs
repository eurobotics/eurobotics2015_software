﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader GUI.
//
//    ds30 Loader GUI is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader GUI is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader GUI.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 

namespace ds30_Loader_GUI
{
	partial class frmDS30Loader
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && ( components != null ) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDS30Loader));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOptions = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOptDebugmode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOptResetSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCommands = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCmdAbort = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCmdDownload = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCmdCheckForBl = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCmdReparse = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuView = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewMicro = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewOntop = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewAdvanced = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewInfoWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuHelpVisitHomepage = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblCopyright = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblGPL = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblVersion = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.cboBaudrate = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblBaudRate = new System.Windows.Forms.Label();
            this.cboPort = new System.Windows.Forms.ComboBox();
            this.cboFamily = new System.Windows.Forms.ComboBox();
            this.cboDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.txtInfo = new System.Windows.Forms.RichTextBox();
            this.chkWriteConfigs = new System.Windows.Forms.CheckBox();
            this.chkNoGoto = new System.Windows.Forms.CheckBox();
            this.chkWriteEeprom = new System.Windows.Forms.CheckBox();
            this.chkWriteProgram = new System.Windows.Forms.CheckBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.btnDownload2 = new System.Windows.Forms.ToolStripButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabBasic = new System.Windows.Forms.TabPage();
            this.btnPortSettings = new System.Windows.Forms.Button();
            this.cboLocalId = new System.Windows.Forms.ComboBox();
            this.cboRemoteId = new System.Windows.Forms.ComboBox();
            this.lblGUIId = new System.Windows.Forms.Label();
            this.lbPICId = new System.Windows.Forms.Label();
            this.cboFiles = new System.Windows.Forms.ComboBox();
            this.mnuRecentFile = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuRecentFileRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.tabAdvanced = new System.Windows.Forms.TabPage();
            this.chkAddCRC = new System.Windows.Forms.CheckBox();
            this.chkEcho = new System.Windows.Forms.CheckBox();
            this.chkAutoBaud = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblSize = new System.Windows.Forms.Label();
            this.lblPlacement = new System.Windows.Forms.Label();
            this.txtCustomBlSizeP = new System.Windows.Forms.TextBox();
            this.txtCustomBlPlacementP = new System.Windows.Forms.TextBox();
            this.chkAllowBlOverwrite = new System.Windows.Forms.CheckBox();
            this.chkCustomBl = new System.Windows.Forms.CheckBox();
            this.tabTiming = new System.Windows.Forms.TabPage();
            this.txtTimeout = new System.Windows.Forms.TextBox();
            this.txtPolltime = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabReset = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.cboResetBaudrate = new System.Windows.Forms.ComboBox();
            this.lblIncorrectFormat = new System.Windows.Forms.Label();
            this.txtResettime = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtResetCommand = new System.Windows.Forms.TextBox();
            this.rdbResetCommand = new System.Windows.Forms.RadioButton();
            this.rdbResetRts = new System.Windows.Forms.RadioButton();
            this.rdbResetDtr = new System.Windows.Forms.RadioButton();
            this.rdbResetManual = new System.Windows.Forms.RadioButton();
            this.tabActivation = new System.Windows.Forms.TabPage();
            this.rdbActivateNone = new System.Windows.Forms.RadioButton();
            this.rdbActivateRTS = new System.Windows.Forms.RadioButton();
            this.rdbActivateDTR = new System.Windows.Forms.RadioButton();
            this.tabTerminal = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.lblTxCRC = new System.Windows.Forms.Label();
            this.cboTermTxType = new System.Windows.Forms.ComboBox();
            this.cborTermRxType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnTermClearRx = new System.Windows.Forms.Button();
            this.txtTermTx = new System.Windows.Forms.TextBox();
            this.txtTermRx = new System.Windows.Forms.TextBox();
            this.btnTermClose = new System.Windows.Forms.Button();
            this.chkTermSwitchTo = new System.Windows.Forms.CheckBox();
            this.btnTermOpen = new System.Windows.Forms.Button();
            this.cboTermBaudrate = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabTest = new System.Windows.Forms.TabPage();
            this.btnExportDeviceDb = new System.Windows.Forms.Button();
            this.cboTestResponse = new System.Windows.Forms.ComboBox();
            this.txtTestFwVersion = new System.Windows.Forms.TextBox();
            this.chkTestEnable = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.btnCheck = new System.Windows.Forms.ToolStripButton();
            this.btnDownload = new System.Windows.Forms.ToolStripButton();
            this.btnReparseHexFile = new System.Windows.Forms.ToolStripButton();
            this.btnAbort = new System.Windows.Forms.ToolStripButton();
            this.btnShowOutput = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.picHexContent = new System.Windows.Forms.PictureBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.mnuViewSettingsDir = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabBasic.SuspendLayout();
            this.mnuRecentFile.SuspendLayout();
            this.tabAdvanced.SuspendLayout();
            this.tabTiming.SuspendLayout();
            this.tabReset.SuspendLayout();
            this.tabActivation.SuspendLayout();
            this.tabTerminal.SuspendLayout();
            this.tabTest.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picHexContent)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuOptions,
            this.mnuCommands,
            this.mnuView,
            this.mnuHelp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(352, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFileExit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(37, 20);
            this.mnuFile.Text = "&File";
            // 
            // mnuFileExit
            // 
            this.mnuFileExit.Name = "mnuFileExit";
            this.mnuFileExit.Size = new System.Drawing.Size(92, 22);
            this.mnuFileExit.Text = "E&xit";
            this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
            // 
            // mnuOptions
            // 
            this.mnuOptions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOptDebugmode,
            this.mnuOptResetSettings});
            this.mnuOptions.Name = "mnuOptions";
            this.mnuOptions.Size = new System.Drawing.Size(61, 20);
            this.mnuOptions.Text = "&Options";
            // 
            // mnuOptDebugmode
            // 
            this.mnuOptDebugmode.Checked = true;
            this.mnuOptDebugmode.CheckOnClick = true;
            this.mnuOptDebugmode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.mnuOptDebugmode.Name = "mnuOptDebugmode";
            this.mnuOptDebugmode.Size = new System.Drawing.Size(215, 22);
            this.mnuOptDebugmode.Text = "&Debug mode";
            this.mnuOptDebugmode.CheckedChanged += new System.EventHandler(this.mnuEditDebugmode_CheckedChanged);
            // 
            // mnuOptResetSettings
            // 
            this.mnuOptResetSettings.Name = "mnuOptResetSettings";
            this.mnuOptResetSettings.Size = new System.Drawing.Size(215, 22);
            this.mnuOptResetSettings.Text = "Reset all settings to default";
            this.mnuOptResetSettings.Click += new System.EventHandler(this.mnuOptResetSettings_Click);
            // 
            // mnuCommands
            // 
            this.mnuCommands.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCmdAbort,
            this.mnuCmdDownload,
            this.mnuCmdCheckForBl,
            this.mnuCmdReparse});
            this.mnuCommands.Name = "mnuCommands";
            this.mnuCommands.Size = new System.Drawing.Size(81, 20);
            this.mnuCommands.Text = "&Commands";
            // 
            // mnuCmdAbort
            // 
            this.mnuCmdAbort.Enabled = false;
            this.mnuCmdAbort.Name = "mnuCmdAbort";
            this.mnuCmdAbort.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.mnuCmdAbort.Size = new System.Drawing.Size(186, 22);
            this.mnuCmdAbort.Text = "&Abort";
            this.mnuCmdAbort.Click += new System.EventHandler(this.mnuCmdAbort_Click);
            // 
            // mnuCmdDownload
            // 
            this.mnuCmdDownload.Name = "mnuCmdDownload";
            this.mnuCmdDownload.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.mnuCmdDownload.Size = new System.Drawing.Size(186, 22);
            this.mnuCmdDownload.Text = "&Download";
            this.mnuCmdDownload.Click += new System.EventHandler(this.mnuCmdDownload_Click);
            // 
            // mnuCmdCheckForBl
            // 
            this.mnuCmdCheckForBl.Name = "mnuCmdCheckForBl";
            this.mnuCmdCheckForBl.Size = new System.Drawing.Size(186, 22);
            this.mnuCmdCheckForBl.Text = "Check for bootloader";
            this.mnuCmdCheckForBl.Click += new System.EventHandler(this.mnuCmdCheckForBl_Click);
            // 
            // mnuCmdReparse
            // 
            this.mnuCmdReparse.Name = "mnuCmdReparse";
            this.mnuCmdReparse.Size = new System.Drawing.Size(186, 22);
            this.mnuCmdReparse.Text = "Reparse hex-file";
            this.mnuCmdReparse.Click += new System.EventHandler(this.mnuCmdReparse_Click);
            // 
            // mnuView
            // 
            this.mnuView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuViewMicro,
            this.mnuViewOntop,
            this.mnuViewAdvanced,
            this.mnuViewInfoWindow,
            this.mnuViewSettingsDir});
            this.mnuView.Name = "mnuView";
            this.mnuView.Size = new System.Drawing.Size(44, 20);
            this.mnuView.Text = "&View";
            // 
            // mnuViewMicro
            // 
            this.mnuViewMicro.Name = "mnuViewMicro";
            this.mnuViewMicro.ShortcutKeys = System.Windows.Forms.Keys.F11;
            this.mnuViewMicro.Size = new System.Drawing.Size(174, 22);
            this.mnuViewMicro.Text = "&Micro";
            this.mnuViewMicro.Visible = false;
            this.mnuViewMicro.Click += new System.EventHandler(this.mnuViewMicro_Click);
            // 
            // mnuViewOntop
            // 
            this.mnuViewOntop.CheckOnClick = true;
            this.mnuViewOntop.Name = "mnuViewOntop";
            this.mnuViewOntop.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.mnuViewOntop.Size = new System.Drawing.Size(174, 22);
            this.mnuViewOntop.Text = "&Always on top";
            this.mnuViewOntop.CheckedChanged += new System.EventHandler(this.mnuViewOntop_CheckedChanged);
            // 
            // mnuViewAdvanced
            // 
            this.mnuViewAdvanced.Checked = true;
            this.mnuViewAdvanced.CheckOnClick = true;
            this.mnuViewAdvanced.CheckState = System.Windows.Forms.CheckState.Checked;
            this.mnuViewAdvanced.Name = "mnuViewAdvanced";
            this.mnuViewAdvanced.Size = new System.Drawing.Size(174, 22);
            this.mnuViewAdvanced.Text = "A&dvanced mode";
            this.mnuViewAdvanced.CheckedChanged += new System.EventHandler(this.mnuViewAdvanced_CheckedChanged);
            // 
            // mnuViewInfoWindow
            // 
            this.mnuViewInfoWindow.CheckOnClick = true;
            this.mnuViewInfoWindow.Name = "mnuViewInfoWindow";
            this.mnuViewInfoWindow.Size = new System.Drawing.Size(174, 22);
            this.mnuViewInfoWindow.Text = "Info window";
            this.mnuViewInfoWindow.CheckedChanged += new System.EventHandler(this.mnuViewInfoWindow_CheckedChanged);
            // 
            // mnuHelp
            // 
            this.mnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.mnuHelpVisitHomepage,
            this.toolStripMenuItem1,
            this.mnuHelpAbout});
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(44, 20);
            this.mnuHelp.Text = "&Help";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(153, 6);
            this.toolStripMenuItem2.Visible = false;
            // 
            // mnuHelpVisitHomepage
            // 
            this.mnuHelpVisitHomepage.Name = "mnuHelpVisitHomepage";
            this.mnuHelpVisitHomepage.Size = new System.Drawing.Size(156, 22);
            this.mnuHelpVisitHomepage.Text = "&Visit homepage";
            this.mnuHelpVisitHomepage.Click += new System.EventHandler(this.mnuHelpVisitHomepage_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(153, 6);
            // 
            // mnuHelpAbout
            // 
            this.mnuHelpAbout.Name = "mnuHelpAbout";
            this.mnuHelpAbout.Size = new System.Drawing.Size(156, 22);
            this.mnuHelpAbout.Text = "&About...";
            this.mnuHelpAbout.Click += new System.EventHandler(this.mnuHelpAbout_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblCopyright,
            this.lblGPL,
            this.lblVersion});
            this.statusStrip1.Location = new System.Drawing.Point(0, 399);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(352, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblCopyright
            // 
            this.lblCopyright.Name = "lblCopyright";
            this.lblCopyright.Size = new System.Drawing.Size(229, 17);
            this.lblCopyright.Spring = true;
            this.lblCopyright.Text = "Copyright © 08-10, Mikael Gustafsson";
            this.lblCopyright.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblGPL
            // 
            this.lblGPL.Name = "lblGPL";
            this.lblGPL.Size = new System.Drawing.Size(77, 17);
            this.lblGPL.Text = "GPL Licensed";
            // 
            // lblVersion
            // 
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(31, 17);
            this.lblVersion.Text = "1.2.2";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBrowse.Location = new System.Drawing.Point(285, 11);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(24, 20);
            this.btnBrowse.TabIndex = 5;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // cboBaudrate
            // 
            this.cboBaudrate.FormattingEnabled = true;
            this.cboBaudrate.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "56000",
            "57600",
            "115200",
            "128000",
            "256000"});
            this.cboBaudrate.Location = new System.Drawing.Point(67, 64);
            this.cboBaudrate.Name = "cboBaudrate";
            this.cboBaudrate.Size = new System.Drawing.Size(82, 21);
            this.cboBaudrate.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Device:";
            // 
            // lblBaudRate
            // 
            this.lblBaudRate.AutoSize = true;
            this.lblBaudRate.Location = new System.Drawing.Point(11, 67);
            this.lblBaudRate.Name = "lblBaudRate";
            this.lblBaudRate.Size = new System.Drawing.Size(53, 13);
            this.lblBaudRate.TabIndex = 9;
            this.lblBaudRate.Text = "Baudrate:";
            // 
            // cboPort
            // 
            this.cboPort.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboPort.FormattingEnabled = true;
            this.cboPort.Location = new System.Drawing.Point(190, 64);
            this.cboPort.Name = "cboPort";
            this.cboPort.Size = new System.Drawing.Size(119, 21);
            this.cboPort.TabIndex = 9;
            this.cboPort.SelectedIndexChanged += new System.EventHandler(this.cboPort_SelectedIndexChanged);
            this.cboPort.Leave += new System.EventHandler(this.cboPort_Leave);
            this.cboPort.TextChanged += new System.EventHandler(this.cboPort_TextChanged);
            // 
            // cboFamily
            // 
            this.cboFamily.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFamily.FormattingEnabled = true;
            this.cboFamily.Location = new System.Drawing.Point(67, 37);
            this.cboFamily.Name = "cboFamily";
            this.cboFamily.Size = new System.Drawing.Size(82, 21);
            this.cboFamily.Sorted = true;
            this.cboFamily.TabIndex = 6;
            this.cboFamily.SelectedIndexChanged += new System.EventHandler(this.cboFamily_SelectedIndexChanged);
            // 
            // cboDevice
            // 
            this.cboDevice.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboDevice.DropDownHeight = 400;
            this.cboDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDevice.FormattingEnabled = true;
            this.cboDevice.IntegralHeight = false;
            this.cboDevice.Location = new System.Drawing.Point(155, 37);
            this.cboDevice.MaximumSize = new System.Drawing.Size(154, 0);
            this.cboDevice.MinimumSize = new System.Drawing.Size(154, 0);
            this.cboDevice.Name = "cboDevice";
            this.cboDevice.Size = new System.Drawing.Size(154, 21);
            this.cboDevice.Sorted = true;
            this.cboDevice.TabIndex = 7;
            this.cboDevice.SelectedIndexChanged += new System.EventHandler(this.cboDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Hex-file:";
            // 
            // progressBar
            // 
            this.progressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar.Location = new System.Drawing.Point(271, 7);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(69, 10);
            this.progressBar.TabIndex = 7;
            this.progressBar.Value = 50;
            // 
            // txtInfo
            // 
            this.txtInfo.BackColor = System.Drawing.SystemColors.Window;
            this.txtInfo.DetectUrls = false;
            this.txtInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtInfo.Location = new System.Drawing.Point(0, 0);
            this.txtInfo.Name = "txtInfo";
            this.txtInfo.ReadOnly = true;
            this.txtInfo.ShortcutsEnabled = false;
            this.txtInfo.Size = new System.Drawing.Size(298, 149);
            this.txtInfo.TabIndex = 3;
            this.txtInfo.Text = "";
            this.txtInfo.WordWrap = false;
            this.txtInfo.TextChanged += new System.EventHandler(this.txtInfo_TextChanged);
            // 
            // chkWriteConfigs
            // 
            this.chkWriteConfigs.AutoSize = true;
            this.chkWriteConfigs.Location = new System.Drawing.Point(11, 60);
            this.chkWriteConfigs.Name = "chkWriteConfigs";
            this.chkWriteConfigs.Size = new System.Drawing.Size(88, 17);
            this.chkWriteConfigs.TabIndex = 13;
            this.chkWriteConfigs.Text = "Write configs";
            this.chkWriteConfigs.UseVisualStyleBackColor = true;
            // 
            // chkNoGoto
            // 
            this.chkNoGoto.AutoSize = true;
            this.chkNoGoto.Location = new System.Drawing.Point(11, 14);
            this.chkNoGoto.Name = "chkNoGoto";
            this.chkNoGoto.Size = new System.Drawing.Size(138, 17);
            this.chkNoGoto.TabIndex = 12;
            this.chkNoGoto.Text = "Don\'t write goto at 0x00";
            this.chkNoGoto.UseVisualStyleBackColor = true;
            this.chkNoGoto.CheckedChanged += new System.EventHandler(this.chkNoGoto_CheckedChanged);
            // 
            // chkWriteEeprom
            // 
            this.chkWriteEeprom.AutoSize = true;
            this.chkWriteEeprom.Location = new System.Drawing.Point(14, 118);
            this.chkWriteEeprom.Name = "chkWriteEeprom";
            this.chkWriteEeprom.Size = new System.Drawing.Size(90, 17);
            this.chkWriteEeprom.TabIndex = 11;
            this.chkWriteEeprom.Text = "Write Eeprom";
            this.chkWriteEeprom.UseVisualStyleBackColor = true;
            // 
            // chkWriteProgram
            // 
            this.chkWriteProgram.AutoSize = true;
            this.chkWriteProgram.Location = new System.Drawing.Point(14, 95);
            this.chkWriteProgram.Name = "chkWriteProgram";
            this.chkWriteProgram.Size = new System.Drawing.Size(92, 17);
            this.chkWriteProgram.TabIndex = 10;
            this.chkWriteProgram.Text = "Write program";
            this.chkWriteProgram.UseVisualStyleBackColor = true;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.btnDownload2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(388, 25);
            this.toolStrip1.TabIndex = 16;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.Visible = false;
            this.toolStrip1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.toolStrip1_MouseDown);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(46, 22);
            this.toolStripButton1.Text = "Return";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // btnDownload2
            // 
            this.btnDownload2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnDownload2.Image = ((System.Drawing.Image)(resources.GetObject("btnDownload2.Image")));
            this.btnDownload2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDownload2.Name = "btnDownload2";
            this.btnDownload2.Size = new System.Drawing.Size(65, 22);
            this.btnDownload2.Text = "Download";
            this.btnDownload2.Click += new System.EventHandler(this.btnDownload2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabBasic);
            this.tabControl1.Controls.Add(this.tabAdvanced);
            this.tabControl1.Controls.Add(this.tabTiming);
            this.tabControl1.Controls.Add(this.tabReset);
            this.tabControl1.Controls.Add(this.tabActivation);
            this.tabControl1.Controls.Add(this.tabTerminal);
            this.tabControl1.Controls.Add(this.tabTest);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(48, 18);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(327, 177);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 2;
            this.tabControl1.TabStop = false;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabBasic
            // 
            this.tabBasic.BackColor = System.Drawing.Color.Transparent;
            this.tabBasic.Controls.Add(this.btnPortSettings);
            this.tabBasic.Controls.Add(this.cboLocalId);
            this.tabBasic.Controls.Add(this.cboRemoteId);
            this.tabBasic.Controls.Add(this.lblGUIId);
            this.tabBasic.Controls.Add(this.lbPICId);
            this.tabBasic.Controls.Add(this.cboFiles);
            this.tabBasic.Controls.Add(this.chkWriteProgram);
            this.tabBasic.Controls.Add(this.btnBrowse);
            this.tabBasic.Controls.Add(this.label1);
            this.tabBasic.Controls.Add(this.chkWriteEeprom);
            this.tabBasic.Controls.Add(this.cboBaudrate);
            this.tabBasic.Controls.Add(this.label4);
            this.tabBasic.Controls.Add(this.label2);
            this.tabBasic.Controls.Add(this.lblBaudRate);
            this.tabBasic.Controls.Add(this.cboDevice);
            this.tabBasic.Controls.Add(this.cboPort);
            this.tabBasic.Controls.Add(this.cboFamily);
            this.tabBasic.Location = new System.Drawing.Point(4, 22);
            this.tabBasic.Name = "tabBasic";
            this.tabBasic.Padding = new System.Windows.Forms.Padding(3);
            this.tabBasic.Size = new System.Drawing.Size(319, 151);
            this.tabBasic.TabIndex = 0;
            this.tabBasic.Text = "Basic";
            this.tabBasic.UseVisualStyleBackColor = true;
            // 
            // btnPortSettings
            // 
            this.btnPortSettings.Location = new System.Drawing.Point(293, 91);
            this.btnPortSettings.Name = "btnPortSettings";
            this.btnPortSettings.Size = new System.Drawing.Size(24, 23);
            this.btnPortSettings.TabIndex = 22;
            this.btnPortSettings.Text = "...";
            this.btnPortSettings.UseVisualStyleBackColor = true;
            this.btnPortSettings.Visible = false;
            this.btnPortSettings.Click += new System.EventHandler(this.btnPortSettings_Click);
            // 
            // cboLocalId
            // 
            this.cboLocalId.FormattingEnabled = true;
            this.cboLocalId.Location = new System.Drawing.Point(219, 119);
            this.cboLocalId.Name = "cboLocalId";
            this.cboLocalId.Size = new System.Drawing.Size(64, 21);
            this.cboLocalId.TabIndex = 15;
            this.cboLocalId.Visible = false;
            // 
            // cboRemoteId
            // 
            this.cboRemoteId.FormattingEnabled = true;
            this.cboRemoteId.Location = new System.Drawing.Point(219, 93);
            this.cboRemoteId.Name = "cboRemoteId";
            this.cboRemoteId.Size = new System.Drawing.Size(64, 21);
            this.cboRemoteId.TabIndex = 15;
            this.cboRemoteId.Visible = false;
            // 
            // lblGUIId
            // 
            this.lblGUIId.AutoSize = true;
            this.lblGUIId.Location = new System.Drawing.Point(152, 122);
            this.lblGUIId.Name = "lblGUIId";
            this.lblGUIId.Size = new System.Drawing.Size(43, 13);
            this.lblGUIId.TabIndex = 14;
            this.lblGUIId.Text = "GUI ID:";
            this.lblGUIId.Visible = false;
            // 
            // lbPICId
            // 
            this.lbPICId.AutoSize = true;
            this.lbPICId.Location = new System.Drawing.Point(152, 96);
            this.lbPICId.Name = "lbPICId";
            this.lbPICId.Size = new System.Drawing.Size(41, 13);
            this.lbPICId.TabIndex = 14;
            this.lbPICId.Text = "PIC ID:";
            this.lbPICId.Visible = false;
            // 
            // cboFiles
            // 
            this.cboFiles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cboFiles.ContextMenuStrip = this.mnuRecentFile;
            this.cboFiles.DropDownWidth = 300;
            this.cboFiles.FormattingEnabled = true;
            this.cboFiles.Location = new System.Drawing.Point(67, 10);
            this.cboFiles.Name = "cboFiles";
            this.cboFiles.Size = new System.Drawing.Size(214, 21);
            this.cboFiles.Sorted = true;
            this.cboFiles.TabIndex = 4;
            this.cboFiles.SelectedIndexChanged += new System.EventHandler(this.cboFiles_SelectedIndexChanged);
            // 
            // mnuRecentFile
            // 
            this.mnuRecentFile.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuRecentFileRemove});
            this.mnuRecentFile.Name = "mnuRecentFile";
            this.mnuRecentFile.Size = new System.Drawing.Size(165, 26);
            // 
            // mnuRecentFileRemove
            // 
            this.mnuRecentFileRemove.Name = "mnuRecentFileRemove";
            this.mnuRecentFileRemove.Size = new System.Drawing.Size(164, 22);
            this.mnuRecentFileRemove.Text = "Remove from list";
            this.mnuRecentFileRemove.Click += new System.EventHandler(this.mnuRecentFileRemove_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(152, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Port:";
            // 
            // tabAdvanced
            // 
            this.tabAdvanced.Controls.Add(this.chkAddCRC);
            this.tabAdvanced.Controls.Add(this.chkEcho);
            this.tabAdvanced.Controls.Add(this.chkAutoBaud);
            this.tabAdvanced.Controls.Add(this.label14);
            this.tabAdvanced.Controls.Add(this.label15);
            this.tabAdvanced.Controls.Add(this.lblSize);
            this.tabAdvanced.Controls.Add(this.lblPlacement);
            this.tabAdvanced.Controls.Add(this.txtCustomBlSizeP);
            this.tabAdvanced.Controls.Add(this.txtCustomBlPlacementP);
            this.tabAdvanced.Controls.Add(this.chkAllowBlOverwrite);
            this.tabAdvanced.Controls.Add(this.chkNoGoto);
            this.tabAdvanced.Controls.Add(this.chkCustomBl);
            this.tabAdvanced.Controls.Add(this.chkWriteConfigs);
            this.tabAdvanced.Location = new System.Drawing.Point(4, 22);
            this.tabAdvanced.Name = "tabAdvanced";
            this.tabAdvanced.Size = new System.Drawing.Size(319, 151);
            this.tabAdvanced.TabIndex = 5;
            this.tabAdvanced.Text = "Advanced";
            this.tabAdvanced.UseVisualStyleBackColor = true;
            // 
            // chkAddCRC
            // 
            this.chkAddCRC.AutoSize = true;
            this.chkAddCRC.Location = new System.Drawing.Point(204, 60);
            this.chkAddCRC.Name = "chkAddCRC";
            this.chkAddCRC.Size = new System.Drawing.Size(124, 17);
            this.chkAddCRC.TabIndex = 20;
            this.chkAddCRC.Text = "Put CRC before goto";
            this.chkAddCRC.UseVisualStyleBackColor = true;
            this.chkAddCRC.CheckedChanged += new System.EventHandler(this.chkAddCRC_CheckedChanged);
            // 
            // chkEcho
            // 
            this.chkEcho.AutoSize = true;
            this.chkEcho.Location = new System.Drawing.Point(204, 37);
            this.chkEcho.Name = "chkEcho";
            this.chkEcho.Size = new System.Drawing.Size(105, 17);
            this.chkEcho.TabIndex = 19;
            this.chkEcho.Text = "Echo verification";
            this.chkEcho.UseVisualStyleBackColor = true;
            // 
            // chkAutoBaud
            // 
            this.chkAutoBaud.AutoSize = true;
            this.chkAutoBaud.Location = new System.Drawing.Point(204, 14);
            this.chkAutoBaud.Name = "chkAutoBaud";
            this.chkAutoBaud.Size = new System.Drawing.Size(93, 17);
            this.chkAutoBaud.TabIndex = 18;
            this.chkAutoBaud.Text = "Auto baudrate";
            this.chkAutoBaud.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(27, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 17;
            this.label14.Text = "placement";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(27, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "size";
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.Location = new System.Drawing.Point(155, 130);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(42, 13);
            this.lblSize.TabIndex = 16;
            this.lblSize.Text = "page(s)";
            // 
            // lblPlacement
            // 
            this.lblPlacement.AutoSize = true;
            this.lblPlacement.Location = new System.Drawing.Point(155, 104);
            this.lblPlacement.Name = "lblPlacement";
            this.lblPlacement.Size = new System.Drawing.Size(104, 13);
            this.lblPlacement.TabIndex = 16;
            this.lblPlacement.Text = "page(s) from the end";
            // 
            // txtCustomBlSizeP
            // 
            this.txtCustomBlSizeP.Enabled = false;
            this.txtCustomBlSizeP.Location = new System.Drawing.Point(106, 127);
            this.txtCustomBlSizeP.Name = "txtCustomBlSizeP";
            this.txtCustomBlSizeP.Size = new System.Drawing.Size(43, 20);
            this.txtCustomBlSizeP.TabIndex = 15;
            this.txtCustomBlSizeP.Text = "1";
            this.txtCustomBlSizeP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCustomBlSizeP.Leave += new System.EventHandler(this.txtCustmBlSize_Leave);
            this.txtCustomBlSizeP.Enter += new System.EventHandler(this.txtCustomBlSizeP_Enter);
            // 
            // txtCustomBlPlacementP
            // 
            this.txtCustomBlPlacementP.Enabled = false;
            this.txtCustomBlPlacementP.Location = new System.Drawing.Point(106, 101);
            this.txtCustomBlPlacementP.Name = "txtCustomBlPlacementP";
            this.txtCustomBlPlacementP.Size = new System.Drawing.Size(43, 20);
            this.txtCustomBlPlacementP.TabIndex = 15;
            this.txtCustomBlPlacementP.Text = "1";
            this.txtCustomBlPlacementP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCustomBlPlacementP.Leave += new System.EventHandler(this.txtCustmBlPlacement_Leave);
            this.txtCustomBlPlacementP.Enter += new System.EventHandler(this.txtCustomBlPlacementP_Enter);
            // 
            // chkAllowBlOverwrite
            // 
            this.chkAllowBlOverwrite.AutoSize = true;
            this.chkAllowBlOverwrite.Location = new System.Drawing.Point(11, 37);
            this.chkAllowBlOverwrite.Name = "chkAllowBlOverwrite";
            this.chkAllowBlOverwrite.Size = new System.Drawing.Size(162, 17);
            this.chkAllowBlOverwrite.TabIndex = 14;
            this.chkAllowBlOverwrite.Text = "Allow overwrite of bootloader";
            this.chkAllowBlOverwrite.UseVisualStyleBackColor = true;
            this.chkAllowBlOverwrite.CheckedChanged += new System.EventHandler(this.chkAllowBlOverwrite_CheckedChanged);
            // 
            // chkCustomBl
            // 
            this.chkCustomBl.AutoSize = true;
            this.chkCustomBl.Location = new System.Drawing.Point(11, 84);
            this.chkCustomBl.Name = "chkCustomBl";
            this.chkCustomBl.Size = new System.Drawing.Size(114, 17);
            this.chkCustomBl.TabIndex = 13;
            this.chkCustomBl.Text = "Custom bootloader";
            this.chkCustomBl.UseVisualStyleBackColor = true;
            this.chkCustomBl.CheckedChanged += new System.EventHandler(this.chkCustomBl_CheckedChanged);
            // 
            // tabTiming
            // 
            this.tabTiming.BackColor = System.Drawing.Color.Transparent;
            this.tabTiming.Controls.Add(this.txtTimeout);
            this.tabTiming.Controls.Add(this.txtPolltime);
            this.tabTiming.Controls.Add(this.label7);
            this.tabTiming.Controls.Add(this.label6);
            this.tabTiming.Location = new System.Drawing.Point(4, 22);
            this.tabTiming.Name = "tabTiming";
            this.tabTiming.Padding = new System.Windows.Forms.Padding(3);
            this.tabTiming.Size = new System.Drawing.Size(319, 151);
            this.tabTiming.TabIndex = 1;
            this.tabTiming.Text = "Timing";
            this.tabTiming.UseVisualStyleBackColor = true;
            // 
            // txtTimeout
            // 
            this.txtTimeout.Location = new System.Drawing.Point(96, 43);
            this.txtTimeout.Name = "txtTimeout";
            this.txtTimeout.Size = new System.Drawing.Size(43, 20);
            this.txtTimeout.TabIndex = 2;
            this.txtTimeout.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPolltime
            // 
            this.txtPolltime.Location = new System.Drawing.Point(96, 17);
            this.txtPolltime.Name = "txtPolltime";
            this.txtPolltime.Size = new System.Drawing.Size(43, 20);
            this.txtPolltime.TabIndex = 1;
            this.txtPolltime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Timeout [ms]:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Poll time [ms]:";
            // 
            // tabReset
            // 
            this.tabReset.Controls.Add(this.label10);
            this.tabReset.Controls.Add(this.cboResetBaudrate);
            this.tabReset.Controls.Add(this.lblIncorrectFormat);
            this.tabReset.Controls.Add(this.txtResettime);
            this.tabReset.Controls.Add(this.label8);
            this.tabReset.Controls.Add(this.txtResetCommand);
            this.tabReset.Controls.Add(this.rdbResetCommand);
            this.tabReset.Controls.Add(this.rdbResetRts);
            this.tabReset.Controls.Add(this.rdbResetDtr);
            this.tabReset.Controls.Add(this.rdbResetManual);
            this.tabReset.Location = new System.Drawing.Point(4, 22);
            this.tabReset.Name = "tabReset";
            this.tabReset.Size = new System.Drawing.Size(319, 151);
            this.tabReset.TabIndex = 2;
            this.tabReset.Text = "Reset";
            this.tabReset.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(132, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Baudrate:";
            // 
            // cboResetBaudrate
            // 
            this.cboResetBaudrate.Enabled = false;
            this.cboResetBaudrate.FormattingEnabled = true;
            this.cboResetBaudrate.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "56000",
            "57600",
            "115200",
            "128000",
            "256000"});
            this.cboResetBaudrate.Location = new System.Drawing.Point(200, 83);
            this.cboResetBaudrate.Name = "cboResetBaudrate";
            this.cboResetBaudrate.Size = new System.Drawing.Size(79, 21);
            this.cboResetBaudrate.TabIndex = 16;
            // 
            // lblIncorrectFormat
            // 
            this.lblIncorrectFormat.AutoSize = true;
            this.lblIncorrectFormat.ForeColor = System.Drawing.Color.Red;
            this.lblIncorrectFormat.Location = new System.Drawing.Point(25, 129);
            this.lblIncorrectFormat.Name = "lblIncorrectFormat";
            this.lblIncorrectFormat.Size = new System.Drawing.Size(81, 13);
            this.lblIncorrectFormat.TabIndex = 15;
            this.lblIncorrectFormat.Text = "Incorrect format";
            this.lblIncorrectFormat.Visible = false;
            // 
            // txtResettime
            // 
            this.txtResettime.Enabled = false;
            this.txtResettime.Location = new System.Drawing.Point(200, 60);
            this.txtResettime.Name = "txtResettime";
            this.txtResettime.Size = new System.Drawing.Size(79, 20);
            this.txtResettime.TabIndex = 6;
            this.txtResettime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(103, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Reset time [ms]:";
            // 
            // txtResetCommand
            // 
            this.txtResetCommand.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResetCommand.Enabled = false;
            this.txtResetCommand.Location = new System.Drawing.Point(28, 109);
            this.txtResetCommand.Name = "txtResetCommand";
            this.txtResetCommand.Size = new System.Drawing.Size(276, 20);
            this.txtResetCommand.TabIndex = 3;
            this.txtResetCommand.TextChanged += new System.EventHandler(this.txtResetCommand_TextChanged);
            // 
            // rdbResetCommand
            // 
            this.rdbResetCommand.AutoSize = true;
            this.rdbResetCommand.Location = new System.Drawing.Point(11, 83);
            this.rdbResetCommand.Name = "rdbResetCommand";
            this.rdbResetCommand.Size = new System.Drawing.Size(75, 17);
            this.rdbResetCommand.TabIndex = 2;
            this.rdbResetCommand.Text = "Command:";
            this.rdbResetCommand.UseVisualStyleBackColor = true;
            this.rdbResetCommand.CheckedChanged += new System.EventHandler(this.rdbCommandReset_CheckedChanged);
            // 
            // rdbResetRts
            // 
            this.rdbResetRts.AutoSize = true;
            this.rdbResetRts.Location = new System.Drawing.Point(11, 37);
            this.rdbResetRts.Name = "rdbResetRts";
            this.rdbResetRts.Size = new System.Drawing.Size(47, 17);
            this.rdbResetRts.TabIndex = 4;
            this.rdbResetRts.Text = "RTS";
            this.rdbResetRts.UseVisualStyleBackColor = true;
            // 
            // rdbResetDtr
            // 
            this.rdbResetDtr.AutoSize = true;
            this.rdbResetDtr.Location = new System.Drawing.Point(11, 60);
            this.rdbResetDtr.Name = "rdbResetDtr";
            this.rdbResetDtr.Size = new System.Drawing.Size(48, 17);
            this.rdbResetDtr.TabIndex = 5;
            this.rdbResetDtr.Text = "DTR";
            this.rdbResetDtr.UseVisualStyleBackColor = true;
            // 
            // rdbResetManual
            // 
            this.rdbResetManual.AutoSize = true;
            this.rdbResetManual.Checked = true;
            this.rdbResetManual.Location = new System.Drawing.Point(11, 14);
            this.rdbResetManual.Name = "rdbResetManual";
            this.rdbResetManual.Size = new System.Drawing.Size(60, 17);
            this.rdbResetManual.TabIndex = 1;
            this.rdbResetManual.TabStop = true;
            this.rdbResetManual.Text = "Manual";
            this.rdbResetManual.UseVisualStyleBackColor = true;
            this.rdbResetManual.CheckedChanged += new System.EventHandler(this.rdbResetManual_CheckedChanged);
            // 
            // tabActivation
            // 
            this.tabActivation.Controls.Add(this.rdbActivateNone);
            this.tabActivation.Controls.Add(this.rdbActivateRTS);
            this.tabActivation.Controls.Add(this.rdbActivateDTR);
            this.tabActivation.Location = new System.Drawing.Point(4, 22);
            this.tabActivation.Name = "tabActivation";
            this.tabActivation.Size = new System.Drawing.Size(319, 151);
            this.tabActivation.TabIndex = 3;
            this.tabActivation.Text = "Activation";
            this.tabActivation.UseVisualStyleBackColor = true;
            // 
            // rdbActivateNone
            // 
            this.rdbActivateNone.AutoSize = true;
            this.rdbActivateNone.Checked = true;
            this.rdbActivateNone.Location = new System.Drawing.Point(11, 14);
            this.rdbActivateNone.Name = "rdbActivateNone";
            this.rdbActivateNone.Size = new System.Drawing.Size(60, 17);
            this.rdbActivateNone.TabIndex = 5;
            this.rdbActivateNone.TabStop = true;
            this.rdbActivateNone.Text = "Manual";
            this.rdbActivateNone.UseVisualStyleBackColor = true;
            // 
            // rdbActivateRTS
            // 
            this.rdbActivateRTS.AutoSize = true;
            this.rdbActivateRTS.Location = new System.Drawing.Point(11, 37);
            this.rdbActivateRTS.Name = "rdbActivateRTS";
            this.rdbActivateRTS.Size = new System.Drawing.Size(47, 17);
            this.rdbActivateRTS.TabIndex = 4;
            this.rdbActivateRTS.Text = "RTS";
            this.rdbActivateRTS.UseVisualStyleBackColor = true;
            // 
            // rdbActivateDTR
            // 
            this.rdbActivateDTR.AutoSize = true;
            this.rdbActivateDTR.Location = new System.Drawing.Point(11, 60);
            this.rdbActivateDTR.Name = "rdbActivateDTR";
            this.rdbActivateDTR.Size = new System.Drawing.Size(48, 17);
            this.rdbActivateDTR.TabIndex = 3;
            this.rdbActivateDTR.Text = "DTR";
            this.rdbActivateDTR.UseVisualStyleBackColor = true;
            // 
            // tabTerminal
            // 
            this.tabTerminal.Controls.Add(this.label18);
            this.tabTerminal.Controls.Add(this.lblTxCRC);
            this.tabTerminal.Controls.Add(this.cboTermTxType);
            this.tabTerminal.Controls.Add(this.cborTermRxType);
            this.tabTerminal.Controls.Add(this.label12);
            this.tabTerminal.Controls.Add(this.label11);
            this.tabTerminal.Controls.Add(this.btnTermClearRx);
            this.tabTerminal.Controls.Add(this.txtTermTx);
            this.tabTerminal.Controls.Add(this.txtTermRx);
            this.tabTerminal.Controls.Add(this.btnTermClose);
            this.tabTerminal.Controls.Add(this.chkTermSwitchTo);
            this.tabTerminal.Controls.Add(this.btnTermOpen);
            this.tabTerminal.Controls.Add(this.cboTermBaudrate);
            this.tabTerminal.Controls.Add(this.label9);
            this.tabTerminal.Location = new System.Drawing.Point(4, 22);
            this.tabTerminal.Name = "tabTerminal";
            this.tabTerminal.Size = new System.Drawing.Size(319, 151);
            this.tabTerminal.TabIndex = 4;
            this.tabTerminal.Text = "Terminal";
            this.tabTerminal.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(216, 44);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 13);
            this.label18.TabIndex = 23;
            this.label18.Text = "Tx CRC:";
            // 
            // lblTxCRC
            // 
            this.lblTxCRC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTxCRC.Location = new System.Drawing.Point(268, 44);
            this.lblTxCRC.Name = "lblTxCRC";
            this.lblTxCRC.Size = new System.Drawing.Size(48, 23);
            this.lblTxCRC.TabIndex = 22;
            this.lblTxCRC.Text = "0x0000";
            // 
            // cboTermTxType
            // 
            this.cboTermTxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTermTxType.DropDownWidth = 100;
            this.cboTermTxType.FormattingEnabled = true;
            this.cboTermTxType.Items.AddRange(new object[] {
            "Text",
            "Hex 8bit"});
            this.cboTermTxType.Location = new System.Drawing.Point(38, 41);
            this.cboTermTxType.Name = "cboTermTxType";
            this.cboTermTxType.Size = new System.Drawing.Size(60, 21);
            this.cboTermTxType.TabIndex = 20;
            // 
            // cborTermRxType
            // 
            this.cborTermRxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cborTermRxType.DropDownWidth = 100;
            this.cborTermRxType.FormattingEnabled = true;
            this.cborTermRxType.Items.AddRange(new object[] {
            "Text",
            "8bit hex",
            "8bit unsigned",
            "16bit hex",
            "16bit unsigned",
            "32bit hex",
            "32bit unsigned"});
            this.cborTermRxType.Location = new System.Drawing.Point(38, 68);
            this.cborTermRxType.Name = "cborTermRxType";
            this.cborTermRxType.Size = new System.Drawing.Size(60, 21);
            this.cborTermRxType.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 13);
            this.label12.TabIndex = 18;
            this.label12.Text = "Tx:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 71);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Rx";
            // 
            // btnTermClearRx
            // 
            this.btnTermClearRx.Location = new System.Drawing.Point(104, 67);
            this.btnTermClearRx.Name = "btnTermClearRx";
            this.btnTermClearRx.Size = new System.Drawing.Size(64, 23);
            this.btnTermClearRx.TabIndex = 17;
            this.btnTermClearRx.Text = "Clear Rx";
            this.btnTermClearRx.UseVisualStyleBackColor = true;
            this.btnTermClearRx.Click += new System.EventHandler(this.btnTermClearRx_Click);
            // 
            // txtTermTx
            // 
            this.txtTermTx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTermTx.Enabled = false;
            this.txtTermTx.Location = new System.Drawing.Point(104, 41);
            this.txtTermTx.Name = "txtTermTx";
            this.txtTermTx.Size = new System.Drawing.Size(106, 20);
            this.txtTermTx.TabIndex = 16;
            this.txtTermTx.TextChanged += new System.EventHandler(this.txtTermTx_TextChanged);
            this.txtTermTx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTermTxHex_KeyDown);
            // 
            // txtTermRx
            // 
            this.txtTermRx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTermRx.Location = new System.Drawing.Point(13, 96);
            this.txtTermRx.Multiline = true;
            this.txtTermRx.Name = "txtTermRx";
            this.txtTermRx.ReadOnly = true;
            this.txtTermRx.Size = new System.Drawing.Size(290, 44);
            this.txtTermRx.TabIndex = 15;
            // 
            // btnTermClose
            // 
            this.btnTermClose.Enabled = false;
            this.btnTermClose.Location = new System.Drawing.Point(220, 16);
            this.btnTermClose.Name = "btnTermClose";
            this.btnTermClose.Size = new System.Drawing.Size(50, 23);
            this.btnTermClose.TabIndex = 14;
            this.btnTermClose.Text = "Close";
            this.btnTermClose.UseVisualStyleBackColor = true;
            this.btnTermClose.Click += new System.EventHandler(this.btnTermClose_Click);
            // 
            // chkTermSwitchTo
            // 
            this.chkTermSwitchTo.AutoSize = true;
            this.chkTermSwitchTo.Location = new System.Drawing.Point(174, 73);
            this.chkTermSwitchTo.Name = "chkTermSwitchTo";
            this.chkTermSwitchTo.Size = new System.Drawing.Size(143, 17);
            this.chkTermSwitchTo.TabIndex = 13;
            this.chkTermSwitchTo.Text = "Switch to after download";
            this.chkTermSwitchTo.UseVisualStyleBackColor = true;
            // 
            // btnTermOpen
            // 
            this.btnTermOpen.Location = new System.Drawing.Point(164, 16);
            this.btnTermOpen.Name = "btnTermOpen";
            this.btnTermOpen.Size = new System.Drawing.Size(50, 23);
            this.btnTermOpen.TabIndex = 12;
            this.btnTermOpen.Text = "Open";
            this.btnTermOpen.UseVisualStyleBackColor = true;
            this.btnTermOpen.Click += new System.EventHandler(this.btnTermOpen_Click);
            // 
            // cboTermBaudrate
            // 
            this.cboTermBaudrate.FormattingEnabled = true;
            this.cboTermBaudrate.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "56000",
            "57600",
            "115200",
            "128000",
            "256000"});
            this.cboTermBaudrate.Location = new System.Drawing.Point(71, 18);
            this.cboTermBaudrate.Name = "cboTermBaudrate";
            this.cboTermBaudrate.Size = new System.Drawing.Size(87, 21);
            this.cboTermBaudrate.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Baudrate:";
            // 
            // tabTest
            // 
            this.tabTest.Controls.Add(this.btnExportDeviceDb);
            this.tabTest.Controls.Add(this.cboTestResponse);
            this.tabTest.Controls.Add(this.txtTestFwVersion);
            this.tabTest.Controls.Add(this.chkTestEnable);
            this.tabTest.Controls.Add(this.label17);
            this.tabTest.Controls.Add(this.label16);
            this.tabTest.Location = new System.Drawing.Point(4, 22);
            this.tabTest.Name = "tabTest";
            this.tabTest.Size = new System.Drawing.Size(319, 151);
            this.tabTest.TabIndex = 6;
            this.tabTest.Text = "Simulation";
            this.tabTest.UseVisualStyleBackColor = true;
            // 
            // btnExportDeviceDb
            // 
            this.btnExportDeviceDb.Location = new System.Drawing.Point(11, 113);
            this.btnExportDeviceDb.Name = "btnExportDeviceDb";
            this.btnExportDeviceDb.Size = new System.Drawing.Size(174, 23);
            this.btnExportDeviceDb.TabIndex = 4;
            this.btnExportDeviceDb.Text = "Export internal device database";
            this.btnExportDeviceDb.UseVisualStyleBackColor = true;
            this.btnExportDeviceDb.Click += new System.EventHandler(this.btnExportDeviceDb_Click);
            // 
            // cboTestResponse
            // 
            this.cboTestResponse.FormattingEnabled = true;
            this.cboTestResponse.Items.AddRange(new object[] {
            "Ok",
            "Checksum error",
            "Verification failed",
            "Bl protection tripped"});
            this.cboTestResponse.Location = new System.Drawing.Point(103, 75);
            this.cboTestResponse.Name = "cboTestResponse";
            this.cboTestResponse.Size = new System.Drawing.Size(135, 21);
            this.cboTestResponse.TabIndex = 3;
            // 
            // txtTestFwVersion
            // 
            this.txtTestFwVersion.Location = new System.Drawing.Point(103, 49);
            this.txtTestFwVersion.Name = "txtTestFwVersion";
            this.txtTestFwVersion.Size = new System.Drawing.Size(53, 20);
            this.txtTestFwVersion.TabIndex = 2;
            this.txtTestFwVersion.Text = "1.0.0";
            // 
            // chkTestEnable
            // 
            this.chkTestEnable.AutoSize = true;
            this.chkTestEnable.Location = new System.Drawing.Point(11, 19);
            this.chkTestEnable.Name = "chkTestEnable";
            this.chkTestEnable.Size = new System.Drawing.Size(59, 17);
            this.chkTestEnable.TabIndex = 1;
            this.chkTestEnable.Text = "Enable";
            this.chkTestEnable.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 78);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Response:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Firmware version:";
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnCheck,
            this.btnDownload,
            this.btnReparseHexFile,
            this.btnAbort,
            this.btnShowOutput});
            this.toolStrip2.Location = new System.Drawing.Point(0, 24);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(352, 25);
            this.toolStrip2.TabIndex = 0;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // btnCheck
            // 
            this.btnCheck.Image = ((System.Drawing.Image)(resources.GetObject("btnCheck.Image")));
            this.btnCheck.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(91, 22);
            this.btnCheck.Text = "Check for bl";
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnDownload
            // 
            this.btnDownload.Image = ((System.Drawing.Image)(resources.GetObject("btnDownload.Image")));
            this.btnDownload.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(81, 22);
            this.btnDownload.Text = "Download";
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // btnReparseHexFile
            // 
            this.btnReparseHexFile.Image = ((System.Drawing.Image)(resources.GetObject("btnReparseHexFile.Image")));
            this.btnReparseHexFile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnReparseHexFile.Name = "btnReparseHexFile";
            this.btnReparseHexFile.Size = new System.Drawing.Size(84, 22);
            this.btnReparseHexFile.Text = "Reload hex";
            this.btnReparseHexFile.ToolTipText = "Reparse hex-file";
            this.btnReparseHexFile.Click += new System.EventHandler(this.btnReparseHexFile_Click);
            // 
            // btnAbort
            // 
            this.btnAbort.Enabled = false;
            this.btnAbort.Image = ((System.Drawing.Image)(resources.GetObject("btnAbort.Image")));
            this.btnAbort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Size = new System.Drawing.Size(57, 22);
            this.btnAbort.Text = "Abort";
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnShowOutput
            // 
            this.btnShowOutput.BackColor = System.Drawing.SystemColors.Control;
            this.btnShowOutput.Checked = true;
            this.btnShowOutput.CheckOnClick = true;
            this.btnShowOutput.CheckState = System.Windows.Forms.CheckState.Checked;
            this.btnShowOutput.Image = ((System.Drawing.Image)(resources.GetObject("btnShowOutput.Image")));
            this.btnShowOutput.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnShowOutput.Name = "btnShowOutput";
            this.btnShowOutput.Size = new System.Drawing.Size(65, 20);
            this.btnShowOutput.Text = "Output";
            this.btnShowOutput.Visible = false;
            this.btnShowOutput.CheckedChanged += new System.EventHandler(this.btnShowOutput_CheckedChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(12, 52);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            this.splitContainer1.Panel1MinSize = 177;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(327, 330);
            this.splitContainer1.SplitterDistance = 177;
            this.splitContainer1.TabIndex = 19;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.txtInfo);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.picHexContent);
            this.splitContainer2.Size = new System.Drawing.Size(327, 149);
            this.splitContainer2.SplitterDistance = 298;
            this.splitContainer2.TabIndex = 0;
            // 
            // picHexContent
            // 
            this.picHexContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picHexContent.Location = new System.Drawing.Point(0, 0);
            this.picHexContent.Name = "picHexContent";
            this.picHexContent.Size = new System.Drawing.Size(25, 149);
            this.picHexContent.TabIndex = 0;
            this.picHexContent.TabStop = false;
            this.picHexContent.Paint += new System.Windows.Forms.PaintEventHandler(this.picHexContent_Paint);
            this.picHexContent.SizeChanged += new System.EventHandler(this.picHexContent_SizeChanged);
            // 
            // tabControl2
            // 
            this.tabControl2.Location = new System.Drawing.Point(337, 24);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(16, 22);
            this.tabControl2.TabIndex = 20;
            this.tabControl2.Visible = false;
            // 
            // mnuViewSettingsDir
            // 
            this.mnuViewSettingsDir.Name = "mnuViewSettingsDir";
            this.mnuViewSettingsDir.Size = new System.Drawing.Size(174, 22);
            this.mnuViewSettingsDir.Text = "Settings directory";
            this.mnuViewSettingsDir.Click += new System.EventHandler(this.mnuViewSettingsDir_Click);
            // 
            // frmDS30Loader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 421);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.toolStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(5000, 5000);
            this.MinimumSize = new System.Drawing.Size(368, 36);
            this.Name = "frmDS30Loader";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ds30 Loader";
            this.Activated += new System.EventHandler(this.frmDS30Loader_Activated);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmDSLoader_MouseDown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDSLoader_FormClosing);
            this.LocationChanged += new System.EventHandler(this.frmDS30Loader_LocationChanged);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabBasic.ResumeLayout(false);
            this.tabBasic.PerformLayout();
            this.mnuRecentFile.ResumeLayout(false);
            this.tabAdvanced.ResumeLayout(false);
            this.tabAdvanced.PerformLayout();
            this.tabTiming.ResumeLayout(false);
            this.tabTiming.PerformLayout();
            this.tabReset.ResumeLayout(false);
            this.tabReset.PerformLayout();
            this.tabActivation.ResumeLayout(false);
            this.tabActivation.PerformLayout();
            this.tabTerminal.ResumeLayout(false);
            this.tabTerminal.PerformLayout();
            this.tabTest.ResumeLayout(false);
            this.tabTest.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picHexContent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem mnuFile;
		private System.Windows.Forms.ToolStripMenuItem mnuFileExit;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel lblCopyright;
        private System.Windows.Forms.ToolStripStatusLabel lblVersion;
		private System.Windows.Forms.ComboBox cboBaudrate;
		private System.Windows.Forms.Label lblBaudRate;
        private System.Windows.Forms.ComboBox cboPort;
        private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RichTextBox txtInfo;
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.ToolStripStatusLabel lblGPL;
        private System.Windows.Forms.ProgressBar progressBar;
		private System.Windows.Forms.CheckBox chkWriteProgram;
		private System.Windows.Forms.CheckBox chkWriteEeprom;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.CheckBox chkNoGoto;
		private System.Windows.Forms.ComboBox cboFamily;
		private System.Windows.Forms.CheckBox chkWriteConfigs;
        private System.Windows.Forms.ComboBox cboDevice;
        private System.Windows.Forms.ToolStripMenuItem mnuOptions;
        private System.Windows.Forms.ToolStripMenuItem mnuOptDebugmode;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuHelpAbout;
        private System.Windows.Forms.ToolStripMenuItem mnuHelpVisitHomepage;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton btnDownload2;
        private System.Windows.Forms.ToolStripMenuItem mnuView;
        private System.Windows.Forms.ToolStripMenuItem mnuViewMicro;
        private System.Windows.Forms.ToolStripMenuItem mnuViewOntop;
        private System.Windows.Forms.ToolStripMenuItem mnuCommands;
        private System.Windows.Forms.ToolStripMenuItem mnuCmdDownload;
        private System.Windows.Forms.ToolStripMenuItem mnuCmdAbort;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabBasic;
        private System.Windows.Forms.TabPage tabTiming;
        private System.Windows.Forms.TextBox txtTimeout;
        private System.Windows.Forms.TextBox txtPolltime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabReset;
        private System.Windows.Forms.TextBox txtResetCommand;
        private System.Windows.Forms.RadioButton rdbResetCommand;
        private System.Windows.Forms.RadioButton rdbResetRts;
        private System.Windows.Forms.RadioButton rdbResetDtr;
        private System.Windows.Forms.RadioButton rdbResetManual;
        private System.Windows.Forms.TabPage tabActivation;
        private System.Windows.Forms.TextBox txtResettime;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rdbActivateRTS;
        private System.Windows.Forms.RadioButton rdbActivateDTR;
        private System.Windows.Forms.RadioButton rdbActivateNone;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton btnCheck;
        private System.Windows.Forms.ToolStripButton btnDownload;
        private System.Windows.Forms.ToolStripButton btnAbort;
        private System.Windows.Forms.ToolStripButton btnShowOutput;
        private System.Windows.Forms.Label lblIncorrectFormat;
        private System.Windows.Forms.TabPage tabTerminal;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnTermOpen;
        private System.Windows.Forms.ComboBox cboTermBaudrate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chkTermSwitchTo;
        private System.Windows.Forms.Button btnTermClose;
        private System.Windows.Forms.TextBox txtTermRx;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboResetBaudrate;
        private System.Windows.Forms.ToolStripMenuItem mnuOptResetSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuViewAdvanced;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.Button btnTermClearRx;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTermTx;
        private System.Windows.Forms.TabPage tabAdvanced;
        private System.Windows.Forms.CheckBox chkAllowBlOverwrite;
        private System.Windows.Forms.ToolStripMenuItem mnuCmdCheckForBl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.PictureBox picHexContent;
        private System.Windows.Forms.ComboBox cborTermRxType;
        private System.Windows.Forms.ComboBox cboTermTxType;
        private System.Windows.Forms.ComboBox cboFiles;
        private System.Windows.Forms.TextBox txtCustomBlPlacementP;
        private System.Windows.Forms.CheckBox chkCustomBl;
        private System.Windows.Forms.Label lblPlacement;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblSize;
        private System.Windows.Forms.TextBox txtCustomBlSizeP;
        private System.Windows.Forms.ContextMenuStrip mnuRecentFile;
        private System.Windows.Forms.ToolStripMenuItem mnuRecentFileRemove;
        private System.Windows.Forms.CheckBox chkAutoBaud;
        private System.Windows.Forms.CheckBox chkEcho;
        private System.Windows.Forms.ToolStripMenuItem mnuCmdReparse;
        private System.Windows.Forms.TabPage tabTest;
        private System.Windows.Forms.TextBox txtTestFwVersion;
        private System.Windows.Forms.CheckBox chkTestEnable;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cboTestResponse;
        private System.Windows.Forms.Label lblTxCRC;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ToolStripMenuItem mnuViewInfoWindow;
        private System.Windows.Forms.Label lbPICId;
        private System.Windows.Forms.ComboBox cboRemoteId;
        private System.Windows.Forms.Button btnPortSettings;
        private System.Windows.Forms.ComboBox cboLocalId;
        private System.Windows.Forms.Label lblGUIId;
        private System.Windows.Forms.Button btnExportDeviceDb;
        private System.Windows.Forms.CheckBox chkAddCRC;
        private System.Windows.Forms.ToolStripButton btnReparseHexFile;
        private System.Windows.Forms.ToolStripMenuItem mnuViewSettingsDir;
	}
}

