using System;

namespace ds30_Loader_GUI
{
    //---------------------------------------------------------------------------
    // Class: clsDefaultStartSettings
    //---------------------------------------------------------------------------
	[Serializable]
	public class clsDefaultStartSettings
	{
		//---------------------------------------------------------------------
		// Constructor
        //---------------------------------------------------------------------
		public clsDefaultStartSettings()
		{
            // View 
            AdvancedMode = false;
            AdvancedModeAllow = true;

            // Tab basic
            Portname = string.Empty;
            PortnameAllow = true;
            Baudrate = "9600";
            BaudrateAllow = true;
            Familyname = string.Empty;
            FamilynameAllow = true;
            Devicename = string.Empty;
            DevicenameAllow = true;
            WriteProgram = false;
            WriteProgramAllow = true;
            WriteEeprom = false;
            WriteEepromAllow = true;

            // Tab advanced
            WriteConfigs = false;
            WriteConfigsAllow = true;
            NoGoto = false;
            NoGotoAllow = true;
            IgnoreBLOverwrite = false;   
            IgnoreBLOverwriteAllow = true;
            CustomBl = false;
            CustomBlAllow = true;
            CustomBlPlacementP = 1;
            CustomBlPlacementPAllow = true;
            CustomBlSizeP = 1;
            CustomBlSizePAllow = true;
            AutoBaudRate = false;
            AutoBaudRateAllow = true;
            EchoVerification = false;
            EchoVerificationAllow = true;
            AddChecksum = false;
            AddChecksumAllow = true;

            // Tab timing
            Polltime = "500";
            PolltimeAllow = true;
            Timeout = "10000";
            TimeoutAllow = true;

            // Tab reset
            CommandReset = false;
            CommandResetAllow = true;
            ResetCommand = string.Empty;
            ResetCommandAllow = true;
            ResetBaudrate = "9600";
            ResetBaudrateAllow = true;
            DTRReset = false;
            DTRResetAllow = true;
            ManualReset = true;
            ManualResetAllow = true;
            RTSReset = false;
            RTSResetAllow = true;
            ResetTime = "1000";
            ResetTimeAllow = true;

            // Tab activation
            ActivateDTR = false;
            ActivateDTRAllow = true;
            ActivateRTS = false;
            ActivateRTSAllow = true;

            // Tab terminal
            TermSwithTo = false;
            TermBaudrate = "9600";  
            TermRxType = 0;
            TermTxType = 0;  
            TermTx = string.Empty;
		}// Constructor


        //---------------------------------------------------------------------
		// View options
        //---------------------------------------------------------------------
        public bool AdvancedMode { get; set; }
        public bool AdvancedModeAllow { get; set; }


		//---------------------------------------------------------------------
		// Tab basic settings
        //---------------------------------------------------------------------
		public string Filename { get; set; }
        public bool FilenameAllow { get; set; }
		
        public string Portname { get; set; }
        public bool PortnameAllow { get; set; }

		public string Baudrate { get; set; }
        public bool BaudrateAllow { get; set; }

		public string Familyname { get; set; }
        public bool FamilynameAllow { get; set; }

        public string Devicename { get; set; }
        public bool DevicenameAllow { get; set; }

		public bool WriteProgram { get; set; }
        public bool WriteProgramAllow { get; set; }

        public bool WriteEeprom { get; set; }
        public bool WriteEepromAllow { get; set; }
              
        
        //---------------------------------------------------------------------
		// Tab advanced
        //---------------------------------------------------------------------
        public bool WriteConfigs { get; set; }
        public bool WriteConfigsAllow { get; set; }

        public bool NoGoto { get; set; }
        public bool NoGotoAllow { get; set; }
      
        public bool IgnoreBLOverwrite { get; set; }
        public bool IgnoreBLOverwriteAllow { get; set; }

        public bool CustomBl { get; set; }
        public bool CustomBlAllow { get; set; }

        public int CustomBlPlacementP { get; set; }
        public bool CustomBlPlacementPAllow { get; set; }

        public int CustomBlSizeP { get; set; }
        public bool CustomBlSizePAllow { get; set; }

        public bool AutoBaudRate { get; set; }
        public bool AutoBaudRateAllow { get; set; }

        public bool EchoVerification { get; set; }
        public bool EchoVerificationAllow { get; set; }

        public bool AddChecksum { get; set; }
        public bool AddChecksumAllow { get; set; }


		//---------------------------------------------------------------------
		// Tab timing
        //---------------------------------------------------------------------
        public string Polltime { get; set; }
        public bool PolltimeAllow { get; set; }

        public string Timeout { get; set; }
        public bool TimeoutAllow { get; set; }


		//---------------------------------------------------------------------
		// Tab reset
        //---------------------------------------------------------------------
        public bool CommandReset { get; set; }
        public bool CommandResetAllow { get; set; }

        public string ResetCommand { get; set; }
        public bool ResetCommandAllow { get; set; }

        public string ResetBaudrate { get; set; }
        public bool ResetBaudrateAllow { get; set; }

        public bool DTRReset { get; set; }
        public bool DTRResetAllow { get; set; }

        public bool ManualReset { get; set; }
        public bool ManualResetAllow { get; set; }

        public bool RTSReset { get; set; }
        public bool RTSResetAllow { get; set; }

        public string ResetTime { get; set; }
        public bool ResetTimeAllow { get; set; }


		//---------------------------------------------------------------------
		// Tab activation
        //---------------------------------------------------------------------
        public bool ActivateDTR { get; set; }
        public bool ActivateDTRAllow { get; set; }
 
        public bool ActivateRTS { get; set; }
        public bool ActivateRTSAllow { get; set; }


		//---------------------------------------------------------------------
		// Tab terminal
        //---------------------------------------------------------------------
        public bool TermSwithTo { get; set; }
        public string TermBaudrate {  get; set; }
        public int TermRxType { get; set; }
        public int TermTxType { get; set; }
        public string TermTx { get; set; }		
	}
}