﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using ds30Loader;
using System.IO;

namespace ds30_Loader_GUI
{
    //---------------------------------------------------------------------------
    // Class: frmInfo
    //---------------------------------------------------------------------------
    partial class frmInfo : Form
    {
        //-----------------------------------------------------------------------
        // Constructor()
        //-----------------------------------------------------------------------
        public frmInfo()
        {
            InitializeComponent();
        }// Constructor()
        
        
        //-----------------------------------------------------------------------
        // Propery: ShowWithoutActivation
        //-----------------------------------------------------------------------
        protected override bool ShowWithoutActivation
        {
            get{
                return true;
            }
        }// Propery: ShowWithoutActivation


        //-----------------------------------------------------------------------
        // AddInfo()
        //-----------------------------------------------------------------------
        int iLabelCount = 0;
        int iLabelHeight = 13;
        private void AddInfo( GroupBox grpContainer, int piIndex, string pstrDescription, string pstrValue, string pstrUnit, ContentAlignment paliValueAlignment )
        { 
            Label lblDescription = new Label(); 
            grpContainer.Controls.Add( lblDescription );
            lblDescription.Location = new Point( 6, Convert.ToInt32(iLabelHeight * (1.5 + piIndex)) ); 
            lblDescription.Name = "labell" + (iLabelCount++).ToString();
            lblDescription.Size = new Size( 67, iLabelHeight );   
            lblDescription.AutoSize = true;             
            lblDescription.Text = pstrDescription;
            lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            
            Label lblValue = new Label(); 
            grpContainer.Controls.Add( lblValue );
            lblValue.Name = "label" + (iLabelCount++).ToString();
            lblValue.Size = new Size( 53, iLabelHeight );
            lblValue.Location = new Point( 80, Convert.ToInt32(iLabelHeight * (1.5 + piIndex)) ); 
            //lblValue.AutoSize = true; 
            lblValue.TextAlign = paliValueAlignment; 
            lblValue.Text = pstrValue;

            Label lblUnit = new Label(); 
            grpContainer.Controls.Add( lblUnit );
            lblUnit.Name = "label" + (iLabelCount++).ToString();
            lblUnit.Size = new Size( this.Width - 130 - 10/*67*/, iLabelHeight );
            lblUnit.Location = new Point( 130, Convert.ToInt32(iLabelHeight * (1.5 + piIndex)) ); 
            lblUnit.Text = pstrUnit;
        }// AddInfo()


        //-----------------------------------------------------------------------
        // ClearInfo()
        //-----------------------------------------------------------------------
        private void ClearInfo()
        {
            iLabelCount = 0;

            grpHex.Controls.Clear();
            grpDevice.Controls.Clear();
            grpBootloader.Controls.Clear();
        }// ClearInfo()


        //-----------------------------------------------------------------------
        // UpdateInfo()
        //-----------------------------------------------------------------------
        public void UpdateInfo( clsDevice pobjDevice, clsHex pobjHex, clsParseSettings pobjParseSettings )
        {
            ClearInfo();


            //-----------------------------------------------------------------
            // Device
            //-----------------------------------------------------------------
            if ( pobjDevice != null ) {
                int iIndex = 0;

                // Flash size
                AddInfo( grpDevice, iIndex++, "Flash size:", Math.Round(pobjDevice.flashSizeB / 1024.0, 1).ToString(), "kB", ContentAlignment.MiddleRight );

                // Eeprom size
                string strEepromSize, strEepromSizeUnit;
                if ( pobjDevice.eepromSizeB == 0 ) {
                    strEepromSize = Math.Round(0.0, 1).ToString();
                    strEepromSizeUnit = "kB";
                } else if ( pobjDevice.eepromSizeB < 1024 ) {
                    strEepromSize = pobjDevice.eepromSizeB.ToString();
                    strEepromSizeUnit = "B";
                } else {
                    strEepromSize = Math.Round(pobjDevice.eepromSizeB / 1024.0, 1).ToString();
                    strEepromSizeUnit = "kB";
                }
                AddInfo( grpDevice, iIndex++, "Eeprom size:", strEepromSize, strEepromSizeUnit, ContentAlignment.MiddleRight );

                if ( pobjDevice.pageSizeR > 1 ) {
                    AddInfo( grpDevice, iIndex++, "Page size:", pobjDevice.pageSizeR.ToString(), "rows", ContentAlignment.MiddleRight );
                }
                AddInfo( grpDevice, iIndex++, "Row size:", pobjDevice.rowSizeW.ToString(), "words", ContentAlignment.MiddleRight );
                AddInfo( grpDevice, iIndex++, "Word size:", pobjDevice.family.flashWordSizeBits.ToString(), "bits", ContentAlignment.MiddleRight );

                //
                grpDevice.Height = (iIndex+3) * iLabelHeight;
            }
            
            
            //-----------------------------------------------------------------
            // Hex-file
            //-----------------------------------------------------------------
            if ( pobjHex != null && File.Exists(pobjHex.filename) == true ) {
                // Position groupbox
                grpHex.Top = grpDevice.Top + grpDevice.Height + iLabelHeight;

                //
                int iIndex = 0;
                //AddInfo( grpHex, iIndex++, "Timestamp:", File.GetLastWriteTime(pobjHex.filename).ToString(), "", ContentAlignment.MiddleLeft );
                if ( pobjDevice.pageSizeR > 1 ) {
                    AddInfo( grpHex, iIndex++, "Pages:", pobjHex.progPagesUsed.ToString(), "/ " + pobjDevice.flashSizeP.ToString(), ContentAlignment.MiddleRight );
                }
                AddInfo( grpHex, iIndex++, "Rows:", pobjHex.progRowsUsed.ToString(), "/ " + pobjDevice.flashSizeR.ToString(), ContentAlignment.MiddleRight );
                AddInfo( grpHex, iIndex++, "Eeprom words:", pobjHex.eeWordsUsed.ToString(), "/ " + (pobjDevice.eepromSizeB / pobjDevice.family.eepromWordSizeB).ToString(), ContentAlignment.MiddleRight );
                AddInfo( grpHex, iIndex++, "Configs words:", pobjHex.configWordsUsed.ToString(), "", ContentAlignment.MiddleRight );
                AddInfo( grpHex, iIndex++, "Appl. address:", "0x" + pobjHex.userApplAddress.ToString("X4"), "", ContentAlignment.MiddleRight );

                //
                grpHex.Height = (iIndex+3) * iLabelHeight;
            }

            
            //-----------------------------------------------------------------
            // Bootloader
            //-----------------------------------------------------------------
            if ( pobjDevice != null && pobjHex != null && File.Exists(pobjHex.filename) == true ) {
                // Position groupbox
                grpBootloader.Top = grpDevice.Top + grpDevice.Height + iLabelHeight + grpHex.Height + iLabelHeight;

                //
                int iIndex = 0;
                
                int iStartRow = pobjHex.GetBootloaderStartRow(pobjParseSettings);
                int iEndRow = pobjHex.GetBootloaderEndRow(pobjParseSettings);
                int iStartPage = iStartRow / pobjParseSettings.device.pageSizeR;
                int iEndPage = iEndRow / pobjParseSettings.device.pageSizeR;

                AddInfo( grpBootloader, iIndex++, "Start address:", "0x" + pobjHex.GetBootloaderStartAddress(pobjParseSettings).ToString("X2"), "", ContentAlignment.MiddleRight );
                if ( pobjDevice.pageSizeR > 1 ) {
                    AddInfo( grpBootloader, iIndex++, "Start page:", iStartPage.ToString(), "", ContentAlignment.MiddleRight );
                    AddInfo( grpBootloader, iIndex++, "End page:", iEndPage.ToString(), "", ContentAlignment.MiddleRight );
                }
                AddInfo( grpBootloader, iIndex++, "Start row:", iStartRow.ToString(), "", ContentAlignment.MiddleRight );
                AddInfo( grpBootloader, iIndex++, "End row:", iEndRow.ToString(), "", ContentAlignment.MiddleRight );

                //
                grpBootloader.Height = (iIndex+3) * iLabelHeight;
            }
            this.Height =  SystemInformation.CaptionHeight + 2*SystemInformation.BorderSize.Width + grpDevice.Height + 3*iLabelHeight + grpHex.Height + grpBootloader.Height;


            this.Invalidate();
        }// UpdateInfo()

    }// Class: frmInfo
}