﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader GUI.
//
//    ds30 Loader GUI is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader GUI is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader GUI.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace ds30_Loader_GUI
{
    //---------------------------------------------------------------------------
    // Class: clsRecentFile
    //---------------------------------------------------------------------------
    [XmlRoot("ds30LoaderRecentFile")]
    public class clsRecentFile 
    {
		//---------------------------------------------------------------------
		// Constructor
        //---------------------------------------------------------------------        
        public clsRecentFile() 
        {
            Reset();
        }// Constructor

        
        //---------------------------------------------------------------------
		// Constructor
        //---------------------------------------------------------------------        
        public clsRecentFile( string pstrFilename ) 
        {
	        Filename = pstrFilename;

            Reset();
        }// Constructor
        
        
        //---------------------------------------------------------------------
		// Reset()
        //---------------------------------------------------------------------        
        public void Reset() 
        {
            //
            AdvancedMode = false;
            //
            Portname = "COM1";
            Baudrate = "9600";
            RemoteId = "1";
            LocalId = "2";
            Familyname = "";
            Devicename = "";
            WriteProgram = false;
            WriteEeprom = false;
            //
            WriteConfigs = false;
            NoGoto = false;
            IgnoreBLOverwrite = false;
            CustomBl = false;
            CustomBlPlacementP = 0;
            CustomBlSizeP = 0;
            AutoBaudrate = false;
            EchoVerification = false;
            AddChecksum = false;
            //
            Polltime = "500";
            Timeout = "10000";
            //
            CommandReset = false;
            ResetCommand = "";
            ResetBaudrate = "9600";
            DTRReset = false;
            ManualReset = true;
            RTSReset = false;
            ResetTime = 0;
            //
            ActivateDTR = false;
            ActivateRTS = false;
            //
            TermSwithTo = false;
            TermBaudrate = "9600";  
            TermRxType = 0;
            TermTxType = 0;  
            TermTx = "";
        }// Reset()

        
        //---------------------------------------------------------------------
		// View options
        //---------------------------------------------------------------------
        public bool AdvancedMode { get; set; }


		//---------------------------------------------------------------------
		// Tab basic settings
        //---------------------------------------------------------------------
    	public string Filename { get; set; }
		public string Portname { get; set; }
		public string Baudrate { get; set; }
        public string RemoteId { get; set; }
        public string LocalId { get; set; }        
		public string Familyname { get; set; }
        public string Devicename { get; set; }
		public bool WriteProgram { get; set; }
        public bool WriteEeprom {   get; set; }            
        
		// Tab advanced
        public bool WriteConfigs { get; set; }
        public bool NoGoto { get; set; }
        public bool IgnoreBLOverwrite { get; set; }
        public bool CustomBl { get; set; }
        public int CustomBlPlacementP { get; set; }
        public int CustomBlSizeP { get; set; }
        public bool AutoBaudrate { get; set; }
        public bool EchoVerification { get; set; }
        public bool AddChecksum { get; set; }

		// Tab timing
        public string Polltime { get; set; }
        public string Timeout { get; set; }

		// Tab reset
        public bool CommandReset { get; set; }
        public string ResetCommand { get; set; }
        public string ResetBaudrate { get; set; }
        public bool DTRReset { get; set; }
        public bool ManualReset { get; set; }
        public bool RTSReset { get; set; }
        public int ResetTime { get; set; }

		// Tab activation
        public bool ActivateDTR { get; set; }
        public bool ActivateRTS { get; set; }

		// Tab terminal
        public bool TermSwithTo { get; set; }
        public string TermBaudrate { get; set; }
        public int TermRxType { get; set; }
        public int TermTxType { get; set; }
        public string TermTx { get; set; }

    }// Class: clsRecentFile
}
