﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader GUI
//
// Copyright:		Copyright © 08-10, Mikael Gustafsson
//
// Version:			1.3.12 september 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			1.3.12 Minor improvements
//                         Improvement: new version/port window
//                         Improvement: CAN ID's can be typed as hex values 0x0-0x7ff
//                  1.3.11 Bugfix: high cpu usage when no hex-file is selected and window gets focus after focus has been lost
//                         Bugfix: baudrates for download/reset/terminal was linked
//                  1.3.10 Bugfix: dialog box box showed up multiple times when a checking for new version and new version was available
//                         Improvement: settings are stored in user directory (Windows only)
//                  1.3.9 Bugfix: crash when showing and hiding info window when no device was selected
//                        Change: check for new version on startup has default value true
//                  1.3.8 Minor changes
//                  1.3.7 Minor changes (not officially released)
//                  1.3.6 Beta released with CAN support
//                        New feature: info window
//                        Improvement: added more high baud rates
//                        Improvement: advanced settings are not cleared when switching to basic mode (they're ignored on download)
//                        Minor improvements
//                  1.3.5 Bugfix: incorrect directory separator used for Mac OS X and Linux
//                        Bugfix: crash on startup in Linux and probably Mac (some problem in WinForms implementation)
//                        Bugfix: exception or graphics anomality when returning from micro mode on certain windows/themes
//                        Bugfix: exception handling for invalid terminal baudrate
//                        Changed: newline is not added for each receive in textmode (terminal)
//                        New feature: enumerating usb comports in mac                      
//                  1.3.4 Settings are remebered for each different file opened
//                        Some minor improvements
//                        Added default settings with the ability to lock settings, usefull for customer distribution
//                        Output textbox is automatically hidden when terminal is selected
//                  1.3.3 Fixed bug not able to open terminal until download or check for bl was done first
//                        Improved code for reparse of hex-file when window is activated
//                        Improved about window
//                        Improved check for version window
//                        Improved info output
//                        New graphical hex-file representation
//                  1.3.2 Fixed crash on Linux when settings.xml was present
//                  1.3.1 Fixed redraw bug that only showed up in xp using xp style visual theme
//                  1.3.0 Hex-file is reloaded (if needed) when window is activated
//                        Simple serial terminal emulator added
//                        Option to reset all settings to default
//                        New simple/advanced mode to not intimidate new users/beginners
//                  1.2.2 Settings are stored as xml (again)
//                        Process priority is raised during download if polltime is < 100ms
//                        Added Aboutbox
//                        Reworked check version and update, includes a new window on help menu
//                        More compact design
//                        Output textbox can be hidden
//                  1.2.1 Added check for new version on startup option
//                        Check for new version is improved
//                  1.2.0 Added device reset, decvice activation and time options
//                  1.1.0 Changes reflecting new ds30 Loader version
//                  1.0.4 Some improvements in clsSerialPort
//                        GUI and actual bootloader code is now separated
//                        clsSerialport and debugtext moved to separate helper library
//                  1.0.2 Added debugmode
//                        Added micro mode
//                        Added menuitems with shortcut keys
//                  1.0.1 Added check for latest version
//					0.9.7 Better error handling
//						  Remembers all settings now					
//					0.9.3 Application remebers settings now
//					0.9.2 Overall time performance ~65% faster						  
//						  Better debug output
//						  Abort button fixed
//					0.9.1 Added "check for bootloader" button
//					0.9.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader GUI.
//
//    ds30 Loader GUI is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader GUI is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader GUI.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------    

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.InteropServices;
using System.Net;
using GHelper;
using ds30Loader;


namespace ds30_Loader_GUI
{
	//-------------------------------------------------------------------------
	// Class: frmDS30Loader
	//-------------------------------------------------------------------------
	public partial class frmDS30Loader : Form
	{
		//---------------------------------------------------------------------
		// Public constants
		//---------------------------------------------------------------------	
		public const string strHexFileFilter = "Hex file|*.hex|All files (*.*)|*.*";
        public const string strURLHomepage = "http://mrmackey.no-ip.org/elektronik/ds30loader/";
        private const string strVersion = "1.3.12";
        static public Version verGUI = null;

        // Used for dragging form without caption bar, windows only
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

		
		//---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
        private IPort objPort = null;	
        private Size sizeBeforeMicro;
        public clsSettings objSettings = null;
        private clsHex objHex = null;
        private clsDownloadSettings objds30LSettings = null;
        private clsRecentFiles objRecentFiles = null;
        private bool bDoParse = false;
        private bool bStartup = true;
        private string strPrevFile = string.Empty;
        private frmInfo wndInfo = null;

				
		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public frmDS30Loader()
		{
			bDoParse = false;
            InitializeComponent();

            //---------------------------------------------------------------------	
            // Create objects
            //---------------------------------------------------------------------	
            verGUI = new Version( strVersion );            
            sizeBeforeMicro = new Size();
		    objds30LSettings = new clsDownloadSettings();
            objRecentFiles = new clsRecentFiles();

            
            //---------------------------------------------------------------------	
            // Init
            //---------------------------------------------------------------------
            clsDebugTextbox.SetTextbox( this.txtInfo );            
            progressBar.Visible = false;
            toolStrip1.Visible = false;			
            progressBar.Minimum = 0;
            progressBar.Maximum = 100;
            lblVersion.Text = verGUI.ToString();
            cboTermTxType.SelectedIndex = 0;
            cborTermRxType.SelectedIndex = 0;       
     
            
            //---------------------------------------------------------------------	
            // Load setttings
			//---------------------------------------------------------------------	
            {
                string strPath = GetSettingsFilesPath();
			    string strSettingsFilename = strPath + Path.DirectorySeparatorChar + "settings.xml";  
                string strPathRecentFiles = strPath;
                LoadSettings( strSettingsFilename );		
	            objRecentFiles.SetComboBox( cboFiles );
                objRecentFiles.LoadFiles( strPath );


                //
                if ( cboPort.Text == string.Empty && cboPort.Items.Count > 0 ) {
                    cboPort.SelectedIndex = 0;
                }
                if ( cboTestResponse.Items.Count > 0 ) {
                    cboTestResponse.SelectedIndex = 0;
                }
            }                
            
            {
                // Base path
                string strBasePath = Application.StartupPath;
                if ( strBasePath.EndsWith(Path.DirectorySeparatorChar.ToString()) == false ) {
                    strBasePath += Path.DirectorySeparatorChar;
                }

                //---------------------------------------------------------------------	
                // Init device database
                //---------------------------------------------------------------------	
                clsDeviceDb.ImportDeviceDB( strBasePath + "devices.xml" );


                //---------------------------------------------------------------------	
			    // Init ports
                //---------------------------------------------------------------------	
                clsds30LoaderPorts.Init( strBasePath, /*objSettings.EnabledPorts,*/ 0 );
                cboPort.DataSource = clsds30LoaderPorts.ports;
            }

            //---------------------------------------------------------------------	
			// CAN device id 
            //---------------------------------------------------------------------	
            {   for ( int iId = 1; iId <= 127; iId++ ) {
                    cboRemoteId.Items.Add( iId.ToString() );
                    cboLocalId.Items.Add( iId.ToString() );
                }
            }


            //---------------------------------------------------------------------	
			// Add device families to combobox
            //---------------------------------------------------------------------	
            {
                Hashtable htDeviceFamilys = clsDeviceDb.DeviceFamiliesGet();
			    foreach ( clsDeviceFamily objDeviceFamily in htDeviceFamilys.Values ) {
				    cboFamily.Items.Add( objDeviceFamily.name );
			    }
            }
            

            //---------------------------------------------------------------------	
            // 
			//---------------------------------------------------------------------	            
            clsds30Loader.Downloading += new clsds30Loader.DownloadingDelegate( ds30L_Downloading );


            //---------------------------------------------------------------------	
            // Startup finished
            //---------------------------------------------------------------------	
			bDoParse = true;
		}//Constructor		
	
				
        //---------------------------------------------------------------------
		// Abort()
		// Description:
		//---------------------------------------------------------------------
		public void Abort()		
        {
            clsds30Loader.Abort();
        }//Abort()
	
				
        //---------------------------------------------------------------------
		// AboutWindowOpen()
		// Description:
		//---------------------------------------------------------------------
		public void AboutWindowOpen()		
        {
            frmAbout objAbout = new frmAbout( ref objSettings );
            objAbout.ShowDialog( this );
        }//AboutWindowOpen()	

				
        //---------------------------------------------------------------------
		// CheckLatestVersion()
		//---------------------------------------------------------------------
		public void CheckLatestVersion()		
        {
            //
            clsLatestVersionInfo objLatestVersionInfo = new clsLatestVersionInfo();
            if ( objLatestVersionInfo.CheckLatestVersion() == false ) return;

            //
            string strMsgBoxTitle = "Check for latest version";


            //-----------------------------------------------------------------
            // New version?
            //-----------------------------------------------------------------   
            if ( new Version(clsds30Loader.strVersion) < objLatestVersionInfo.verds30Loader || verGUI < objLatestVersionInfo.verds30LoaderGUI ) {  
                // Message
                string strMessage = string.Empty;
                if ( objLatestVersionInfo.latestVersionInfo != string.Empty ) {
                    strMessage = "Info: " + objLatestVersionInfo.latestVersionInfo + Environment.NewLine;
                }


                //-------------------------------------------------------------
                // Update or download is not allowed
                //-------------------------------------------------------------
                if ( objLatestVersionInfo.allowUpdate == false && objLatestVersionInfo.allowDownload == false ) {
                    string strQuestion = 
                        "A new version is available" + Environment.NewLine + 
                        strMessage + Environment.NewLine +
                        "Do you want to visit the homepage?"
                    ;  
                    DialogResult dgrDownload = MessageBox.Show( strQuestion, strMsgBoxTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question );
                    if ( dgrDownload == DialogResult.Yes ) {  
                        frmDS30Loader.VisitHomepage();
                    }   
             

                //-------------------------------------------------------------
                // Download allowed
                //-------------------------------------------------------------
                } else if ( objLatestVersionInfo.allowDownload == true ) {
                    string strQuestion = 
                        "A new version is available" + Environment.NewLine + 
                        strMessage + Environment.NewLine +
                        "Do you want to download the new package?"
                        
                    ;  
                    DialogResult dgrDownload = MessageBox.Show( strQuestion, strMsgBoxTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question );               
                    if ( dgrDownload == DialogResult.Yes ) {  
                         DownloadLatestPackage( objLatestVersionInfo ); 
                    } 
                

                //-------------------------------------------------------------
                // Auto update allowed
                //-------------------------------------------------------------
                } else if ( objLatestVersionInfo.allowUpdate == true ) {
                    string strQuestion = 
                        "A new version is available" + Environment.NewLine + 
                        strMessage + Environment.NewLine +
                        "Do you want to update to the new version?"
                    ;  
                    DialogResult dgrAutoUpdate = MessageBox.Show( strQuestion, strMsgBoxTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2 );
                    
                    if ( dgrAutoUpdate == DialogResult.Yes ) { 
                        UpdateGUI( objLatestVersionInfo );
                    }  
                }
            }
        }// CheckLatestVersion()


        //---------------------------------------------------------------------
		// DownloadLatestPackage()
		// Description:
		//---------------------------------------------------------------------
		static public void DownloadLatestPackage( clsLatestVersionInfo objLatestVersionInfo )
		{	
            System.Diagnostics.Process.Start( objLatestVersionInfo.urlLatestPackage );
        }// DownloadLatestPackage()


		//---------------------------------------------------------------------
		// CheckForBL()
		// Description:
		//---------------------------------------------------------------------
		private void CheckForBL()
		{	
            //-----------------------------------------------------------------
			// Find device
            //-----------------------------------------------------------------
			clsDevice objDevice = (clsDevice)cboDevice.SelectedItem;
			if ( objDevice == null ) {
                clsDebugTextbox.OutputError( "No device selected", 0 );
                return;
            }

            //
			clsDebugTextbox.ClearTextbox();

            
            //-----------------------------------------------------------------
            // Setup settings
            //-----------------------------------------------------------------   
            bool bSetupDS30LSettingsResult = false;
            SetupDS30LSettings( ref bSetupDS30LSettingsResult );
            if ( bSetupDS30LSettingsResult == false ) {
                clsDebugTextbox.OutputInfo( "Check for bootloader aborted", 0 );
                return;
            }

            //
			txtInfo.Focus();
            EnableDownloadMode();
			
            //
            Version verFw = null;
            bool bFindLoaderResult = false;
            clsds30Loader.FindLoader( objDevice, objds30LSettings, ref verFw, 0, ref bFindLoaderResult );
            
            //
            progressBar.Visible = false;
            DisableDownloadMode();
        }//CheckForBL()
        
        
        //---------------------------------------------------------------------
		// CreatePort()
		// Description: gets a port object from the selected port name
		//---------------------------------------------------------------------
		private void CreatePort()
		{	
            // Check port name
            string strPortName = cboPort.Text.Trim();
            if ( strPortName == string.Empty ) {
                objPort = null;
                return;
            }

            // Create port
            objPort = clsds30LoaderPorts.GetPortObjectFromName( cboPort.Text );

            // Check port object
            if ( objPort == null ) {
                clsDebugTextbox.OutputError( "Failed to create port with name " + cboPort.Text, 0 );
                return;
            }            
        }//CreatePort() 

           
		//---------------------------------------------------------------------
		// DisablePortUsage()
		// Description: disable functionality that requires a selected port
		//---------------------------------------------------------------------
		private void DisablePortUsage()
		{			
            //txtInfo.Enabled = false;

            btnCheck.Enabled = false;
            mnuCmdCheckForBl.Enabled = false;
            
            btnDownload.Enabled = false;
            btnDownload2.Enabled = false;
            mnuCmdDownload.Enabled = false;

            btnTermOpen.Enabled = false;
        }//DisableDownload()


		//---------------------------------------------------------------------
		// DisableDownloadMode()
		// Description: enables controls after download
		//---------------------------------------------------------------------
		private void DisableDownloadMode()
		{			
            //txtInfo.Enabled = true;
            btnCheck.Enabled = true;
			mnuCmdCheckForBl.Enabled = true;

            btnDownload.Enabled = true;
            btnDownload2.Enabled = true;
            mnuCmdDownload.Enabled = true; 

            btnReparseHexFile.Enabled = true;
            mnuCmdReparse.Enabled = true;
            
            btnAbort.Enabled = false;
            mnuCmdAbort.Enabled = false;
            
            tabControl1.Enabled = true;
        }//DisableDownloadMode()


		//---------------------------------------------------------------------
		// Download()
		// Description:
		//---------------------------------------------------------------------
		private void Download()
		{			
            //-----------------------------------------------------------------
            // Nothing to do?
            //-----------------------------------------------------------------
			if ( chkWriteProgram.Checked == false && chkWriteEeprom.Checked == false && chkWriteConfigs.Checked == false  ) {
				MessageBox.Show( "Nothing to do.", "Download", MessageBoxButtons.OK, MessageBoxIcon.Information );
				return;
			}


            //-----------------------------------------------------------------
            // Nonexisting file?
            //-----------------------------------------------------------------
            if ( File.Exists(cboFiles.Text) == false || cboFiles.Text.Trim().Equals(string.Empty) == true ) {
                clsDebugTextbox.OutputError( "Hex-file does not exists.", 0 );
                return;
            }
		

            //-----------------------------------------------------------------
			// Find device
            //-----------------------------------------------------------------
			clsDevice objDevice = (clsDevice)cboDevice.SelectedItem;
			if ( objDevice == null ) {
                clsDebugTextbox.OutputError( "No device selected", 0 );
                return;
            }
            
            
            //
            clsDebugTextbox.ClearTextbox();

            
            //-----------------------------------------------------------------
            // Setup settings
            //-----------------------------------------------------------------            
            bool bSetupDS30LSettingsResult = false;
            SetupDS30LSettings( ref bSetupDS30LSettingsResult );
            if ( bSetupDS30LSettingsResult == false ) {
                clsDebugTextbox.OutputInfo( "Download aborted.", 0 );
                return;
            }

            
            //-----------------------------------------------------------------
            //
            //-----------------------------------------------------------------
			txtInfo.Focus();			
            EnableDownloadMode();

  
            //-----------------------------------------------------------------
            // Download
            //-----------------------------------------------------------------
            bool bDownloadResult = false;
            clsds30Loader.Download( objDevice, objHex, objds30LSettings, 0, ref bDownloadResult );


            //-----------------------------------------------------------------
            // Download finished
            //-----------------------------------------------------------------                                    
            progressBar.Visible = false;
            DisableDownloadMode();


            //-----------------------------------------------------------------
            // Open terminal?
            //-----------------------------------------------------------------            
            if ( chkTermSwitchTo.Checked == true && bDownloadResult == true ) {
                btnTermOpen_Click( null, null );
                tabControl1.SelectedTab = tabTerminal;
            }
        }//Download()


		//---------------------------------------------------------------------
		// EnablePortUsage()
		// Description: enables download button
		//---------------------------------------------------------------------
		private void EnablePortUsage()
		{			
            btnCheck.Enabled = true;
            mnuCmdCheckForBl.Enabled = true;
            
            btnDownload.Enabled = true;
            btnDownload2.Enabled = true;
            mnuCmdDownload.Enabled = true;

            btnTermOpen.Enabled = true;
        }//EnablePortUsage()


		//---------------------------------------------------------------------
		// EnableDownloadMode()
		// Description: disables controls during download
		//---------------------------------------------------------------------
		private void EnableDownloadMode()
		{			
            //txtInfo.Enabled = false;
            btnCheck.Enabled = false;
            mnuCmdCheckForBl.Enabled = false;
            
            btnDownload.Enabled = false;
            btnDownload2.Enabled = false;
            mnuCmdDownload.Enabled = false;  

            btnReparseHexFile.Enabled = false;
            mnuCmdReparse.Enabled = false;

            btnAbort.Enabled = true;            
            mnuCmdAbort.Enabled = true;

            tabControl1.Enabled = false;

            // Make sure output is visible
            if ( btnShowOutput.Checked == false ) {
                btnShowOutput.Checked = true;
            }
        }//EnableDownloadMode()


 		//---------------------------------------------------------------------
		// ds30L_Downloading()
		//---------------------------------------------------------------------
        private void ds30L_Downloading( object obj, clsDownloadingEventArgs e ) 
        {
            switch ( e.eventType ) {
	           case clsDownloadingEventArgs.EventType.started:
                    clsDebugTextbox.OutputInfo( e.message, e.tabLevel );
                    break;
                
                case clsDownloadingEventArgs.EventType.error:
                    clsDebugTextbox.OutputError( e.message, e.tabLevel );
                    break;

                case clsDownloadingEventArgs.EventType.warning:
                    clsDebugTextbox.OutputWarning( e.message, e.tabLevel );
                    break;
                
                case clsDownloadingEventArgs.EventType.info:
                    clsDebugTextbox.OutputInfo( e.message, e.tabLevel );
                    break;

                case clsDownloadingEventArgs.EventType.success:
                    clsDebugTextbox.OutputSuccess( e.message, e.tabLevel );
                    break;

                case clsDownloadingEventArgs.EventType.progressStarted:
                    progressBar.Value = e.tabLevel;
                    progressBar.Visible = true;
                    break;
                
                case clsDownloadingEventArgs.EventType.progress:
                    progressBar.Value = e.tabLevel;
                    break;
                
                case clsDownloadingEventArgs.EventType.progressEnded:
                    progressBar.Value = 0;
                    progressBar.Visible = false;   
                    break;         

                case clsDownloadingEventArgs.EventType.completed:
                    clsDebugTextbox.OutputSuccess( e.message, e.tabLevel );
                    break;

                default:
                    clsDebugTextbox.OutputError( "Unknown download event", e.tabLevel );
                    break;
            }            
        }//ds30L_Downloading()	


		//---------------------------------------------------------------------
		// Hex_Parse()
		//---------------------------------------------------------------------
		private void Hex_Parse( object obj, clsHexFileParseEventArgs e ) 
        { 
            clsHex objHex = (clsHex)obj;

			switch ( e.eventType ) {
                
                case clsHexFileParseEventArgs.EventType.started:
                    clsDebugTextbox.OutputInfo( "Parsing hex-file...", e.tabLevel );
                    break;

                case clsHexFileParseEventArgs.EventType.warning:
                    clsDebugTextbox.OutputWarning( e.message, e.tabLevel );
                    break;
                
                case clsHexFileParseEventArgs.EventType.info:
                    clsDebugTextbox.OutputInfo( e.message, e.tabLevel );
                    break;
                
                case clsHexFileParseEventArgs.EventType.failed:
                    clsDebugTextbox.OutputError( "Parsing of hex-file failed", e.tabLevel );   
                    break;             

                case clsHexFileParseEventArgs.EventType.success:
                    clsDebugTextbox.OutputSuccess( "Hex-file successfully parsed", e.tabLevel );
                    clsDebugTextbox.OutputInfo( "", 0 );
                    clsDebugTextbox.OutputInfo( objHex.progWordsUsed.ToString() + " program words found in " + objHex.progRowsUsed.ToString() + " rows ", e.tabLevel );
                    clsDebugTextbox.OutputInfo( objHex.eeWordsUsed.ToString() + " Eeprom words found ", e.tabLevel);
                    clsDebugTextbox.OutputInfo( objHex.configWordsUsed.ToString() + " config words found ", e.tabLevel );			
                    break;

                default:
                    clsDebugTextbox.OutputError( "Unknown hex parse event", e.tabLevel );    
                    break;            
            }            
		}//Hex_Parse()	


        //---------------------------------------------------------------------
		// Hex_Validate()
		//---------------------------------------------------------------------
		private void Hex_Validate( object obj, clsHexFileValidateEventArgs e ) 
        {
            switch ( e.eventType ) {
			    case clsHexFileValidateEventArgs.EventType.started:
                    clsDebugTextbox.OutputInfo( "Validating hex-file...", e.tabLevel );
                    break;
            
                case clsHexFileValidateEventArgs.EventType.failed:
                    clsDebugTextbox.OutputError( e.message );
                    break;

                case clsHexFileValidateEventArgs.EventType.success:
                    clsDebugTextbox.OutputSuccess( "ok" );
                    break;
 
                default:
                    clsDebugTextbox.OutputError( "Unknown hex validate event", e.tabLevel );    
                    break;               
            }
		}//Hex_Validate()	


		//---------------------------------------------------------------------
		// DoParse()
		// Description:
		//---------------------------------------------------------------------
		public void DoParse( bool pbForce )
		{	
            if ( bDoParse == false ) {
                return;
            }    

            // Check file existence
            string strFilename = cboFiles.Text.Trim();
            if ( File.Exists(cboFiles.Text) == false || strFilename == string.Empty ) {
                return;
            }  

            // Change cursor
            this.UseWaitCursor = true;

            // Setup parse settings            
            clsParseSettings objParseSettings = null; bool bSetupParseSettingsResult = false;
            SetupParseSettings( ref objParseSettings, ref bSetupParseSettingsResult );
            if ( bSetupParseSettingsResult == false ) {
                this.UseWaitCursor = false;
                return;
            }

            // Clear info textbox
            clsDebugTextbox.ClearTextbox();
            
            // Subscribe to events and do parse
            clsHex.HexFileValidateDelegate a = new clsHex.HexFileValidateDelegate( Hex_Validate ); objHex.HexFileValidate += a;
            clsHex.HexFileParseDelegate b = new clsHex.HexFileParseDelegate( Hex_Parse ); objHex.HexFileParse += b;
            bool bParseResult = false;
            objHex.filename = cboFiles.Text;
            
            //EnableDownloadMode();//some windows exception occurs if info window is clicked during parsing
			objHex.ParseHexFile( objParseSettings, pbForce, 0, ref bParseResult );            
            
            
            objHex.HexFileValidate -= a; objHex.HexFileParse -= b;        

            // Apply parse result
            if ( bParseResult == false ) {
                objHex = null;
            } else {	
		        UpdateInfoWindow();
        
			    if ( objHex.hasValidProgram ) {
                    if ( objSettings.DefaultStartSettings.WriteProgramAllow == true ) {
				        chkWriteProgram.Enabled = true;
                    } else {
                        chkWriteProgram.Enabled = objSettings.DefaultStartSettings.WriteProgram;
                    }
			    } else {
				    chkWriteProgram.Enabled = false;
				    chkWriteProgram.Checked = false;
			    }

			    if ( objHex.hasValidEeprom ) {
                    if ( objSettings.DefaultStartSettings.WriteEepromAllow == true ) {
				        chkWriteEeprom.Enabled = true;
                    } else {
                        chkWriteEeprom.Enabled = objSettings.DefaultStartSettings.WriteEeprom;
                    }
			    } else {
				    chkWriteEeprom.Enabled = false;
				    chkWriteEeprom.Checked = false;
			    }
    			
			    if ( objHex.hasValidConfigs ) {
                    if ( objSettings.DefaultStartSettings.WriteConfigsAllow == true ) {
				        chkWriteConfigs.Enabled = true;
                    } else {
                        chkWriteConfigs.Enabled = objSettings.DefaultStartSettings.WriteConfigs;
                    }
			    } else {
				    chkWriteConfigs.Enabled = false;
				    chkWriteConfigs.Checked = false;
			    }	
            }
			
			// Redraw graphical hex representation and restore mouse cursor
            picHexContent.Refresh();
            this.UseWaitCursor = false;
		}//DoParse( false );


        //-------------------------------------------------------------------------
        // GetSettingsFilesPath()
        // Description: returns true if the selected port is a can port
        //-------------------------------------------------------------------------
        public string GetSettingsFilesPath() 
        {
            string strPath = string.Empty;
            string strAppDataPath = Environment.GetFolderPath( Environment.SpecialFolder.ApplicationData );


            if ( GHelper.clsMisc.HostIsWindows() && strAppDataPath != string.Empty ) {
                strPath = strAppDataPath + "\\ds30 Loader";
            } else {
                strPath = Application.StartupPath;
            }

            if ( Directory.Exists(strPath) == false ) {
                try {
                    Directory.CreateDirectory( strPath );
                } catch ( Exception e ) {
                    MessageBox.Show( "Failed to create settings directory " + strPath, "ds30 Loader" + Environment.NewLine + e.Message,  MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                }
            }

            return strPath;
        }// GetSettingsFilesPath()
    
    
        //-------------------------------------------------------------------------
        // IsCanPortSelected()
        // Description: returns true if the selected port is a can port
        //-------------------------------------------------------------------------
        public bool IsCanPortSelected() 
        {
            return cboPort.Text.ToLower().Contains("can");
        }// IsCanPortSelected()


		//-------------------------------------------------------------------------
        // LoadSettings()
        // Description: 
        //-------------------------------------------------------------------------
        public bool LoadSettings( string pstrFilename ) 
        {
			//-----------------------------------------------------------------
			// No previous settings
			//-----------------------------------------------------------------
			if ( File.Exists(pstrFilename) == false ) {
                objSettings = new clsSettings();

			
			//-----------------------------------------------------------------
			// Load settings
			//-----------------------------------------------------------------            
            } else {            
                clsDebugTextbox.OutputInfo( "Loading settings...", 0 );

                XmlSerializer xmlSerializer = new XmlSerializer( typeof( clsSettings ) );
                TextReader textReader = new StreamReader( pstrFilename );
                bool bLoadSettingsFailed = false;
                try {                
                    objSettings = (clsSettings)xmlSerializer.Deserialize( textReader );
                } catch {
                    clsDebugTextbox.OutputResult( false );
                    objSettings = new clsSettings();
                    bLoadSettingsFailed = true;

                }
                if ( textReader != null ) {
                    textReader.Close();
                }
                if ( bLoadSettingsFailed == false ) {
                    clsDebugTextbox.OutputResult( true );
                }
            }


			//-----------------------------------------------------------------
			// Apply settings
			//-----------------------------------------------------------------
			
            // View options
			mnuViewOntop.Checked = objSettings.WindowOnTop;

			
            // Window size
			if ( objSettings.WindowWidth > 200 ) {
                this.Width = objSettings.WindowWidth;
            }
			if ( objSettings.WindowHeight > 200 ) {
                this.Height = objSettings.WindowHeight;
            }
            
            // Tab basic 
            cboFiles.Text = objSettings.Filename;

            
			//-----------------------------------------------------------------
			// Apply default settings
			//-----------------------------------------------------------------
            ResetSettingsToDefault();        


			//-----------------------------------------------------------------
			// Finished
			//-----------------------------------------------------------------
            return true;
		}//LoadSettings()  


		//-------------------------------------------------------------------------
		// OpenFile()
		//-------------------------------------------------------------------------
		public void OpenFile( string pstrFilename )
		{
            if ( File.Exists(pstrFilename) == false ) {
                objRecentFiles.RemoveFile( pstrFilename );
                return;
            }

            bDoParse = false;


            // ----------------------------------------------------------------
            // Manage recent file list
            // ----------------------------------------------------------------
            clsRecentFile objRecentFile = null;
            bool bExistingRecentFile = false;
            objRecentFiles.AddFile( pstrFilename, ref objRecentFile, ref bExistingRecentFile );
            strPrevFile = cboFiles.Text;


            // ----------------------------------------------------------------
            // If the file isn't a recent file, copy settings from gui
            // ----------------------------------------------------------------
            if ( bExistingRecentFile == false ) {
                UpdateRecentFile( objRecentFile );
            

            // ----------------------------------------------------------------
            // It's a recent file, apply settings
            // ----------------------------------------------------------------
            } else {
                // View
                mnuViewAdvanced.Checked = objRecentFile.AdvancedMode;
                
                // Tab basic 
			    cboPort.Text = objRecentFile.Portname;
			    cboBaudrate.Text = objRecentFile.Baudrate;
			    cboFamily.Text = objRecentFile.Familyname;
                cboDevice.SelectedItem = clsDeviceDb.DeviceGet( cboFamily.Text + objRecentFile.Devicename );
                cboRemoteId.Text = objRecentFile.RemoteId;
                cboLocalId.Text = objRecentFile.LocalId;
                
                // Write options
			    chkWriteProgram.Checked = objRecentFile.WriteProgram;
			    chkWriteEeprom.Checked = objRecentFile.WriteEeprom;
			    chkWriteConfigs.Checked = objRecentFile.WriteConfigs;
			    chkNoGoto.Checked = objRecentFile.NoGoto;                

                // Tab advanced
                chkWriteConfigs.Checked = objRecentFile.WriteConfigs;
			    chkNoGoto.Checked = objRecentFile.NoGoto;             
                chkAllowBlOverwrite.Checked = objRecentFile.IgnoreBLOverwrite;
                chkCustomBl.Checked = objRecentFile.CustomBl;
                txtCustomBlPlacementP.Text = objRecentFile.CustomBlPlacementP.ToString();
                txtCustomBlSizeP.Text = objRecentFile.CustomBlSizeP.ToString();
                chkAutoBaud.Checked = objRecentFile.AutoBaudrate;
                chkEcho.Checked = objRecentFile.EchoVerification;
                chkAddCRC.Checked = objRecentFile.AddChecksum;

                // Tab timing
                txtPolltime.Text = objRecentFile.Polltime;
                txtTimeout.Text = objRecentFile.Timeout;

                // Tab rest
                rdbResetCommand.Checked = objRecentFile.CommandReset;
                txtResetCommand.Text = objRecentFile.ResetCommand;
                cboResetBaudrate.Text = objRecentFile.ResetBaudrate;
                rdbResetDtr.Checked = objRecentFile.DTRReset;
                rdbResetManual.Checked = objRecentFile.ManualReset;
                rdbResetRts.Checked = objRecentFile.RTSReset;
                txtResettime.Text = objRecentFile.ResetTime.ToString();

                // Tab device activation
                rdbActivateDTR.Checked = objRecentFile.ActivateDTR;
                rdbActivateRTS.Checked = objRecentFile.ActivateRTS;

                // Tab terminal
                cboTermBaudrate.Text = objRecentFile.TermBaudrate;
                chkTermSwitchTo.Checked = objRecentFile.TermSwithTo;
                cborTermRxType.SelectedIndex = objRecentFile.TermRxType;
                cboTermTxType.SelectedIndex = objRecentFile.TermTxType;
                txtTermTx.Text = objRecentFile.TermTx;
            }

            // ----------------------------------------------------------------
            // Do actual opening of the hex-file
            // ----------------------------------------------------------------
            bDoParse = true;
            DoParse( false );
		}// OpenFile()

		
        //-------------------------------------------------------------------------
		// ParseDecimalOrHexString()
		//-------------------------------------------------------------------------
		public uint ParseDecimalOrHexString( string strString, ref bool pbResult)
		{        
            pbResult = true;
            try {
                if ( strString.Length < 2 ) {
                    return uint.Parse( strString );
                } else if ( strString.Substring(0, 2).Equals("0x") ) {
                    return uint.Parse( strString.Substring(2, strString.Length-2), System.Globalization.NumberStyles.HexNumber );
                } else {
                    return uint.Parse( strString );
                }
            } catch {
                pbResult = false;
                return 0;
            }            	
        }// ParseDecimalOrHexString()


		//-------------------------------------------------------------------------
		// ResetSettingsToDefault()
		//-------------------------------------------------------------------------
		public void ResetSettingsToDefault()
		{
            // Menu options
            mnuOptDebugmode.Checked = false;


            // Menu view            
            mnuViewAdvanced.Checked = objSettings.DefaultStartSettings.AdvancedMode;                
            mnuViewAdvanced.Enabled = objSettings.DefaultStartSettings.AdvancedModeAllow;
            
            
            // Tab basic 
	        cboPort.Text    = objSettings.DefaultStartSettings.Portname;
            cboPort.Enabled = objSettings.DefaultStartSettings.PortnameAllow;

	        cboBaudrate.Text    = objSettings.DefaultStartSettings.Baudrate;
            cboBaudrate.Enabled = objSettings.DefaultStartSettings.BaudrateAllow;

	        cboFamily.Text    = objSettings.DefaultStartSettings.Familyname;
            cboFamily.Enabled = objSettings.DefaultStartSettings.FamilynameAllow;

            cboDevice.SelectedItem = clsDeviceDb.DeviceGet( cboFamily.Text + objSettings.DefaultStartSettings.Devicename );
            cboDevice.Enabled      = objSettings.DefaultStartSettings.DevicenameAllow;

            
            // Write options
	        chkWriteProgram.Checked = objSettings.DefaultStartSettings.WriteProgram;
            chkWriteProgram.Enabled = objSettings.DefaultStartSettings.WriteProgramAllow;

	        chkWriteEeprom.Checked = objSettings.DefaultStartSettings.WriteEeprom;
            chkWriteEeprom.Enabled = objSettings.DefaultStartSettings.WriteEepromAllow;
	        

            // Tab advanced
            chkWriteConfigs.Checked = objSettings.DefaultStartSettings.WriteConfigs;
            chkWriteConfigs.Enabled = objSettings.DefaultStartSettings.WriteConfigsAllow;
            
            chkAllowBlOverwrite.Checked = objSettings.DefaultStartSettings.IgnoreBLOverwrite;
            chkAllowBlOverwrite.Enabled = objSettings.DefaultStartSettings.IgnoreBLOverwriteAllow;

	        chkNoGoto.Checked = objSettings.DefaultStartSettings.NoGoto;
            chkNoGoto.Enabled = objSettings.DefaultStartSettings.NoGotoAllow;

            chkCustomBl.Checked = objSettings.DefaultStartSettings.CustomBl;
            chkCustomBl.Enabled = objSettings.DefaultStartSettings.CustomBlAllow;
            
            txtCustomBlPlacementP.Text    = objSettings.DefaultStartSettings.CustomBlPlacementP.ToString();
            txtCustomBlPlacementP.Enabled = objSettings.DefaultStartSettings.CustomBlPlacementPAllow & objSettings.DefaultStartSettings.CustomBl;
            
            txtCustomBlSizeP.Text    = objSettings.DefaultStartSettings.CustomBlSizeP.ToString();
            txtCustomBlSizeP.Enabled = objSettings.DefaultStartSettings.CustomBlSizePAllow & objSettings.DefaultStartSettings.CustomBl;            

            chkAutoBaud.Checked = objSettings.DefaultStartSettings.AutoBaudRate;
            chkAutoBaud.Enabled = objSettings.DefaultStartSettings.AutoBaudRateAllow;
            
            chkEcho.Checked = objSettings.DefaultStartSettings.EchoVerification;
            chkEcho.Enabled = objSettings.DefaultStartSettings.EchoVerificationAllow;
            
            chkAddCRC.Checked = objSettings.DefaultStartSettings.AddChecksum;
            chkAddCRC.Enabled = objSettings.DefaultStartSettings.AddChecksumAllow;


            // Tab timing
            txtPolltime.Text    = objSettings.DefaultStartSettings.Polltime;
            txtPolltime.Enabled = objSettings.DefaultStartSettings.PolltimeAllow;

            txtTimeout.Text    = objSettings.DefaultStartSettings.Timeout;
            txtTimeout.Enabled = objSettings.DefaultStartSettings.TimeoutAllow;


            // Tab rest
            rdbResetCommand.Checked = objSettings.DefaultStartSettings.CommandReset;
            rdbResetCommand.Enabled = objSettings.DefaultStartSettings.CommandResetAllow;

            txtResetCommand.Text    = objSettings.DefaultStartSettings.ResetCommand;
            txtResetCommand.Enabled = objSettings.DefaultStartSettings.ResetCommandAllow & objSettings.DefaultStartSettings.CommandReset;

            cboResetBaudrate.Text    = objSettings.DefaultStartSettings.ResetBaudrate;
            cboResetBaudrate.Enabled = objSettings.DefaultStartSettings.ResetBaudrateAllow & objSettings.DefaultStartSettings.CommandReset;

            rdbResetDtr.Checked = objSettings.DefaultStartSettings.DTRReset;
            rdbResetDtr.Enabled = objSettings.DefaultStartSettings.DTRResetAllow;

            rdbResetManual.Checked = objSettings.DefaultStartSettings.ManualReset;
            rdbResetManual.Enabled = objSettings.DefaultStartSettings.ManualResetAllow;

            rdbResetRts.Checked = objSettings.DefaultStartSettings.RTSReset;
            rdbResetRts.Enabled = objSettings.DefaultStartSettings.RTSResetAllow;

            txtResettime.Text    = objSettings.DefaultStartSettings.ResetTime.ToString();
            txtResettime.Enabled = objSettings.DefaultStartSettings.ResetTimeAllow & (objSettings.DefaultStartSettings.DTRReset | objSettings.DefaultStartSettings.RTSReset | objSettings.DefaultStartSettings.CommandReset);


            // Tab device activation
            rdbActivateDTR.Checked = objSettings.DefaultStartSettings.ActivateDTR;
            rdbActivateDTR.Enabled = objSettings.DefaultStartSettings.ActivateDTRAllow;

            rdbActivateRTS.Checked = objSettings.DefaultStartSettings.ActivateRTS;
            rdbActivateRTS.Enabled = objSettings.DefaultStartSettings.ActivateRTSAllow;


            // Tab terminal
            cboTermBaudrate.Text = objSettings.DefaultStartSettings.TermBaudrate;
            chkTermSwitchTo.Checked = objSettings.DefaultStartSettings.TermSwithTo;
            cborTermRxType.SelectedIndex = objSettings.DefaultStartSettings.TermRxType;
            cboTermTxType.SelectedIndex = objSettings.DefaultStartSettings.TermTxType;
            txtTermTx.Text = objSettings.DefaultStartSettings.TermTx;   

            // Tab test
            chkTestEnable.Checked = false;
		}// ResetSettingsToDefault()


		//-------------------------------------------------------------------------
		// SaveSettings()
		// Description: 
		//-------------------------------------------------------------------------
		public void SaveSettings()
		{	
            string strPath = GetSettingsFilesPath();
            
            
            //-----------------------------------------------------------------
			// Recent files
            //-----------------------------------------------------------------
            UpdateRecentFile( cboFiles.Text );
            objRecentFiles.SaveFiles( strPath );


            //-----------------------------------------------------------------
			// Filename
            //-----------------------------------------------------------------			
			string strFilename = strPath + Path.DirectorySeparatorChar + "settings.xml";


            //-----------------------------------------------------------------
            //
            //-----------------------------------------------------------------
			objSettings.WindowOnTop = mnuViewOntop.Checked;
			objSettings.WindowWidth = this.Width;
            objSettings.WindowHeight = this.Height;
            objSettings.Filename = cboFiles.Text;
 
            
            //-----------------------------------------------------------------
            // Serialize
            //-----------------------------------------------------------------           
            XmlSerializer xmlSerializer = new XmlSerializer( typeof(clsSettings) );
            TextWriter textWriter = new StreamWriter( strFilename );
            xmlSerializer.Serialize( textWriter, objSettings );
            textWriter.Close();
		}//SaveSettings()         
        

        //-------------------------------------------------------------------------
		// SetPanel2CollapsedState()
		//-------------------------------------------------------------------------
        private void SetPanel2CollapsedState( bool pbCollapsed ) 
        {
            splitContainer1.Panel2Collapsed = pbCollapsed;

            splitContainer1.Panel2.Tag = splitContainer1.Panel2Collapsed;
            btnShowOutput.Checked = !splitContainer1.Panel2Collapsed;
        }//SetPanel2CollapsedState
        

        //-------------------------------------------------------------------------
		// SetupDS30LSettings()
		// Description: 
		//-------------------------------------------------------------------------
		public void SetupDS30LSettings( ref bool pbResult )
		{	
            pbResult = false;
            bool bAdvancedMode = mnuViewAdvanced.Checked;

            //-----------------------------------------------------------------
            // Basic tab
            //-----------------------------------------------------------------
            objds30LSettings.portName = cboPort.Text;
            try {
                objds30LSettings.baudRate = int.Parse( cboBaudrate.Text );
            } catch {
                clsDebugTextbox.OutputError( "Couldn't parse baudrate" ); 
                return;
            }
            if ( objPort.portType == PortType.CAN ) {
                /*try {
                    objds30LSettings.remoteId = uint.Parse( cboRemoteId.Text );
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse remote id" ); 
                    return;
                }
                try {
                    objds30LSettings.localId = uint.Parse( cboLocalId.Text );
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse local id" ); 
                    return;
                }*/

                bool bResult = false;                
                objds30LSettings.remoteId = ParseDecimalOrHexString( cboRemoteId.Text, ref bResult );                    
                if ( bResult == false ) {
                    clsDebugTextbox.OutputError( "Could not parse PIC CAN id", 0 );
                    return;
                }
                
                bResult = false;
                objds30LSettings.localId = ParseDecimalOrHexString( cboLocalId.Text, ref bResult );
                if ( bResult == false ) {
                    clsDebugTextbox.OutputError( "Could not parse GUI CAN id", 0 );
                    return;
                }
            }
            objds30LSettings.writeProgram = chkWriteProgram.Checked;
            objds30LSettings.writeEeprom = chkWriteEeprom.Checked;


            //-----------------------------------------------------------------
            // Advanced tab
            //-----------------------------------------------------------------
            if ( bAdvancedMode == true ) {
                objds30LSettings.writeConfigs = chkWriteConfigs.Checked;
                objds30LSettings.noGoto = chkNoGoto.Checked;
                objds30LSettings.allowBlOverwrite = chkAllowBlOverwrite.Checked;     
                objds30LSettings.customBl = chkCustomBl.Checked;
                try {
                    objds30LSettings.customBlPlacementP = int.Parse( txtCustomBlPlacementP.Text.Trim() );
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse custom bootloader placement" ); 
                    return;
                }
                try {
                    objds30LSettings.customBlSizeP = int.Parse( txtCustomBlSizeP.Text.Trim() );            
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse custom bootloader size" ); 
                    return;
                }
                objds30LSettings.autoBaudrate = chkAutoBaud.Checked;
                objds30LSettings.echoVerification = chkEcho.Checked;
                objds30LSettings.addChecksum = chkAddCRC.Checked;
            } else {
                objds30LSettings.writeConfigs = objSettings.DefaultStartSettings.WriteConfigs;
                objds30LSettings.noGoto = objSettings.DefaultStartSettings.NoGoto;
                objds30LSettings.allowBlOverwrite = false;
                objds30LSettings.customBl = objSettings.DefaultStartSettings.CustomBl;
                objds30LSettings.customBlPlacementP = objSettings.DefaultStartSettings.CustomBlPlacementP;
                objds30LSettings.customBlSizeP = objSettings.DefaultStartSettings.CustomBlSizeP;
                objds30LSettings.autoBaudrate = objSettings.DefaultStartSettings.AutoBaudRate;
                objds30LSettings.echoVerification = objSettings.DefaultStartSettings.EchoVerification;
                objds30LSettings.addChecksum = objSettings.DefaultStartSettings.AddChecksum;
            }

            //-----------------------------------------------------------------
            // Timing tab
            //-----------------------------------------------------------------
            if ( bAdvancedMode == true ) {
                try {
                    objds30LSettings.timeout = int.Parse( txtTimeout.Text.Trim() );
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse timeout" ); 
                    return;
                }    
                try {
                    objds30LSettings.polltime = int.Parse( txtPolltime.Text.Trim() );   
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse polltime" ); 
                    return;
                }
            } else {
                try {
                    objds30LSettings.timeout = int.Parse( objSettings.DefaultStartSettings.Timeout );
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse timeout" ); 
                    return;
                }    
                try {
                    objds30LSettings.polltime = int.Parse( objSettings.DefaultStartSettings.Polltime );   
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse polltime" ); 
                    return;
                }
            }


            //-----------------------------------------------------------------
            // Reset tab
            //-----------------------------------------------------------------

            if ( bAdvancedMode == true ) {
                objds30LSettings.resetCommand = rdbResetCommand.Checked;
                objds30LSettings.resetCommandSequence = txtResetCommand.Text.Trim();
                objds30LSettings.resetDtr = rdbResetDtr.Checked;
                objds30LSettings.resetRts = rdbResetRts.Checked; 
                if ( objds30LSettings.resetCommand ) {
                    try {
                        objds30LSettings.resetBaudrate = int.Parse( cboResetBaudrate.Text.Trim() );
                    } catch {
                        clsDebugTextbox.OutputError( "Couldn't parse reset baudrate" ); 
                        return;
                    }
                }
                try {
                    objds30LSettings.resetTime = int.Parse( txtResettime.Text.Trim() );
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse reset time" ); 
                    return;
                }

            } else {
                objds30LSettings.resetCommand = objSettings.DefaultStartSettings.CommandReset;
                objds30LSettings.resetCommandSequence = objSettings.DefaultStartSettings.ResetCommand;
                objds30LSettings.resetDtr = objSettings.DefaultStartSettings.DTRReset;
                objds30LSettings.resetRts = objSettings.DefaultStartSettings.RTSReset;    

                if ( objds30LSettings.resetCommand ) {
                    try {
                        objds30LSettings.resetBaudrate = int.Parse( objSettings.DefaultStartSettings.ResetBaudrate );
                    } catch {
                        clsDebugTextbox.OutputError( "Couldn't parse reset baudrate: ''" + objSettings.DefaultStartSettings.ResetBaudrate + "''" ); 
                        return;
                    }
                }
                try {
                    objds30LSettings.resetTime = int.Parse( objSettings.DefaultStartSettings.ResetTime );
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse reset time: ''" + objSettings.DefaultStartSettings.ResetTime + "''" ); 
                    return;
                }
            }

            //-----------------------------------------------------------------
            // Activation tab
            //-----------------------------------------------------------------
            if ( bAdvancedMode == true ) {
                objds30LSettings.activateDtr = rdbActivateDTR.Checked;
                objds30LSettings.activateRts = rdbActivateRTS.Checked;
            } else {
                objds30LSettings.activateDtr = objSettings.DefaultStartSettings.ActivateDTR;
                objds30LSettings.activateRts = objSettings.DefaultStartSettings.ActivateRTS;
            }

            //-----------------------------------------------------------------
            // Test tab
            //-----------------------------------------------------------------
            if ( bAdvancedMode == true ) {
                clsds30Loader.testMode = chkTestEnable.Checked;
            } else {
                clsds30Loader.testMode = false;
            }
            if ( clsds30Loader.testMode == true ) {
                // Device id
                clsds30Loader.testDeviceID = ((clsDevice)cboDevice.SelectedItem).id;
                
                // Firmware version
                try {
                    clsds30Loader.testFwVer = new Version( txtTestFwVersion.Text );
                } catch {
                    clsDebugTextbox.OutputError( "Invalid test firmware version" );
                    return;
                }

                // Response
                switch ( cboTestResponse.Text.ToLower() ) {
                    case "ok":
                        clsds30Loader.testResponse = clsds30Loader.cOK;
                        break;
                    case "checksum error":
                        clsds30Loader.testResponse = clsds30Loader.cChecksumErr;
                        break;
                     case "verification failed":
                        clsds30Loader.testResponse = clsds30Loader.cVerifyErr;
                        break;
                    case "bl protection tripped":
                        clsds30Loader.testResponse = clsds30Loader.cBlProtTrip;
                        break;
                    default:
                        clsDebugTextbox.OutputError( "Unknown test response" );
                        return;              
                }
            }

            pbResult = true;
		}//SetupDS30LSettings()  
  		
        
        //---------------------------------------------------------------------
		// SetupParseSettings()
		//---------------------------------------------------------------------
		private void SetupParseSettings( ref clsParseSettings pobjParseSettings, ref bool pbResult) 
        { 
            pbResult = false;

            // Get selected device
            clsDevice objDevice = (clsDevice)cboDevice.SelectedItem;
            if ( objDevice == null ) {
                return;
            }            
            
            int iBlSizeP = objHex.defaultBlSizeP;
            int iBlPlacementP = objHex.defaultBlPlacementP;

            // Custom bootloader placement
            bool bAdvancedMode = mnuViewAdvanced.Checked;
            if ( chkCustomBl.Checked == true && bAdvancedMode == true ) {
                try {
                    iBlPlacementP = int.Parse(txtCustomBlPlacementP.Text);
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse custom bootloader placement" ); 
                    return;
                }
                try {                    
                    iBlSizeP =  int.Parse(txtCustomBlSizeP.Text);
                } catch {
                    clsDebugTextbox.OutputError( "Couldn't parse custom bootloader size" ); 
                    return;
                }
            }

            // 
            pobjParseSettings = new clsParseSettings( iBlSizeP, objDevice, chkAllowBlOverwrite.Checked, chkNoGoto.Checked, iBlPlacementP, chkAddCRC.Checked );          
            pbResult = true;
		}//SetupParseSettings() 
     

        //-------------------------------------------------------------------------
		// TermUpdateButtons()
		//-------------------------------------------------------------------------       
        private void TermUpdateButtons()
        {
            //
            btnTermOpen.Enabled = !objPort.isOpen;
            btnTermClose.Enabled = objPort.isOpen;
            txtTermTx.Enabled = objPort.isOpen;
            cboTermBaudrate.Enabled = !objPort.isOpen;

            //              
            cboPort.Enabled = !objPort.isOpen;
            btnCheck.Enabled = !objPort.isOpen;
            btnDownload.Enabled = !objPort.isOpen;
            mnuCmdDownload.Enabled = !objPort.isOpen;
            mnuViewAdvanced.Enabled = !objPort.isOpen;
            cboLocalId.Enabled = !objPort.isOpen;
            cboRemoteId.Enabled = !objPort.isOpen;

            if ( objPort.isOpen && tabTerminal.Text.EndsWith("*") == false ) {
                tabTerminal.Text += "*";
            } else if ( !objPort.isOpen && tabTerminal.Text.EndsWith("*") == true ) {
                tabTerminal.Text = tabTerminal.Text.Substring( 0, tabTerminal.Text.Length-1 );
            }
        }// TermUpdateButtons()

 
        //---------------------------------------------------------------------
		// UpdateDeviceList()
		// Description: fills the device combo box with devices that matches 
        //              selected family
		//---------------------------------------------------------------------
		public void UpdateDeviceList()
		{	
            bool bCanPortSelected = IsCanPortSelected();

            // Clear devices in combobox
			cboDevice.Items.Clear();
			
			// Get selected device family
			clsDeviceFamily objDeviceFamily = clsDeviceDb.DeviceFamilyGet( cboFamily.Text );
			if ( objDeviceFamily == null ) return;
			
			// Populate combobox with devices
			Hashtable htDevices = objDeviceFamily.DevicesGet();			
			foreach ( clsDevice objDevice in htDevices.Values ) {
				if ( 
                    //objDevice.family == objDeviceFamily &&
                    (
                        bCanPortSelected == false || 
                        (bCanPortSelected == true && objDevice.hasCanModule == true) 
                    )
                ) {
                    cboDevice.Items.Add( objDevice );
				}
			}
			
			// Select the first device
			if ( cboDevice.Items.Count > 0 ) {
				cboDevice.SelectedIndex = 0;
			} else {
				cboDevice.Text = "";
			}
        }// UpdateDeviceList()


        //---------------------------------------------------------------------
		// UpdateGUI()
		// Description: 
		//---------------------------------------------------------------------
		static public bool UpdateGUI( clsLatestVersionInfo objLatestVersionInfo )
		{	
            // Download file
            try {
                WebClient Client = new WebClient ();
                Client.DownloadFile( objLatestVersionInfo.urlds30Loader_dll, "ds30 loader.dll.new");
                Client.DownloadFile( objLatestVersionInfo.urlds30LoaderGUI_exe, "ds30 loader GUI.exe.new");
            } catch {
                MessageBox.Show( "Download failed. Update aborted.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                return false;
            }

            // Create bat-file
            TextWriter tw = new StreamWriter("update.bat");
            tw.WriteLine( "@echo off" );
            tw.WriteLine( "echo Wait for the application to close. Then press any key to continue update." );
            tw.WriteLine( "echo Press CTRL+C to abort." );
            tw.WriteLine( "pause" );
            tw.WriteLine( "del \"ds30 loader.dll\"" );
            tw.WriteLine( "del \"ds30 loader GUI.exe\"" );
            tw.WriteLine( "ren \"ds30 loader.dll.new\" \"ds30 loader.dll\"" );
            tw.WriteLine( "ren \"ds30 loader GUI.exe.new\" \"ds30 loader GUI.exe\"" );
            tw.WriteLine( "start \"\" \"ds30 loader gui.exe\"" );
            tw.WriteLine( "del update.bat" );
            tw.Close();

            // Start bat
            try {
                System.Diagnostics.ProcessStartInfo a = new System.Diagnostics.ProcessStartInfo();
                a.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
                a.FileName = "update.bat";
                a.WorkingDirectory = Path.GetDirectoryName( Application.ExecutablePath );
                /*System.Diagnostics.Process objUpdateProcess = */System.Diagnostics.Process.Start( a );                    
            } catch {
                MessageBox.Show( "Update failed.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                return false;
            }

            // Close application
            Application.Exit();

            return true;
        }// UpdateGUI()
        

        //-------------------------------------------------------------------------
		// UpdateInfoWindow()
		//-------------------------------------------------------------------------       
        private void UpdateInfoWindow()
        {
            if ( wndInfo == null ) return;

            clsDevice objDevice = (clsDevice)cboDevice.SelectedItem;

            bool bSetupParseSettingsResult = false;
            clsParseSettings objParseSettings = null;
            SetupParseSettings( ref objParseSettings, ref bSetupParseSettingsResult );
            if ( bSetupParseSettingsResult == false ) {
                objParseSettings = null;
            }

            wndInfo.UpdateInfo( objDevice, objHex, objParseSettings );
        }// UpdateInfoWindow()


        //-------------------------------------------------------------------------
		// UpdatePortSelection()
		//-------------------------------------------------------------------------       
        private void UpdatePortSelection()
        {
            CreatePort();
            if ( objPort == null ) {
                DisablePortUsage();
                return;                
            }
            EnablePortUsage();

            bool bCanPortWasSelected = cboRemoteId.Visible;
            bool bCanPortIsSelected = (objPort.portType == PortType.CAN);
            
            if ( bCanPortIsSelected == true ) {
                lbPICId.Visible = true;
                cboRemoteId.Visible = true;
                lblGUIId.Visible = true;
                cboLocalId.Visible = true;
                
                chkAutoBaud.Enabled = false;
                chkAutoBaud.Checked = false;
                chkEcho.Enabled = false;
                chkEcho.Checked = false;

                if ( rdbResetDtr.Checked || rdbResetRts.Checked ) {
                    rdbResetManual.Checked = true;
                }
                rdbResetDtr.Enabled = false;
                rdbResetRts.Enabled = false;
                
                if ( rdbActivateDTR.Checked || rdbActivateRTS.Checked ) {
                    rdbActivateNone.Checked = true;
                }
                rdbActivateDTR.Enabled = false;
                rdbActivateRTS.Enabled = false;
            } else {
                lbPICId.Visible = false;
                cboRemoteId.Visible = false;
                lblGUIId.Visible = false;
                cboLocalId.Visible = false;
                
                chkAutoBaud.Enabled = true;
                chkEcho.Enabled = true;                

                rdbResetDtr.Enabled = true;
                rdbResetRts.Enabled = true;
                
                rdbActivateDTR.Enabled = true;
                rdbActivateRTS.Enabled = true;
            }

            if ( bCanPortIsSelected != bCanPortWasSelected || bStartup == true  ) {
                if ( objPort.allowCustomBaudRate ) {
                    cboBaudrate.DropDownStyle = cboResetBaudrate.DropDownStyle = cboTermBaudrate.DropDownStyle = ComboBoxStyle.DropDown;
                } else {
                    cboBaudrate.DropDownStyle = cboResetBaudrate.DropDownStyle = cboTermBaudrate.DropDownStyle = ComboBoxStyle.DropDownList;
                }
                ArrayList lstBaudRates = objPort.GetBaudRates();
                cboBaudrate.Items.Clear();
                cboResetBaudrate.Items.Clear();
                cboTermBaudrate.Items.Clear();
                foreach ( int iBaudRate in lstBaudRates ) {
                    cboBaudrate.Items.Add( iBaudRate );
                    cboResetBaudrate.Items.Add( iBaudRate );
                    cboTermBaudrate.Items.Add( iBaudRate );
                }
                //cboBaudrate.DataSource = objPort.GetBaudRates();
                //cboResetBaudrate.DataSource = objPort.GetBaudRates();
                //cboTermBaudrate.DataSource = objPort.GetBaudRates();

                if ( bStartup == false ) {
                    UpdateDeviceList();
                }
            }         
   
            if ( objPort.portType == PortType.CAN ) {
                lblBaudRate.Text = "Bit rate:";
            } else {
                lblBaudRate.Text = "Baud rate:";
            }

            if ( objPort != null ) {
                btnPortSettings.Visible = objPort.hasWindow;
            } else {
                btnPortSettings.Visible = false;
            }
        }// UpdatePortSelection()


        //-------------------------------------------------------------------------
		// UpdateRecentFile()
		// Description: 
		//-------------------------------------------------------------------------
		public void UpdateRecentFile( string pstrFilename )
		{	
            clsRecentFile objRecentFile = objRecentFiles.GetFile( pstrFilename );
            if ( objRecentFiles != null ) {
                UpdateRecentFile( objRecentFile );
            } 
        }// UpdateRecentFile()


        //-------------------------------------------------------------------------
		// UpdateRecentFile()
		// Description: 
		//-------------------------------------------------------------------------
		public void UpdateRecentFile( clsRecentFile pobjRecentFile )
		{	
            if ( pobjRecentFile == null ) {
                return;
            }

            pobjRecentFile.AdvancedMode = mnuViewAdvanced.Checked;
			
            // Tab basic settings
			pobjRecentFile.Portname = cboPort.Text;
			pobjRecentFile.Baudrate = cboBaudrate.Text;
            pobjRecentFile.RemoteId = cboRemoteId.Text;
            pobjRecentFile.LocalId = cboLocalId.Text;
			pobjRecentFile.Familyname = cboFamily.Text;
			pobjRecentFile.Devicename = cboDevice.Text;
			pobjRecentFile.WriteProgram = chkWriteProgram.Checked; 
			pobjRecentFile.WriteEeprom = chkWriteEeprom.Checked;

            // Tab advanced
			pobjRecentFile.WriteConfigs = chkWriteConfigs.Checked;
			pobjRecentFile.NoGoto = chkNoGoto.Checked;
            //pobjRecentFile.IgnoreBLOverwrite = chkAllowBlOverwrite;
            pobjRecentFile.CustomBl = chkCustomBl.Checked;
            try {
                pobjRecentFile.CustomBlPlacementP = int.Parse( txtCustomBlPlacementP.Text );
            } catch {
                pobjRecentFile.CustomBlPlacementP = 0;
            }
             try {
                pobjRecentFile.CustomBlSizeP = int.Parse( txtCustomBlSizeP.Text );
            } catch {
                pobjRecentFile.CustomBlSizeP = 0;
            }
            pobjRecentFile.AutoBaudrate = chkAutoBaud.Checked;
            pobjRecentFile.EchoVerification = chkEcho.Checked;
            pobjRecentFile.AddChecksum = chkAddCRC.Checked;

            // Tab timing
            pobjRecentFile.Polltime = txtPolltime.Text;
            pobjRecentFile.Timeout = txtTimeout.Text;

            // Tab device reset
            pobjRecentFile.CommandReset = rdbResetCommand.Checked;
            pobjRecentFile.ResetCommand = txtResetCommand.Text;
            pobjRecentFile.ResetBaudrate = cboResetBaudrate.Text;

            pobjRecentFile.DTRReset = rdbResetDtr.Checked;
            pobjRecentFile.ManualReset = rdbResetManual.Checked;
            
            pobjRecentFile.RTSReset = rdbResetRts.Checked;
            try {
                pobjRecentFile.ResetTime = int.Parse( txtResettime.Text );
            } catch {
                pobjRecentFile.ResetTime = 0;
            }

            // Tab device activation
            pobjRecentFile.ActivateDTR = rdbActivateDTR.Checked;
            pobjRecentFile.ActivateRTS = rdbActivateRTS.Checked;

            // Tab terminal
            pobjRecentFile.TermBaudrate = cboTermBaudrate.Text;
            pobjRecentFile.TermSwithTo = chkTermSwitchTo.Checked;
            pobjRecentFile.TermRxType = cborTermRxType.SelectedIndex;
            pobjRecentFile.TermTxType = cboTermTxType.SelectedIndex;
            pobjRecentFile.TermTx = txtTermTx.Text;
		}//UpdateRecentFile()   


        //-------------------------------------------------------------------------
		// VisitHomepage()
		// Description: 
		//-------------------------------------------------------------------------
		static public void VisitHomepage()
		{	
            System.Diagnostics.Process.Start( strURLHomepage );  
		}//VisitHomepage()         		


		//---------------------------------------------------------------------
		// mnuFileExit_Click()
		//---------------------------------------------------------------------
		private void mnuFileExit_Click( object sender, EventArgs e )
		{
            Application.Exit();
		}//mnuFileExit_Click()
		
		
		//---------------------------------------------------------------------
		// cboFamily_SelectedIndexChanged()
		//---------------------------------------------------------------------
		private void cboFamily_SelectedIndexChanged( object sender, EventArgs e )
		{
            // Create hex-file object  
            switch ( cboFamily.Text ) {
                case "PIC16F":
                    objHex = new clsHex16F( cboFiles.Text );  
                    break;           
                case "PIC18F":
                    objHex = new clsHex18F( cboFiles.Text );
                    break;
                 case "PIC18FJ":
                    objHex = new clsHex18FJ( cboFiles.Text );  
                    break;         
                case "PIC24F":
                    objHex = new clsHex24F( cboFiles.Text );
                    break;
                case "PIC24FJ":
                    objHex = new clsHex24FJ( cboFiles.Text ); 
                    break;           
                case "PIC24HJ":
                    objHex = new clsHex24H( cboFiles.Text );
                    break;
                case "dsPIC30F":				
				    objHex = new clsHex30F( cboFiles.Text );
                    break;			
                case "dsPIC33FJ":
				    objHex = new clsHex33FJ( cboFiles.Text );            
                    break;
                default:
				    throw new Exception( "Unknown device family" );
			}

            clsDeviceFamily objFamily = clsDeviceDb.DeviceFamilyGet(  cboFamily.Text );
            if ( objFamily != null ) {
                if ( objFamily.pageSizeR > 1 ) {
                    lblPlacement.Text = "page(s) from the end";
                    lblSize.Text = "page(s)";
                } else {
                    lblPlacement.Text = "row(s) from the end";
                    lblSize.Text = "row(s)";
                }
            }

			UpdateDeviceList();
		}//cboFamily_SelectedIndexChanged()
		
		
		//---------------------------------------------------------------------
		// btnBrowse_Click()
		//---------------------------------------------------------------------
		private void btnBrowse_Click( object sender, EventArgs e )
		{
			OpenFileDialog  dialog = new OpenFileDialog ();
			dialog.InitialDirectory = "";
			dialog.Title = "Choose hex-file";
			dialog.Filter = strHexFileFilter;
			dialog.FilterIndex = 0;
			
			// User presses OK
			if ( dialog.ShowDialog() == DialogResult.OK ) {
                // File changed?
                if ( dialog.FileName == cboFiles.Text ) {
                    return;
                }

                // Apply settings for old file
                UpdateRecentFile( cboFiles.Text );

                // Apply new file
				cboFiles.Text = dialog.FileName;
				OpenFile( cboFiles.Text );
			 }			
		}//btnBrowse_Click()
		
		
		//---------------------------------------------------------------------
		// frmDSLoader_FormClosing()
		//---------------------------------------------------------------------
		private void frmDSLoader_FormClosing( object sender, FormClosingEventArgs e )
		{
			objPort.Close();
            SaveSettings();
		}//btnCheck_Click()
		
		
		//---------------------------------------------------------------------
		// cboDevice_SelectedIndexChanged()
		//---------------------------------------------------------------------
		private void cboDevice_SelectedIndexChanged( object sender, EventArgs e )
		{
			DoParse( false );
		}//btnCheck_Click()
		
		
		//---------------------------------------------------------------------
		// mnuEditDebugmode_CheckedChanged()
		//---------------------------------------------------------------------
        private void mnuEditDebugmode_CheckedChanged(object sender, EventArgs e)
        {
            clsds30Loader.debugMode = mnuOptDebugmode.Checked;
            DoParse( true );
            if ( mnuOptDebugmode.Checked == false ) {
                chkTestEnable.Checked = false;
                tabControl2.TabPages.Add( tabTest );
            } else {
                tabControl1.TabPages.Add( tabTest );
            }
        }//mnuEditDebugmode_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// mnuHelpVisitHomepage_Click()
		//---------------------------------------------------------------------
        private void mnuHelpVisitHomepage_Click(object sender, EventArgs e)
        {
            VisitHomepage();
        }//mnuHelpVisitHomepage_Click()
		
		
		//---------------------------------------------------------------------
		// mnuViewMicro_Click()
		//---------------------------------------------------------------------
        private void mnuViewMicro_Click(object sender, EventArgs e)
        {
            sizeBeforeMicro.Width = this.Width;
            sizeBeforeMicro.Height = this.Height;

            this.Width = 170;
            this.Height = toolStrip1.Height;
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = false;

            mnuViewMicro.Enabled = false;
            menuStrip1.Visible = false;             
            tabControl1.Visible = false;
            txtInfo.Visible = false;
            toolStrip2.Visible = false;
            statusStrip1.Visible = false;
            this.ControlBox = false;
            this.Text = "";

            toolStrip1.Top = menuStrip1.Top;
            toolStrip1.Visible = true;            
            
            //progressBar.Top = toolStrip1.Top + (toolStripButton1.Height - progressBar.Height)/2;
            //progressBar.Left = toolStripButton1.Width + toolStripButton2.Width + 20;
            //progressBar.Width = this.Width - progressBar.Left - 35;            
            
            progressBar.Left = toolStrip1.Left + 10;
            progressBar.Top = toolStrip1.Top + toolStrip1.Height;
            progressBar.Width = toolStrip1.Width - 20;

            if ( mnuViewOntop.Checked == false  ) {
                mnuViewOntop.Checked = true;
            }
        }//mnuViewMicro_Click()
		
		
		//---------------------------------------------------------------------
		// toolStripButton1_Click()
		//---------------------------------------------------------------------
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            mnuViewMicro.Enabled = true;
            toolStrip1.Visible = false;
            menuStrip1.Visible = true;
            tabControl1.Visible = true;
            txtInfo.Visible = true;
            toolStrip2.Visible = true;
            statusStrip1.Visible = true;
            this.ControlBox = true;
            this.Text = "ds30 Loader";

            this.Width = sizeBeforeMicro.Width;
            this.Height = sizeBeforeMicro.Height;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.ShowInTaskbar = true;

            progressBar.Top = 7;
            progressBar.Left = 253;
            progressBar.Width = tabControl1.Width + tabControl1.Left - progressBar.Left;

        }//toolStripButton1_Click()
		
		
		//---------------------------------------------------------------------
		// frmDSLoader_MouseDown()
		//---------------------------------------------------------------------
        static bool bHostIsWindows = GHelper.clsMisc.HostIsWindows();
        private void frmDSLoader_MouseDown(object sender, MouseEventArgs e)
        {
            if ( bHostIsWindows == true && e.Button == MouseButtons.Left && mnuViewMicro.Checked ) {
                ReleaseCapture();
                SendMessage( Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0 );
            }
        }//frmDSLoader_MouseDown()
		
		
		//---------------------------------------------------------------------
		// toolStrip1_MouseDown()
		//---------------------------------------------------------------------
        private void toolStrip1_MouseDown(object sender, MouseEventArgs e)
        {
           if ( e.Button == MouseButtons.Left ) {
                ReleaseCapture();
                SendMessage( Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0 );
            }
        }//toolStrip1_MouseDown()
		
		
		//---------------------------------------------------------------------
		// btnDownload2_Click()
		//---------------------------------------------------------------------
        private void btnDownload2_Click(object sender, EventArgs e)
        {
            Download();
        }//btnDownload2_Click()
		
		
		//---------------------------------------------------------------------
		// txtInfo_TextChanged()
		//---------------------------------------------------------------------
        private void txtInfo_TextChanged(object sender, EventArgs e)
        {
            if ( mnuViewMicro.Checked == true ) {
                btnDownload2.ToolTipText = txtInfo.Text;
            }
        }//txtInfo_TextChanged()
		
		
		//---------------------------------------------------------------------
		// mnuViewOntop_CheckedChanged()
		//---------------------------------------------------------------------
        private void mnuViewOntop_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = mnuViewOntop.Checked;
        }//mnuViewOntop_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// mnuCmdDownload_Click()
		//---------------------------------------------------------------------
        private void mnuCmdDownload_Click(object sender, EventArgs e)
        {
            Download();
        }//mnuViewOntop_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// mnuCmdAbort_Click()
		//---------------------------------------------------------------------
        private void mnuCmdAbort_Click(object sender, EventArgs e)
        {
            Abort();
        }//mnuCmdAbort_Click()
		
		
		//---------------------------------------------------------------------
		// mnuHelpAbout_Click()
		//---------------------------------------------------------------------
        private void mnuHelpAbout_Click(object sender, EventArgs e)
        {
            AboutWindowOpen();
        }//mnuHelpAbout_Click()
		
		
		//---------------------------------------------------------------------
		// chkNoGoto_CheckedChanged()
		//---------------------------------------------------------------------
        private void chkNoGoto_CheckedChanged(object sender, EventArgs e)
        {
            DoParse( false );
        }//chkNoGoto_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// btnDownload_Click()
		//---------------------------------------------------------------------
        private void btnDownload_Click(object sender, EventArgs e)
        {
            Download();
        }//btnDownload_Click()
		
		
		//---------------------------------------------------------------------
		// btnCheck_Click()
		//---------------------------------------------------------------------
        private void btnCheck_Click(object sender, EventArgs e)
        {
            CheckForBL();
        }//btnCheck_Click()
		
		
		//---------------------------------------------------------------------
		// btnAbort_Click()
		//---------------------------------------------------------------------
        private void btnAbort_Click(object sender, EventArgs e)
        {
            Abort();
        }//btnAbort_Click()
		
		
		//---------------------------------------------------------------------
		// btnShowOutput_CheckedChanged()
		//---------------------------------------------------------------------
        private void btnShowOutput_CheckedChanged(object sender, EventArgs e)
        {
            SetPanel2CollapsedState( !btnShowOutput.Checked );
        }//btnShowOutput_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// frmDS30Loader_Activated()
        // Description: reload hex-file when windows is actived, maybe the user
        //              is returning from mplab...
		//---------------------------------------------------------------------
        private void frmDS30Loader_Activated(object sender, EventArgs e)
        {
            if ( objHex != null && File.Exists(cboFiles.Text) ) {
                if ( objHex.objParsedSettings.fileTimestamp != File.GetLastWriteTime(cboFiles.Text) ) {
                    DoParse( false );
                }
            }
    
            if ( bStartup == true ) {
                bStartup = false;            
                // Check for new version?
                if ( objSettings.CheckVerStart == true ) {
                    CheckLatestVersion();
                }

                // Open last file
                OpenFile( cboFiles.Text );
            }
        }//frmDS30Loader_Activated()
		
		
		//---------------------------------------------------------------------
		// rdbCommandReset_CheckedChanged()
		//---------------------------------------------------------------------
        private void rdbCommandReset_CheckedChanged(object sender, EventArgs e)
        {
            txtResetCommand.Enabled = rdbResetCommand.Checked;        
            cboResetBaudrate.Enabled = rdbResetCommand.Checked;
        }//rdbCommandReset_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// txtResetCommand_TextChanged()
		//---------------------------------------------------------------------
        private void txtResetCommand_TextChanged(object sender, EventArgs e)
        {
            bool bSplitResult = false;
            if ( objPort == null ) return;

            if ( objPort.portType == PortType.CAN ) {
                clsds30Loader.ParseCanCommand(txtResetCommand.Text, ref bSplitResult);
            } else {
                GHelper.clsMisc.Split8bitHexStringToBytes(txtResetCommand.Text, ref bSplitResult);
            }
            
            if ( bSplitResult == false ) {
                lblIncorrectFormat.Visible = true;
                return;
            }

            lblIncorrectFormat.Visible = false;
        }//txtResetCommand_TextChanged()
		
		
		//---------------------------------------------------------------------
		// tabControl1_SelectedIndexChanged()
        // Description: show/hide output when terminal tab is (de)selected
		//---------------------------------------------------------------------
        private TabPage tabPrevious = null;
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {            
            if ( tabControl1.SelectedTab == tabTerminal ) {
                btnShowOutput.Checked = false;
                btnShowOutput.Visible = true;
            } else if ( tabPrevious == tabTerminal ) {
                btnShowOutput.Checked = true;
                btnShowOutput.Visible = false;
            }
            tabPrevious = tabControl1.SelectedTab;
        }// tabControl1_SelectedIndexChanged()
		

		//---------------------------------------------------------------------
		// splitContainer1_Panel1_Paint()
		//---------------------------------------------------------------------
        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {
            // Tabcontrol is set to invisible in micro mode
            // Selectedtab is null when returning from micro mode in some windows/themes
            if ( tabControl1.SelectedTab != null ) {
                tabControl1.SelectedTab.Refresh();
            }
        }// splitContainer1_Panel1_Paint()
		
		
		//---------------------------------------------------------------------
		// btnTermOpen_Click()
		//---------------------------------------------------------------------
        private void btnTermOpen_Click(object sender, EventArgs e)
        {
            if ( objPort == null ) {
                CreatePort();
            }
            if ( objPort == null ) {
                return;
            }


            // Configure port
            int iBaudrate = 0;
            try {
                iBaudrate = int.Parse( cboTermBaudrate.Text );
            } catch {
                clsDebugTextbox.OutputError( "Terminal: could not parse baudrate", 0 );
                return;
            }
            if ( objPort.portType == PortType.CAN ) {
                bool bResult = false;                
                ((IPortCAN)objPort).remoteID = ParseDecimalOrHexString( cboRemoteId.Text, ref bResult );                    
                if ( bResult == false ) {
                    clsDebugTextbox.OutputError( "Terminal: could not parse remote CAN id", 0 );
                    return;
                }
                
                bResult = false;
                ((IPortCAN)objPort).localID = ParseDecimalOrHexString( cboLocalId.Text, ref bResult );
                if ( bResult == false ) {
                    clsDebugTextbox.OutputError( "Terminal: could not parse local CAN id", 0 );
                    return;
                }
            }
            objPort.Setup( cboPort.Text, iBaudrate );
            objPort.dtrEnable = rdbActivateDTR.Checked;
            objPort.rtsEnable = rdbActivateRTS.Checked;   


            // 
            objPort.DataReceived += new clsPortBase.DataReceivedDelegate( objPort_DataReceived );
            
            // Empty buffers and open port
            objPort.EmptyBuffers( true, true );
            objPort.Open();
            if ( objPort.isOpen == false ) {
                clsDebugTextbox.OutputError( "Terminal: could not open port", 0 );
            }

            TermUpdateButtons();
        }// btnTermOpen_Click()
		
		
		//---------------------------------------------------------------------
		// objPort_DataReceived()
		//---------------------------------------------------------------------
        void objPort_DataReceived( object sender, EventArgs e )
        {
            IPort pobjPort = (IPort)sender;

            // Text
            if ( cborTermRxType.SelectedItem.ToString() == "Text" ) {                
                bool bReadTextResult = false;
                string strText = pobjPort.ReadText( ref bReadTextResult );
                
                if ( bReadTextResult == true ) {
                    txtTermRx.AppendText( strText );
                }
            
            // Values
            } else {
                //
                string strRxType = cborTermRxType.SelectedItem.ToString().ToLower();

                // Get wordsize
                int iWordSizeBytes;
                if ( strRxType.StartsWith("8") == true ) {
                    iWordSizeBytes = 1;
                } else if ( strRxType.StartsWith("16") == true ) {
                    iWordSizeBytes = 2;
                } else if ( strRxType.StartsWith("32") == true ) {
                    iWordSizeBytes = 4;
                } else {
                    return;
                }

                // Nr of words available
                int iBytesAvailable = pobjPort.inBufferCount;                
                int iWords = (int)Math.Floor( (decimal)(iBytesAvailable / (int)iWordSizeBytes) );

                // Read words
                byte[] bRxBytes = new byte[iWords*iWordSizeBytes];                
                pobjPort.ReadBytes( ref bRxBytes, iWords*iWordSizeBytes );

                // Calculate value and output
                bool bHex = strRxType.Contains( "hex" );
                bool bUnsigned = strRxType.Contains( "unsigned" );
                string strFormat = "X" + (iWordSizeBytes*2).ToString();

                int iValue = 0;
                for ( int iWord = 0; iWord < iWords; iWord++ ) {
                    // Calculate
                    iValue = 0;
                    for ( int iByte = 0; iByte < iWordSizeBytes; iByte++ ) {
                        iValue += bRxBytes[ iWord * iWordSizeBytes + iByte] << ( 8 * (iWordSizeBytes - iByte - 1) );
                    }                    
                    
                    // Output
                    if ( bHex == true ) {
                        txtTermRx.AppendText( "0x" + iValue.ToString(strFormat) + " " );
                    } else if ( bUnsigned == true ) {
                        txtTermRx.AppendText( iValue.ToString() + " " );
                    }
                }                
            }
        }// objPort_DataReceived()
		
		
		//---------------------------------------------------------------------
		// btnTermClose_Click()
		//---------------------------------------------------------------------
        private void btnTermClose_Click(object sender, EventArgs e)
        {
            objPort.Close();
            //objPort.DataReceived -= new System.IO.Ports.SerialDataReceivedEventHandler(objPort_DataReceived);
            objPort.DataReceived -= new clsPortBase.DataReceivedDelegate( objPort_DataReceived );
            TermUpdateButtons();
        }// btnTermClose_Click()
		
		
		//---------------------------------------------------------------------
		// mnuOptResetSettings_Click()
		//---------------------------------------------------------------------
        private void mnuOptResetSettings_Click(object sender, EventArgs e)
        {
            DialogResult doReset = MessageBox.Show( "Do you really want to reset all settings to default?", "Reset settings to default", MessageBoxButtons.YesNo, MessageBoxIcon.Question );
            if ( doReset == DialogResult.Yes ) {
                ResetSettingsToDefault();
            }
        }// mnuOptResetSettings_Click()
		
		
		//---------------------------------------------------------------------
		// mnuViewAdvanced_CheckedChanged()
		//---------------------------------------------------------------------
        private void mnuViewAdvanced_CheckedChanged(object sender, EventArgs e)
        {
            //-----------------------------------------------------------------
            // Basic
            //-----------------------------------------------------------------            
            if ( mnuViewAdvanced.Checked == false ) {                
                //clsDebugTextbox.ClearTextbox();
                
                //
                /*if ( bStartup == false ) {
                    clsDebugTextbox.OutputInfo( "Switching to basic mode, advanced settings are resetted!", 0 );
                }
                ResetAdvancedSettings();*/

                // Menu options
                mnuOptDebugmode.Checked = false;
                mnuOptDebugmode.Visible = false;
                mnuOptResetSettings.Visible = false;
                
                // Menu command
                mnuCommands.Visible = false;              

                // Menu view
                //mnuViewMicro.Visible = false;
                mnuViewInfoWindow.Visible = false;
                mnuViewSettingsDir.Visible = false;

                // Toolbar
                btnCheck.Visible = false;
                btnShowOutput.Checked = true;
                btnReparseHexFile.Visible = false;

                // Tabcontrol
                tabControl2.TabPages.Add ( tabAdvanced );
                tabControl2.TabPages.Add ( tabTiming );
                tabControl2.TabPages.Add ( tabReset  );
                tabControl2.TabPages.Add ( tabActivation );
                tabControl2.TabPages.Add ( tabTerminal );

            
            //-----------------------------------------------------------------
            // Advanced
            //-----------------------------------------------------------------
            } else {
                // Menu options
                mnuOptDebugmode.Visible = true;
                mnuOptResetSettings.Visible = true;

                // Menu commands
                mnuCommands.Visible = true;

                // Menu view
                //mnuViewMicro.Visible = true;
                mnuViewInfoWindow.Visible = true;
                mnuViewSettingsDir.Visible = true;

                // Toolbar
                btnCheck.Visible = true;
                btnReparseHexFile.Visible = true;

                // Tabcontrol
                chkNoGoto.Visible = true;
                tabControl1.TabPages.Add ( tabAdvanced );
                tabControl1.TabPages.Add ( tabTiming );
                tabControl1.TabPages.Add ( tabReset  );
                tabControl1.TabPages.Add ( tabActivation );
                tabControl1.TabPages.Add ( tabTerminal );
                
            }
        }// mnuViewAdvanced_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// btnTermClearRx_Click()
		//---------------------------------------------------------------------
        private void btnTermClearRx_Click(object sender, EventArgs e)
        {            
            txtTermRx.Clear();
        }// btnTermClearRx_Click()
		
		
		//---------------------------------------------------------------------
		// rdbResetManual_CheckedChanged()
		//---------------------------------------------------------------------
        private void rdbResetManual_CheckedChanged(object sender, EventArgs e)
        {
            txtResettime.Enabled = !rdbResetManual.Checked;
        }// rdbResetManual_CheckedChanged()

        
        //---------------------------------------------------------------------
		// txtTermTxHex_KeyDown()
		//---------------------------------------------------------------------
        private void txtTermTxHex_KeyDown(object sender, KeyEventArgs e)
        {
            // Send when enter is pressed
            if ( e.KeyCode == Keys.Enter ) {
                // Text
                if ( cboTermTxType.SelectedIndex == 0 ) {
                    objPort.SendText( txtTermTx.Text );
                    txtTermTx.SelectAll();

                // Hex 8bit
                } else {            
                    bool bSplitResult = false;
                    byte[] bBytes = GHelper.clsMisc.Split8bitHexStringToBytes( txtTermTx.Text, ref bSplitResult );
                    if ( bSplitResult == true ) {
                        objPort.SendBytes( ref bBytes, 0, bBytes.Length );
                        txtTermTx.SelectAll();
                    }
                }
            }
        }// txtTermTxHex_KeyDown()	
		
		
		//---------------------------------------------------------------------
		// mnuCmdCheckForBl_Click()
		//---------------------------------------------------------------------
        private void mnuCmdCheckForBl_Click(object sender, EventArgs e)
        {
            CheckForBL();
        }// mnuCmdCheckForBl_Click()
		
		
		//---------------------------------------------------------------------
		// picHexContent_Paint()
		//---------------------------------------------------------------------
        private void picHexContent_Paint(object sender, PaintEventArgs e)
        {
            clsDevice objDevice = (clsDevice)cboDevice.SelectedItem;
            if ( objHex == null || objDevice == null ) {
                e.Graphics.Clear( Color.White );
                e.Graphics.DrawLine( Pens.Red, 0, 0, picHexContent.Width-1, picHexContent.Height-1 );
                e.Graphics.DrawLine( Pens.Red, picHexContent.Width-1, 0, 0, picHexContent.Height-1 );
                return;
            }

            if ( objHex.objParsedSettings == null || objHex.objParsedSettings.device == null ) {
                e.Graphics.Clear( Color.White );
                e.Graphics.DrawLine( Pens.Red, 0, 0, picHexContent.Width-1, picHexContent.Height-1 );
                e.Graphics.DrawLine( Pens.Red, picHexContent.Width-1, 0, 0, picHexContent.Height-1 );
                return;
            }            
            /*if ( objHex == null ) {
                e.Graphics.Clear( Color.White );
                e.Graphics.DrawLine( Pens.Red, 0, 0, picHexContent.Width-1, picHexContent.Height-1 );
                e.Graphics.DrawLine( Pens.Red, picHexContent.Width-1, 0, 0, picHexContent.Height-1 );
                return;
            }
             
            //
            clsDevice objDevice = (clsDevice)cboDevice.SelectedItem;
            if ( objDevice == null || objHex.objParsedSettings == null || objHex.objParsedSettings.device == null ) {
                picHexContent.Image = null;
                return;
            }*/

            //            
            int iMaxRow = objDevice.flashSizePcu / objDevice.family.pcuPerWord / objDevice.rowSizeW;
            //int iMaxPage = iMaxRow / objDevice.pageSizeR;
 
            //
            Bitmap bmpHex = new Bitmap( picHexContent.Width, iMaxRow, e.Graphics );
            Graphics grpHex = Graphics.FromImage( bmpHex );            
 
            //            
            grpHex.Clear( Color.White );
            for ( int iRow = 0; iRow < iMaxRow; iRow++ ) {
                // Bootloader & User application
                if (  objHex.bProgRowUsed[iRow] == true && iRow >= objHex.GetBootloaderStartRow(objHex.objParsedSettings) && iRow <= objHex.GetBootloaderEndRow(objHex.objParsedSettings) ) {
                    grpHex.DrawLine( Pens.Red, 0, iRow, bmpHex.Width-1, iRow );
                
                // User application
                } else if ( objHex.bProgRowUsed[iRow] == true ) {
                    grpHex.DrawLine( Pens.Green, 0, iRow, bmpHex.Width-1, iRow );
                }

                // Bootloader
                if ( iRow >= objHex.GetBootloaderStartRow(objHex.objParsedSettings) && iRow <= objHex.GetBootloaderEndRow(objHex.objParsedSettings) ) {
                    grpHex.DrawLine( Pens.Orange, 0, iRow, bmpHex.Width-1, iRow );
                
                // User application
                } else if ( objHex.bProgRowUsed[iRow] == true ) {
                    grpHex.DrawLine( Pens.Green, 0, iRow, bmpHex.Width-1, iRow );
                }
            }
 
            //
            e.Graphics.DrawImage( 
                bmpHex,
                new Rectangle(0, 0, picHexContent.Width-1, picHexContent.Height-1),
                new Rectangle(0, 0, bmpHex.Width-1, bmpHex.Height-1), 
                GraphicsUnit.Pixel                 
            );
        }// picHexContent_Paint()
		
		
		//---------------------------------------------------------------------
		// picHexContent_SizeChanged()
		//---------------------------------------------------------------------
        private void picHexContent_SizeChanged(object sender, EventArgs e)
        {
            picHexContent.Refresh();
        }// picHexContent_SizeChanged()
		
		
		//---------------------------------------------------------------------
		// cboFiles_SelectedIndexChanged()
		//---------------------------------------------------------------------
        private void cboFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Update current
            UpdateRecentFile( strPrevFile );

            OpenFile( cboFiles.Text );
        }// cboFiles_SelectedIndexChanged()
		
				
		//---------------------------------------------------------------------
		// chkCustomBl_CheckedChanged()
        // Description: reparse hex-file when changing custom bl setting
		//---------------------------------------------------------------------
        private void chkCustomBl_CheckedChanged(object sender, EventArgs e)
        {
            txtCustomBlPlacementP.Enabled = chkCustomBl.Checked;
            txtCustomBlSizeP.Enabled = chkCustomBl.Checked;

            if ( chkCustomBl.Checked == true ) {
                txtCustomBlPlacementP.Focus();
            }

            DoParse( false );
        }// chkCustomBl_CheckedChanged()	
	

		//---------------------------------------------------------------------
		// txtCustmBlPlacement_Leave()
        // Description: reparse hex-file when leaving custom bl setting textbox
		//---------------------------------------------------------------------
        private void txtCustmBlPlacement_Leave(object sender, EventArgs e)
        {
            txtInfo.Enabled = true;
            int iBlPlacementP;

            try {
                iBlPlacementP = int.Parse( txtCustomBlPlacementP.Text );                
            } catch {
                iBlPlacementP = 1;
            }
            
            if ( iBlPlacementP < 1 ) {
                iBlPlacementP = 1;
            }
            txtCustomBlPlacementP.Text = iBlPlacementP.ToString();

            DoParse( false );
        }// txtCustmBlPlacement_Leave()

		
		
		//---------------------------------------------------------------------
		// txtCustmBlSize_Leave()
        // Description: reparse hex-file when leaving custom bl setting textbox
		//---------------------------------------------------------------------
        private void txtCustmBlSize_Leave(object sender, EventArgs e)
        {
            txtInfo.Enabled = true;
            int iBlSizeP;

            try {
                iBlSizeP = int.Parse( txtCustomBlSizeP.Text );                
            } catch {
                iBlSizeP = 1;
            }
            
            if ( iBlSizeP < 1 ) {
                iBlSizeP = 1;
            }
            txtCustomBlSizeP.Text = iBlSizeP.ToString();

            DoParse( false );
        }// txtCustmBlSize_Leave()
		
		
		//---------------------------------------------------------------------
		// chkAllowBlOverwrite_CheckedChanged()
        // Description: reparse hex-file when allow overwrite setting is changed
		//---------------------------------------------------------------------
        private void chkAllowBlOverwrite_CheckedChanged(object sender, EventArgs e)
        {
            DoParse( false );
        }// chkAllowBlOverwrite_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// mnuRecentFileRemove_Click()
        // Description: remove recent file from combobox
		//---------------------------------------------------------------------
        private void mnuRecentFileRemove_Click(object sender, EventArgs e)
        {
            objRecentFiles.RemoveFile( cboFiles.Text );
        }// mnuRecentFileRemove_Click()
		
		
		//---------------------------------------------------------------------
		// mnuCmdReparse_Click()
        // Description: parse hex-file
		//---------------------------------------------------------------------
        private void mnuCmdReparse_Click(object sender, EventArgs e)
        {
            DoParse( true );
        }// mnuCmdReparse_Click()
		
		
		//---------------------------------------------------------------------
		// txtTermTx_TextChanged()
        // Description: if hex, calculate crc and validate format
		//---------------------------------------------------------------------
        private void txtTermTx_TextChanged(object sender, EventArgs e)
        {
            if ( cboTermTxType.Text.ToLower() == "text" ) {
                txtTermTx.ForeColor = Color.Black;
                lblTxCRC.Text = "-";
                return;
            }

            bool bSplitResult = false;
            byte [] bTx = GHelper.clsMisc.Split8bitHexStringToBytes( txtTermTx.Text, ref bSplitResult );
            if ( bSplitResult == false ) {
                txtTermTx.ForeColor = Color.Red;
                return;
            } else {
                txtTermTx.ForeColor = Color.Black;
            }
            lblTxCRC.Text = "0x" + GHelper.clsCRC16.CRC16( bTx, 0, bTx.Length ).ToString("X4");
        }// txtTermTx_TextChanged()
		
		
		//---------------------------------------------------------------------
		// mnuViewInfoWindow_CheckedChanged()
        // Description: show/close info windows
		//---------------------------------------------------------------------
        private void mnuViewInfoWindow_CheckedChanged(object sender, EventArgs e)
        {
            if ( mnuViewInfoWindow.Checked == false ) {
                if ( wndInfo != null ) {
                    wndInfo.Close();
                    wndInfo = null;
                }
            } else {
                clsDevice objDevice = (clsDevice)cboDevice.SelectedItem;
                if ( objDevice == null ) {
                    mnuViewInfoWindow.Checked = false;
                    MessageBox.Show( "No device is selected", "Show info", MessageBoxButtons.OK, MessageBoxIcon.Information );
                    return;
                }
                wndInfo = new frmInfo();   
                UpdateInfoWindow();
                wndInfo.Show( this );
                wndInfo.Location = new Point( this.Location.X+this.Width, this.Location.Y);                
                wndInfo.LocationChanged += new EventHandler(wndInfo_LocationChanged);                
            }
        }// mnuViewInfoWindow_CheckedChanged()
		
		
		//---------------------------------------------------------------------
		// wndInfo_LocationChanged()
        // Description: determine if the info window is docked to the main window
		//---------------------------------------------------------------------
        void wndInfo_LocationChanged(object sender, EventArgs e)
        {   
            int iA = 20;
            bInfoWindowIsDocked = false;

            // Left side
            if ( 
                wndInfo.Location.Y > this.Location.Y-iA && 
                wndInfo.Location.Y + wndInfo.Height < this.Location.Y+this.Height + iA &&
                wndInfo.Location.X > this.Location.X+this.Width-iA &&
                wndInfo.Location.X < this.Location.X+this.Width+iA 
            ) {
                bInfoWindowIsDocked = true;
                return;
            }
            // Right side
            if ( 
                wndInfo.Location.Y > this.Location.Y-iA && 
                wndInfo.Location.Y + wndInfo.Height < this.Location.Y+this.Height + iA &&
                wndInfo.Location.X+wndInfo.Width > this.Location.X-iA &&
                wndInfo.Location.X+wndInfo.Width < this.Location.X+iA 
            ) {
                bInfoWindowIsDocked = true;
                return;
            }
            // Top
            if ( 
                wndInfo.Location.Y+wndInfo.Height > this.Location.Y-iA && 
                wndInfo.Location.Y+wndInfo.Height < this.Location.Y+iA &&
                wndInfo.Location.X > this.Location.X-iA &&
                wndInfo.Location.X+wndInfo.Width < this.Location.X+this.Width+iA 
            ) {
                bInfoWindowIsDocked = true;
                return;
            }
            // Bottom
            if ( 
                wndInfo.Location.Y > this.Location.Y+this.Height-iA && 
                wndInfo.Location.Y < this.Location.Y+this.Height+iA &&
                wndInfo.Location.X > this.Location.X-iA &&
                wndInfo.Location.X+wndInfo.Width < this.Location.X+this.Width+iA 
            ) {
                bInfoWindowIsDocked = true;
                return;
            }
        }// wndInfo_LocationChanged()
		
		
		//---------------------------------------------------------------------
		// frmDS30Loader_LocationChanged()
        // Description: move info window if docked
		//---------------------------------------------------------------------
        Point poiWindowLastPos = new Point();
        bool bInfoWindowIsDocked = true;
        private void frmDS30Loader_LocationChanged(object sender, EventArgs e)
        {
            if ( this.WindowState != FormWindowState.Normal ) {
                return;
            }
            
            if ( wndInfo != null && bInfoWindowIsDocked ) {
                wndInfo.Location = new Point(
                    wndInfo.Location.X + this.Location.X - poiWindowLastPos.X, 
                    wndInfo.Location.Y + this.Location.Y - poiWindowLastPos.Y 
                );
            }

            poiWindowLastPos.X = this.Location.X;
            poiWindowLastPos.Y = this.Location.Y;
        }// frmDS30Loader_LocationChanged()
		
		
		//---------------------------------------------------------------------
		// btnPortSettings_Click()
        // Description: if available, open selected port settings window
		//---------------------------------------------------------------------
        private void btnPortSettings_Click(object sender, EventArgs e)
        {
            if ( objPort == null ) return;
            objPort.OpenWindow( this );            
        }// btnPortSettings_Click()
		
		
		//---------------------------------------------------------------------
		// cboPort_TextChanged()
        // Description: keep track 
		//---------------------------------------------------------------------
        bool bPortTextHasChanged = false;
        private void cboPort_TextChanged(object sender, EventArgs e)
        {
            bPortTextHasChanged = true;
        }// cboPort_TextChanged()
		
		
		//---------------------------------------------------------------------
		// cboPort_Leave()
        // Description: update port selection if text has been changed
		//---------------------------------------------------------------------
        private void cboPort_Leave(object sender, EventArgs e)
        {
            if ( bPortTextHasChanged == true ) {
                UpdatePortSelection();
            }
        }// cboPort_Leave()

		
		//---------------------------------------------------------------------
		// cboPort_SelectedIndexChanged()
        // Description: checks if a can port is selected and shows/hides id textbox
		//---------------------------------------------------------------------
        private void cboPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdatePortSelection();
            
            bPortTextHasChanged = false;
        }// cboPort_SelectedIndexChanged()	

		
		//---------------------------------------------------------------------
		// btnExportDeviceDb_Click()
        // Description: 
		//---------------------------------------------------------------------
        private void btnExportDeviceDb_Click(object sender, EventArgs e)
        {
            clsDeviceDb.ExportDeviceDB( "devices.xml" );
        }// btnExportDeviceDb_Click()	

		
		//---------------------------------------------------------------------
		// chkAddCRC_CheckedChanged()
        // Description: reparse
		//---------------------------------------------------------------------
        private void chkAddCRC_CheckedChanged(object sender, EventArgs e)
        {
            DoParse( false );
        }// chkAddCRC_CheckedChanged()

		
		//---------------------------------------------------------------------
		// txtCustomBlPlacementP_Enter()
        // Description: circumvent some weird exception coming from ScrollToCaret() on txtInfo
		//---------------------------------------------------------------------
        private void txtCustomBlPlacementP_Enter(object sender, EventArgs e)
        {
            txtInfo.Enabled = false;
        }// txtCustomBlPlacementP_Enter()

        //---------------------------------------------------------------------
		// txtCustomBlSizeP_Enter()
        // Description: circumvent some weird exception coming from ScrollToCaret() on txtInfo
		//---------------------------------------------------------------------
        private void txtCustomBlSizeP_Enter(object sender, EventArgs e)
        {
            txtInfo.Enabled = false;
        }// txtCustomBlSizeP_Enter()


        //---------------------------------------------------------------------
		// btnReparseHexFile_Click()
        //---------------------------------------------------------------------
        private void btnReparseHexFile_Click(object sender, EventArgs e)
        {
            DoParse( true );
        }// btnReparseHexFile_Click()	


        //---------------------------------------------------------------------
		// mnuViewSettingsDir_Click()
        //---------------------------------------------------------------------
        private void mnuViewSettingsDir_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start( GetSettingsFilesPath() );
        }// mnuViewSettingsDir_Click()	
    
    }// Class: frmDS30Loader
}
