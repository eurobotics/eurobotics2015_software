﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader console
//
// Copyright:		Copyright © 09-10, Mikael Gustafsson
//
// Version:			1.0.0 september 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			1.0.0 Added option to list available ports
//                  0.9.5 Bugfix: --write-eeprom gave an error
//                  0.9.4 Added auto baud rate and echo verification
//                        Updated to work with new engine
//                  0.9.3 Bugfix: removed "press any key" from non interactive mode
//                  0.9.2 Added custom bootloader settings
//                  0.9.1 Added option that when used doesn're require user interaction
//                  0.9.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader console.
//
//    ds30 Loader console is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader console is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader console.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------    

using System;
using System.IO;
using System.Collections;

using ds30Loader;
using GHelper;

namespace ds30_Loader_Console
{
    //-------------------------------------------------------------------------
    // Class: clsds30LConsole
    //-------------------------------------------------------------------------
    class clsds30LConsole
    {
        //---------------------------------------------------------------------
        // Variables
        //---------------------------------------------------------------------
        
        // From ValidateParseArgs()
        private string strFile = "";
        private bool bNonInteractive = false;

        //
        private clsDevice objDevice = null;
        private clsHex objHex = null;
        

        
        //---------------------------------------------------------------------
        // Constants
        //---------------------------------------------------------------------
        private const string strURLHomepage = "http://mrmackey.no-ip.org/elektronik/ds30loader/";        
        private const string strVersion = "0.9.5";


        //---------------------------------------------------------------------
        // Constructor
        //---------------------------------------------------------------------
        public clsds30LConsole()
        {
            clsds30Loader.Downloading += new clsds30Loader.DownloadingDelegate( ds30L_Downloading );
        }// Constructor


        //---------------------------------------------------------------------
		// ds30L_Downloading()
		//---------------------------------------------------------------------
        private void ds30L_Downloading( object obj, clsDownloadingEventArgs e ) 
        {
            switch ( e.eventType ) {
	            case clsDownloadingEventArgs.EventType.started:
                    clsDebugTextbox.OutputInfo( e.message, e.tabLevel );
                    break;
                
                case clsDownloadingEventArgs.EventType.error:
                    clsDebugTextbox.OutputError( e.message, e.tabLevel );
                    break;

                case clsDownloadingEventArgs.EventType.warning:
                    clsDebugTextbox.OutputWarning( e.message, e.tabLevel );
                    break;
                
                case clsDownloadingEventArgs.EventType.info:
                    clsDebugTextbox.OutputInfo( e.message, e.tabLevel );
                    break;

                case clsDownloadingEventArgs.EventType.success:
                    clsDebugTextbox.OutputSuccess( e.message, e.tabLevel );
                    break;

                case clsDownloadingEventArgs.EventType.progressStarted:
                    break;
                
                case clsDownloadingEventArgs.EventType.progress:
                    break;
                
                case clsDownloadingEventArgs.EventType.progressEnded:
                    break;

                case clsDownloadingEventArgs.EventType.completed:
                    clsDebugTextbox.OutputSuccess( e.message, e.tabLevel );
                    break;
            }            
        }//ds30L_Downloading()	

        
        //---------------------------------------------------------------------
        // Constructor
        //---------------------------------------------------------------------
        public void DoMagic( string[] pstrArgs, ref bool pbResult ) 
        {
            pbResult = false;            

            
            //-----------------------------------------------------------------
            // If no argumentsa are specified, display help
            //-----------------------------------------------------------------
            if ( pstrArgs.Length == 0 ) {
                PrintHelp();
                return;
            }


            //-----------------------------------------------------------------
            // Validate arguments
            //-----------------------------------------------------------------
            bool bResult = false;
            clsParseSettings objParseSettings = new clsParseSettings();
            clsDownloadSettings objDownloadSettings = new clsDownloadSettings();
            ValidateParseArgs( pstrArgs, objParseSettings, objDownloadSettings, ref bResult );
            if ( bResult == false ) {
                return;
            }


            //-----------------------------------------------------------------
            // Nothing to do?
            //-----------------------------------------------------------------
			if ( objDownloadSettings.writeProgram == false && objDownloadSettings.writeEeprom == false && objDownloadSettings.writeConfigs == false  ) {
				Console.WriteLine( "Nothing to do." );
				return;
			}


            //-----------------------------------------------------------------
            // Parse
            //-----------------------------------------------------------------
            objParseSettings.device = objDevice;
            DoParse( objParseSettings, objDownloadSettings );


            //-----------------------------------------------------------------
            // Print settings
            //-----------------------------------------------------------------
            Console.WriteLine( "" );
            Console.WriteLine( "" );
            Console.WriteLine( "{0,-10} {1, -8}", "File:", strFile );
            Console.WriteLine( "{0,-10} {1, -8}", "Device:", objDevice.name );
            Console.WriteLine( "{0,-10} {1, -8}", "Port:", objDownloadSettings.portName );
            Console.WriteLine( "{0,-10} {1, -8}", "Baudrate:", objDownloadSettings.baudRate.ToString() );
            


            //-----------------------------------------------------------------
            // 
            //-----------------------------------------------------------------            
            Console.WriteLine( "" );
            Console.WriteLine( "" );
            if ( bNonInteractive == false ) {
                Console.WriteLine( "Press any key to begin download" );
                Console.WriteLine( "" );
                Console.ReadKey();
            }
            

            //-----------------------------------------------------------------
            // Download
            //-----------------------------------------------------------------
            bool bDownloadResult = false;
            clsds30Loader.Download( objDevice, objHex, objDownloadSettings, 0, ref bDownloadResult );           
            
            if ( bNonInteractive == false ) {
                Console.WriteLine( "" );
                Console.WriteLine( "Press any key to continue" );
                Console.ReadKey();
            }


            pbResult = bDownloadResult;
        }// DoMagic()


		//---------------------------------------------------------------------
		// DoParse()
		// Description:
		//---------------------------------------------------------------------
		private void DoParse( clsParseSettings pobjParseSettings, clsDownloadSettings pobjDownloadSettings )
		{	
            bool bParseResult = false;

            // Here we only assume a bootloader size to be able to parse the hex-file            
            switch ( objDevice.family.name ) {
                case "PIC16F":
                    objHex = new clsHex16F( strFile );
                    break;
                case "PIC18F":
                    objHex = new clsHex18F( strFile );
                    break;
                case "PIC18FJ":
                    objHex = new clsHex18FJ( strFile );           
                     break;
                case "PIC24F":
                    objHex = new clsHex24F( strFile );
                    break;
                case "PIC24FJ":
                    objHex = new clsHex24FJ( strFile );            
                    break;
                case "PIC24HJ":
                    objHex = new clsHex24H( strFile );
                    break;
                case "dsPIC30F":			
				    objHex = new clsHex30F( strFile );			
                    break;
                case "dsPIC33FJ":
				    objHex = new clsHex33FJ( strFile );	            
                    break;
                default:
                    clsDebugTextbox.OutputError( "Unknown famile: " + objDevice.family.name, 0 );
				    return;
			}

            int iBlSizeP = objHex.defaultBlSizeP;
            int iBlPlacementP = objHex.defaultBlPlacementP;
	        
            // Check file existence
            if ( File.Exists(strFile) == false ) {
                return;
            }

            // Enum events
            objHex.HexFileValidate += new clsHex.HexFileValidateDelegate( Hex_Validate );
            objHex.HexFileParse += new clsHex.HexFileParseDelegate( Hex_Parse );

            // Parse
			if ( objDevice != null ) {
				objHex.ParseHexFile( pobjParseSettings, false, 0, ref bParseResult );
				
				pobjDownloadSettings.writeProgram &= objHex.hasValidProgram;
                pobjDownloadSettings.writeEeprom &= objHex.hasValidEeprom;
                pobjDownloadSettings.writeConfigs &= objHex.hasValidConfigs;
			}		
		}//DoParse();


		//---------------------------------------------------------------------
		// Hex_Parse()
		//---------------------------------------------------------------------
		private void Hex_Parse( object obj, clsHexFileParseEventArgs e ) 
        { 
            clsHex objHex = (clsHex)obj;

            switch ( e.eventType ) {
			    case clsHexFileParseEventArgs.EventType.started:
                    clsDebugTextbox.OutputInfo( "Parsing hex-file...", e.tabLevel );
                    break;

                case clsHexFileParseEventArgs.EventType.warning:
                    clsDebugTextbox.OutputWarning( e.message, e.tabLevel );
                    break;
            
                case clsHexFileParseEventArgs.EventType.info:
                    clsDebugTextbox.OutputInfo( e.message, e.tabLevel );
                    break;
            
                case clsHexFileParseEventArgs.EventType.failed:
                    clsDebugTextbox.OutputError( "Parsing of hex-file failed", e.tabLevel );                
                    break;

                case clsHexFileParseEventArgs.EventType.success:
                    clsDebugTextbox.OutputSuccess( "Hex-file successfully parsed", e.tabLevel );
                    clsDebugTextbox.OutputInfo( "", 0 );
                    clsDebugTextbox.OutputInfo( objHex.progWordsUsed.ToString() + " program words found in " + objHex.progRowsUsed.ToString() + " rows ", e.tabLevel );
                    clsDebugTextbox.OutputInfo( objHex.eeWordsUsed.ToString() + " Eeprom words found ", e.tabLevel);
                    clsDebugTextbox.OutputInfo( objHex.configWordsUsed.ToString() + " config words found ", e.tabLevel );			
                    break;
                
                default:
                    clsDebugTextbox.OutputSuccess( "Unknown hex event", e.tabLevel );                
                    break;
            }
		}//Hex_Parse()	


        //---------------------------------------------------------------------
		// Hex_Validate()
		//---------------------------------------------------------------------
		private void Hex_Validate( object obj, clsHexFileValidateEventArgs e ) 
        {
            switch ( e.eventType ) {
                case clsHexFileValidateEventArgs.EventType.started:
                    clsDebugTextbox.OutputInfo( "Validating hex-file...", e.tabLevel );
                    break;
            
                case clsHexFileValidateEventArgs.EventType.failed:
                    clsDebugTextbox.OutputError( e.message );
                    break;

                case clsHexFileValidateEventArgs.EventType.success:
                    clsDebugTextbox.OutputSuccess( "ok" );
                    break;
                
                default:
                    clsDebugTextbox.OutputSuccess( "Unknown hex event", e.tabLevel );     
                    break;               
            }
		}//Hex_Validate()	


        //-------------------------------------------------------------------------
        // OutputOption()
        //-------------------------------------------------------------------------
        private void OutputOption( string pstrShort, string pstrLong, string pstrDescription )
        {
            Console.WriteLine("{0,-8} {1, -8} {2,-24} {3,-32}", "", "-"+pstrShort, "--"+pstrLong, pstrDescription );
        }// OutputOption


        //-------------------------------------------------------------------------
        // PrintHelp()
        //-------------------------------------------------------------------------
        private void PrintHelp()
        {
            //---------------------------------------------------------------------
            // Header
            //---------------------------------------------------------------------            
            Console.WriteLine( "" );
            Console.WriteLine( "" );
            Console.WriteLine( "ds30 Loader console " + strVersion );
            Console.WriteLine( "ds30 Loader engine " + clsds30Loader.strVersion);
            Console.WriteLine( strURLHomepage );
            Console.WriteLine( "" );
            Console.WriteLine( "" );
            Console.WriteLine( "Usage: ds30loaderconsole options" );


            //---------------------------------------------------------------------
            // Non-optional options
            //---------------------------------------------------------------------
            Console.WriteLine( "" );
            Console.WriteLine( "" );
            Console.WriteLine( "NON-OPTIONAL OPTIONS" );
            OutputOption( "f=val", "file=filename", "Hex-file" );
            OutputOption( "d=val", "device=devicename", "Devicename" );
            OutputOption( "k=val", "port=portname", "Portname" );
            OutputOption( "r=val", "baudrate=value", "Baudrate" );


            //---------------------------------------------------------------------
            // Optional options
            //---------------------------------------------------------------------
            Console.WriteLine( "" );
            Console.WriteLine( "" );
            Console.WriteLine( "OPTIONAL OPTIONS" );
            OutputOption( "h", "help", "Displays help" );
            OutputOption( "l", "debugmode", "Debugmode" );
            OutputOption( "o", "non-interactive", "Starts download without user interaction" );
            OutputOption( "z", "list-ports", "lists available ports" );
            Console.WriteLine( "" );
            OutputOption( "p", "write-program", "Downloads program" );
            OutputOption( "e", "write-eeprom", "Downloads eeprom" );
            Console.WriteLine( "" );
            OutputOption( "g", "no-goto", "Don't write goto" );
            OutputOption( "s", "allow-bl-overwrite", "Allow overwrite of bootloader" );
            OutputOption( "c", "write-config", "Downloads configs" );            
            OutputOption( "v=val", "customplacement", "Custom bootloader placement, pages from end" );
            OutputOption( "w=val", "customsize", "Custom bootloader size, page(s)" );
            OutputOption( "x", "auto-baudrate", "Send auto baud rate sync character" );            
            OutputOption( "y", "echo-verification", "Very tx echoes" );            
            Console.WriteLine( "" );
            OutputOption( "a=val", "polltime=time", "Polltime [ms] [" + clsDownloadSettings.iPolltimeDefault + "]" );
            OutputOption( "t=val", "timeout=time", "Time before timeout [ms] [" + clsDownloadSettings.iTimeoutDefault + "]"  );
            Console.WriteLine( "" );
            OutputOption( "q=val", "reset-command", "Reset device by specified command" );
            OutputOption( "u=val", "reset-baudrate", "Baudrate for reset command" );
            OutputOption( "m", "reset-dtr", "Reset device by dtr" );
            OutputOption( "n", "reset-rts", "Reset device by rts" );
            OutputOption( "b=val", "resettime=time", "Resettime [ms] [" + clsDownloadSettings.iResetTimeDefault + "]" );
            Console.WriteLine( "" );
            OutputOption( "i", "activate-dtr", "Activate device by dtr" );
            OutputOption( "j", "activate-rts", "Activate device by rts" );
            Console.WriteLine( "" );
            Console.WriteLine( "" );
        }// PrintHelp()


        //-------------------------------------------------------------------------
        // ValidateParseArgs()
        //-------------------------------------------------------------------------
        private void ValidateParseArgs( string[] pstrArgs, clsParseSettings pobjParseSettings, clsDownloadSettings pobjDownloadSettings, ref bool pbResult ) 
        {
            pbResult = false;

            //
            string [] strSplitArgs;
            string strOption;
            string strOptionValue;
            string strArgument;

            //
            bool bFileSpecified = false;
            bool bPortSpecified = false;
            bool bBaudrateSpecified = false;
            bool bDeviceSpecified = false;
            bool bCustomBlPlacementSpecified = false;
            bool bCustomBlSizeSpecified = false;
            bool bListPorts = false;


            foreach ( string strArg in pstrArgs ) {
                //
                strArgument = strArg;
                if ( strArg.EndsWith("=") ) {
                    strArgument += "0";
                }
                strSplitArgs = strArgument.Split('=');
                
                // Argument                
                strOption = strSplitArgs[0].ToLower();
                
                // Argument value
                if ( strSplitArgs.Length == 2 ) {
                    strOptionValue = strSplitArgs[1];
                } else if (strSplitArgs.Length == 1 ) {
                    strOptionValue = "";
                } else {
                    Console.WriteLine( "Invalid argument: " + strArg );
                    return;
                }

                switch ( strOption ) {
                    //---------------------------------------------------------
                    // Misc
                    //---------------------------------------------------------

                    // Help
                    case "-h":
                    case "--help":
                        PrintHelp();
                        return;

                    // Debugmode
                    case "-l":
                    case "--debugmode":
                        clsds30Loader.debugMode = true;
                        break;

                    // Non-interactive
                    case "-o":
                    case "--non-interactive":
                        bNonInteractive = true;
                        break;

   
                    // List ports
                    case "-z":
                    case "--list-ports":
                        bListPorts = true;
                        break;
                 

                    //---------------------------------------------------------
                    // Basic
                    //---------------------------------------------------------

                    // Hex-file
                    case "-f":
                    case "--file":
                        strFile = strOptionValue;    
                        if ( File.Exists(strFile) == false ) {
                            Console.WriteLine( "Non-existing file specified." );
                            return;
                        }
                        bFileSpecified = true;
                        
                        break;
                    
                    // Devicename
                    case "-d":
                    case "--device":
                        objDevice = clsDeviceDb.DeviceGet( strOptionValue );
                        if ( objDevice == null ) {
                            Console.WriteLine( "Unknown device specified." );
                            return;
                        }
                        bDeviceSpecified = true;
                        break;
                      

                    // Portname
                    case "-k":
                    case "--port":
                        pobjDownloadSettings.portName = strOptionValue;
                        bPortSpecified = true;
                        break; 
                    
                    // Baudrate
                    case "-r":
                    case "--baudrate":
                        try {
                            pobjDownloadSettings.baudRate = int.Parse( strOptionValue );
                        } catch {
                            Console.WriteLine( "Invalid baudrate specified." );
                            return;
                        }
                        if ( pobjDownloadSettings.baudRate <= 0 ) {
                            Console.WriteLine( "Invalid baudrate specified." );
                            return;
                        }
                        bBaudrateSpecified = true;
                        break;
                    
                    // Write program
                    case "-p":
                    case "--write-program":
                        pobjDownloadSettings.writeProgram = true;
                        break;
                    
                    // Write Eeprom
                    case "-e":
                    case "--write-eeprom":
                        pobjDownloadSettings.writeEeprom = true;
                        break;                    
                    

                    //---------------------------------------------------------
                    // Advanced
                    //---------------------------------------------------------
                    
                    // Don't write goto
                    case "-g":
                    case "--no-goto":
                        pobjParseSettings.noGoto = true;
                        pobjDownloadSettings.noGoto = true;
                        break;
                     
                    // Allow overwrite of bootloader
                    case "-s":
                    case "--allow-bl-overwrite":
                        pobjParseSettings.allowBlOverwrite = true;
                        pobjDownloadSettings.allowBlOverwrite = true;
                        break;

                    // Write configs
                    case "-c":
                    case "--write-configs":
                        pobjDownloadSettings.writeConfigs = true;
                        break;


                     // Custom bootloader placement, pages from end
                    case "-v":
                    case "--customplacement":
                        int iCustomBlPlacementP;
                        try {
                            iCustomBlPlacementP = int.Parse( strOptionValue );
                        } catch {
                            Console.WriteLine( "Invalid custom bootloader placement specified." );
                            return;
                        }
                        if ( iCustomBlPlacementP <= 0 ) {
                            Console.WriteLine( "Invalid custom bootloader placement specified." );
                            return;
                        }
                        pobjDownloadSettings.customBlPlacementP = iCustomBlPlacementP;
                        pobjDownloadSettings.customBl = true;
                        bCustomBlPlacementSpecified = true;
                        break;   

                     // Custom bootloader size, pages
                    case "-w":
                    case "--customsize":
                        int iCustomBlSizeP;
                        try {
                            iCustomBlSizeP = int.Parse( strOptionValue );
                        } catch {
                            Console.WriteLine( "Invalid custom bootloader size specified." );
                            return;
                        }
                        if ( iCustomBlSizeP <= 0 ) {
                            Console.WriteLine( "Invalid custom bootloader size specified." );
                            return;
                        }
                        pobjDownloadSettings.customBlSizeP = iCustomBlSizeP;
                        pobjDownloadSettings.customBl = true;
                        bCustomBlSizeSpecified = true;
                        break;

                    // Auto baud rate
                    case "-x":
                    case "--auto-baudrate":
                        pobjDownloadSettings.autoBaudrate = true;
                        break;

                    // Echo verification
                    case "-y":
                    case "--echo-verification":
                        pobjDownloadSettings.echoVerification = true;
                        break;
                    
                    //---------------------------------------------------------
                    // Timing
                    //---------------------------------------------------------

                    // Polltime
                    case "-a":
                    case "--polltime":
                        int iPolltime;
                        try {
                            iPolltime = int.Parse( strOptionValue );
                        } catch {
                            Console.WriteLine( "Invalid polltime specified." );
                            return;
                        }
                        if ( iPolltime <= 0 ) {
                            Console.WriteLine( "Invalid polltime specified." );
                            return;
                        }
                        pobjDownloadSettings.polltime = iPolltime;
                        break;
                    
                    // Timeout
                    case "-t":
                    case "--timeout":
                        int iTimeout;
                        try {
                            iTimeout = int.Parse( strOptionValue );
                        } catch {
                            Console.WriteLine( "Invalid timeout specified." );
                            return;
                        }
                        if ( iTimeout <= 0 ) {
                            Console.WriteLine( "Invalid timeout specified." );
                            return;
                        }
                        pobjDownloadSettings.timeout = iTimeout;
                        break;


                    //---------------------------------------------------------
                    // Reset
                    //---------------------------------------------------------

                    // Reset by rts
                    case "-n":
                    case "--reset-rts":
                        pobjDownloadSettings.resetRts = true;
                        break;  
                 
                    // Reset by dtr
                    case "-m":
                    case "--reset-dtr":
                        pobjDownloadSettings.resetDtr = true;
                        break;

                    // Reset by command
                    case "-q":
                    case "--reset-command":
                        pobjDownloadSettings.resetCommand = true;
                        pobjDownloadSettings.resetCommandSequence = strOptionValue;
                        break;

                     // Reset baudrate
                    case "-u":
                    case "--reset-baudrate":
                        int iResetBaudrate;
                        try {
                            iResetBaudrate = int.Parse( strOptionValue );
                        } catch {
                            Console.WriteLine( "Invalid reset baudrate specified." );
                            return;
                        }
                        if ( iResetBaudrate <= 0 ) {
                            Console.WriteLine( "Invalid reset baudrate specified." );
                            return;
                        }
                        pobjDownloadSettings.resetBaudrate = iResetBaudrate;
                        break;

                    
                    // Resettime
                    case "-b":
                    case "--resettime":
                        int iResettime;
                        try {
                            iResettime = int.Parse( strOptionValue );
                        } catch {
                            Console.WriteLine( "Invalid resettime specified." );
                            return;
                        }
                        if ( iResettime <= 0 ) {
                            Console.WriteLine( "Invalid resettime specified." );
                            return;
                        }
                        pobjDownloadSettings.resetTime = iResettime;
                        break;


                    //---------------------------------------------------------
                    // Activation
                    //---------------------------------------------------------

                    // Activate by rts
                    case "-j":
                    case "--activate-rts":
                        pobjDownloadSettings.activateRts = true;
                        break;

                    // Activate by dtr
                    case "-i":
                    case "--activate-dtr":
                        pobjDownloadSettings.activateDtr = true;
                        break;


                    //---------------------------------------------------------
                    // Unknown option
                    //---------------------------------------------------------
                    default:
                        Console.WriteLine( "Unknown option \"" + strArg + "\"" );
                        Console.WriteLine( "" );
                        return;

                }
            }

            if ( bListPorts ) {
                ArrayList lstPorts = clsds30LoaderPorts.ports;
                Console.WriteLine( "\n\nAvailable ports" );
                
                foreach ( string strPort in lstPorts ){
                    Console.Write( strPort );
                    IPort objPort = clsds30LoaderPorts.GetPortObjectFromName( strPort );
                    if ( objPort != null ) {
                        if ( objPort.allowCustomBaudRate == false ) {
                            Console.Write( ", available baud/bitrates: " );
                            ArrayList lstBaudrates = objPort.GetBaudRates();
                            foreach ( int iBaudrate in lstBaudrates ) {
                                Console.Write( iBaudrate.ToString() + ", " );
                            }
                            Console.Write( "\n" );
                        } else {
                            Console.Write( ", no restrictions on baud/bitrate by ds30 Loader\n" );
                        }
                    }
                }
                Console.WriteLine( "\nEnd of available ports, exiting" );

                if ( bNonInteractive == false ) {
                    Console.WriteLine( "Press any key to continue" );
                    Console.WriteLine( "" );
                    Console.ReadKey();
                }
                pbResult = false;
                return;
            }


            if ( bFileSpecified == false ) {
                Console.WriteLine( "File not specified" );
                return;
            }
            if ( bPortSpecified == false ) {
                Console.WriteLine( "Port not specified" );
                return;
            }
            if ( bBaudrateSpecified == false ) {
                Console.WriteLine( "Baudrate not specified" );
                return;
            }
            if ( bDeviceSpecified == false ) {
                Console.WriteLine( "Device not specified" );
                return;
            }

            if ( (bCustomBlPlacementSpecified ^ bCustomBlSizeSpecified) == true ) {
                Console.WriteLine( "Both or none of custom bootloader placement/size must be specified" );
                return;
            }

            pbResult = true;
        }// ValidateParseArgs()

    }// Class: clsds30LConsole
}
