﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader Console.
//
//    ds30 Loader console is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader console is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader console.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;

using GHelper;
using ds30Loader;

namespace ds30_Loader_Console
{
    //-------------------------------------------------------------------------
    // Class: Program
    //-------------------------------------------------------------------------
    class Program
    {
        //---------------------------------------------------------------------
        // Main()
        //---------------------------------------------------------------------
        static int Main( string[] args )
        {
            clsDebugTextbox.bConsole = true;
            Console.Clear();

            // Base path
            string strBasePath = Path.GetDirectoryName( Process.GetCurrentProcess().MainModule.FileName );
            if ( strBasePath.EndsWith(Path.DirectorySeparatorChar.ToString()) == false ) {
                strBasePath += Path.DirectorySeparatorChar;
            }

            //---------------------------------------------------------------------	
			// Init ports
            //---------------------------------------------------------------------	
            clsds30LoaderPorts.Init( strBasePath, /*null,*/ 0 );


            //---------------------------------------------------------------------	
            // Init device database
            //---------------------------------------------------------------------	
            clsDeviceDb.ImportDeviceDB( strBasePath + "devices.xml" );


            //---------------------------------------------------------------------	
            //
            //---------------------------------------------------------------------	
            bool bResult = false;
            clsds30LConsole objds30LConsole = new clsds30LConsole();
            objds30LConsole.DoMagic( args, ref bResult );

            
            // Check result
            if ( bResult == false ) {
                System.Environment.ExitCode = -1;
                return -1;
            } else {
                System.Environment.ExitCode = 0;
                return 0;
            }
        }// Main()

    }// Class: Program
}
