﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  

using System;
using System.IO;
using GHelper;


namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsHex16F
	//-------------------------------------------------------------------------
	public class clsHex16F : clsHex
	{
		//---------------------------------------------------------------------
		// Size suffixes
		//---------------------------------------------------------------------
		// R - rows
		// W - words
		// P - program counter units
		// B3 - bytes
	

		//---------------------------------------------------------------------
		// 
		//---------------------------------------------------------------------
		// 1 page = 8 rows = 32 words = 64 pcu = 64 bytes (PIC16F87)
	

		//---------------------------------------------------------------------
		// Constants
		//---------------------------------------------------------------------
        public const int i16FDefaultBlPlacementP = 6;  //page from the end
        public const int i16FDefaultBlSizeP = 6;       //[pages]

        private const int iPageSizeR = 8;
        //public const int iProgPageUsedBufferSize = 2048;
        public const int iProgPageUsedBufferSize = 16384;
		public const int iProgRowUsedBufferSize = iProgPageUsedBufferSize * iPageSizeR;
		public const int iProgMemBufferSize = iProgPageUsedBufferSize * 32 * 2;
		
        public const int iEEWordsUsedBufferSize = 2048;
        public const int iEEMemBufferSize = iEEWordsUsedBufferSize;	

        public const int iConfigWordsUsedBufferSize = 16;
        public const int iConfigMemBufferSize = iConfigWordsUsedBufferSize;
		

        //---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		public clsHex16F( string pstrFilename ) : base ( pstrFilename )
		{
            SizeBuffers( 
                iProgPageUsedBufferSize, iProgRowUsedBufferSize, iProgMemBufferSize, 
                iEEWordsUsedBufferSize, iEEMemBufferSize, 
                iConfigWordsUsedBufferSize, iConfigMemBufferSize 
            );

            iDefaultBlPlacementP = i16FDefaultBlPlacementP;
            iDefaultBlSizeP = i16FDefaultBlSizeP;
		}// Constructor()


        //---------------------------------------------------------------------
		// ParseHexFile()
		//---------------------------------------------------------------------
        override public void ParseHexFile( clsParseSettings pobjSettings, bool pbForce, int iTabLevel, ref bool pbResult )
		{
            //---------------------------------------------------------------------
		    // Allready parsed?
		    //---------------------------------------------------------------------
            pobjSettings.fileTimestamp = File.GetLastWriteTime( filename );
            if ( NeedsParsing(pobjSettings) == false && pbForce == false ) {
                pbResult = true;
                return; 
            }


            //
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.started, "Parsing hexfile...", iTabLevel++) );
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "File timestamp: " + pobjSettings.fileTimestamp.ToString(), iTabLevel) );

            //
            bIsParsed = false;
			bHasValidProgram = true;
			bHasValidEeprom = true;
			bHasValidConfigs = true;
			
		    
		    //---------------------------------------------------------------------
		    // Validate hex-file
		    //---------------------------------------------------------------------
            bool bValidateResult = false;
            ValidateHexFile( iTabLevel, ref bValidateResult );
            if ( bValidateResult == false ) {
                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.failed, "Parsing of hex-file aborted", iTabLevel++) );
                pbResult = false;
                return;
            }


            //--------------------------------------------------------------------------
            // 
            //--------------------------------------------------------------------------            
            InitBuffers( pobjSettings, iTabLevel );
            ParseHexFilePIC16( pobjSettings, iTabLevel );
            CheckForBlOverwrite( pobjSettings, iTabLevel );
            CheckForGotoAt0( pobjSettings, iTabLevel );
            SwapGoto( pobjSettings, iTabLevel );
            SetGotoToBl( pobjSettings, iTabLevel );            
            AddChecksum( pobjSettings, iTabLevel );            
            CalcHexContent( pobjSettings, iTabLevel );


            //--------------------------------------------------------------------------
            // Debug output
            //--------------------------------------------------------------------------
            if ( clsds30Loader.debugMode ) {
                OutputBlDebugInfo( pobjSettings, iTabLevel );
            }


			//--------------------------------------------------------------------------
			// Return
			//--------------------------------------------------------------------------
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.success, "Hex-file successfully parsed", iTabLevel) );            
            UpdateParsedSettings( pobjSettings );
			pbResult = true;
        }// ParseHexFile()
         
	}// Class: clsHex16F
}
