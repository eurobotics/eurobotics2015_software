﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
  

using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;
using System.Collections;
using System.IO;

using System.Reflection;
using GHelper;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Enum: PortType
	//-------------------------------------------------------------------------
    public enum PortType { Serial, CAN };


	//-------------------------------------------------------------------------
	// Class: clsds30LoaderPorts
	//-------------------------------------------------------------------------
	static public class clsds30LoaderPorts
	{
        static private ArrayList lstPorts = null;
        static private ArrayList lstPortTypes = null;
        static private Hashtable htPorts = null;	      
        

		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
        static clsds30LoaderPorts()
        {
            lstPorts = new ArrayList( 11 );
            lstPortTypes = new ArrayList( 5 );
            htPorts = new Hashtable( 11 );
        }// Constructor()


		//---------------------------------------------------------------------
		// Propery: ports
        // Description: returns an array with all available ports
		//---------------------------------------------------------------------	
        static public ArrayList ports
        {
            get {
                return lstPorts;
            }
        }// Propery: ports

        
        //---------------------------------------------------------------------
		// EnumPortPlugins()
        // Description: loads all port plugins and stores all available ports
		//---------------------------------------------------------------------	
		static private void EnumPortPlugins( string pstrPath/*, string [] strEnabledPorts*/, int piTabLevel ) 
        {
            string[] strPortPlugins = GetPortFiles( pstrPath );            
            
            bool bOk;
            AssemblyName assemblyName = null;
            Assembly assembly = null;
            Type type = null;
            string strFilename;
            //bool bPortIsEnabled;

            // Iterate available port plugins
            foreach ( string strPortPlugin in strPortPlugins ) {
                strFilename = Path.GetFileName( strPortPlugin );
                
                // Is port enabled?
                /*if ( strEnabledPorts != null ) {
                    bPortIsEnabled = false;
                    foreach ( string strEnabledPort in strEnabledPorts ) {
                        if ( strFilename == strEnabledPort ) {
                            bPortIsEnabled = true;
                            break;
                        }
                    }
                    if ( bPortIsEnabled == false ) {
                        continue;
                    }
                }*/

                bOk = true;

                clsDebugTextbox.OutputInfo( "Loading port plugin " + strFilename + ": ", piTabLevel );


                //-------------------------------------------------------------
                // Get assembly name
                //-------------------------------------------------------------
                if ( bOk == true ) {                    
                    try {
                        assemblyName = AssemblyName.GetAssemblyName( strPortPlugin );
                    } catch {   
                        assemblyName = null;
                    }

                    if ( assemblyName == null ) {
                        clsDebugTextbox.OutputError( "get assembly name failed", piTabLevel );
                        bOk = false;                        
                    }
                }

                //-------------------------------------------------------------
                // Load assembly
                //-------------------------------------------------------------
                if ( bOk == true ) {
                    try {
                        assembly = Assembly.Load( assemblyName );
                    } catch {
                        assembly = null;
                    }
                    if ( assembly == null ) {
                        clsDebugTextbox.OutputError( "load assembly failed", piTabLevel );
                        bOk = false;
                    }
                }    
 
                //-------------------------------------------------------------
                // Debug
                //-------------------------------------------------------------
                Type[] types = null;
                if ( bOk == true ) {
                    types = assembly.GetTypes();
                    foreach ( Type typ in types ) {
                    }
                }
                    
                //-------------------------------------------------------------
                // Get port class type and add to list
                //-------------------------------------------------------------
				if ( bOk == true ) {
                    try {
                        type = assembly.GetType( "ds30Loader.cls" + Path.GetFileNameWithoutExtension(strPortPlugin) );
                    } catch {
                        type = null;
                    }

                    if ( type == null ) {
                        clsDebugTextbox.OutputError( "get type failed" );
                        bOk = false;
                    }
                }          
                
                //-------------------------------------------------------------
                // Supported on this OS?
                //-------------------------------------------------------------
                if ( bOk == true ) {
                    bool bSupportsWindows = (bool)type.InvokeMember( "supportsWindows", BindingFlags.GetProperty, null, null, null );
                    bool bSupportsLinux = (bool)type.InvokeMember( "supportsLinux", BindingFlags.GetProperty, null, null, null );
                    bool bSupportsMac = (bool)type.InvokeMember( "supportsMac", BindingFlags.GetProperty, null, null, null ); 
                    if ( 
                        (GHelper.clsMisc.HostIsWindows() && bSupportsWindows == false) ||
                        (System.Environment.OSVersion.Platform == PlatformID.Unix && bSupportsLinux == false) ||
                        (System.Environment.OSVersion.Platform == PlatformID.MacOSX && bSupportsMac == false) 
                    ) {
                        clsDebugTextbox.OutputInfo( "no supported on this OS" );
                        continue;
                    }
                }
                
                
                //-------------------------------------------------------------
                // Get available ports from static method GetPorts
                //-------------------------------------------------------------
                if ( bOk == true ) {
                    ArrayList lstLocalPorts = null;
                    
                    bool bGetPortsSuccess = false;
                    object[] objArgs = new object[] { bGetPortsSuccess};
                    try {                        
                        lstLocalPorts = (ArrayList)type.InvokeMember( "GetPorts", BindingFlags.InvokeMethod, null, null, objArgs );
                    } catch {
                        bOk = false;
                        lstLocalPorts = null;
                        clsDebugTextbox.OutputInfo( "0 ports found, driver/hardware seems to not be installed" );
                        if ( clsds30Loader.debugMode ) clsDebugTextbox.OutputInfo( "invocation of GetPorts() failed" );
                    }
                    
                    bGetPortsSuccess = (bool)objArgs[0];

                    if ( bOk == true ) {
                        if ( bGetPortsSuccess == false ) {
                            clsDebugTextbox.OutputInfo( "0 ports found, driver/hardware seems to not be installed" );
                            if ( clsds30Loader.debugMode ) clsDebugTextbox.OutputInfo( "GetPorts() reported fail" );
                            bOk = false;
                        } else if (  bGetPortsSuccess == true && lstLocalPorts == null ) {
                            clsDebugTextbox.OutputError( "GetPorts() didn't return a valid port list", piTabLevel );
                        
                        } else if ( bGetPortsSuccess == true && lstLocalPorts != null ) {
                            lstPortTypes.Add( type );
                            foreach ( string strPort in lstLocalPorts ) {
                                lstPorts.Add( strPort );
                                htPorts.Add( strPort, type );
                            }
                            clsDebugTextbox.OutputSuccess( "found " + lstLocalPorts.Count.ToString() + " " + (lstLocalPorts.Count == 1 ? "port" : "ports") );
                        } else {
                            bOk = false;
                        }
                    }
                }
            }
		}// EnumPortPlugins()

        
        //---------------------------------------------------------------------
		// GetPortFiles()
        // Description: returns file names of availabel port pluginf
		//---------------------------------------------------------------------	
		static public string[] GetPortFiles( string pstrPath ) 
        {
            return Directory.GetFiles( pstrPath, "ds30LoaderPort*.dll" );
        }// GetPortFiles()

        
        //---------------------------------------------------------------------
		// GetPortObjectFromName()
        // Description: returns a port instance from a port name
		//---------------------------------------------------------------------	
		static public IPort GetPortObjectFromName( string pstrPortName ) 
        {
            IPort objPort = null;
            
            // Get type from name
            Type type = (Type)htPorts[ pstrPortName ];            
            
            // Unknown port name, return serial port
            if ( type == null ) {
                foreach ( Type typ in lstPortTypes ) {
                    if ( typ.Name.ToLower().Contains("serial") ) {
                        type = typ;
                        break;
                    }
                }
            }

            // Instantiate the port class type
            try {
                objPort = (IPort) Activator.CreateInstance( type );
            } catch ( Exception e ) {
                objPort = null;
                clsDebugTextbox.OutputError( "Port class instantiation failed: " + e.Message );
            }

            // Return port            
            return objPort;
		}// GetPortObjectFromName()


        //---------------------------------------------------------------------
		// Init()
		//---------------------------------------------------------------------	
		static public void Init( string pstrPath, /*string [] strEnabledPorts,*/ int piTabLevel  ) 
        {
            EnumPortPlugins( pstrPath, /*strEnabledPorts,*/ piTabLevel );
		}// Init()

	}// Class: clsds30LoaderPorts
}
