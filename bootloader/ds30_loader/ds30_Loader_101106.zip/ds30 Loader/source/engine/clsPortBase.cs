﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader
//
// Copyright:		Copyright © 08-10, Mikael Gustafsson
//
// Version:			0.9.0 february 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			0.9.0

//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//
// NOTE: a post build command copies the outputted dll to gui\bin\release and debug
//       does it work in MonoDevelop?
// 
//----------------------------------------------------------------------------- 

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
  

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;

namespace ds30Loader
{

	//-------------------------------------------------------------------------
	// Class: clsPortBase
	//-------------------------------------------------------------------------
	public class clsPortBase
    {
        public delegate void DataReceivedDelegate( object sender, EventArgs e );

        //---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
		protected int iBytesSent = 0;
        protected int iBytesReceived = 0;



 		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		public clsPortBase()
		{
        }// Constructor()


		//---------------------------------------------------------------------
		// Property: bytesSent
		//---------------------------------------------------------------------
		public int bytesSent
		{
			get {
				return iBytesSent;
			}
        }//Property: bytesSent 
  

		//---------------------------------------------------------------------
		// Property: bytesSentStr
		//---------------------------------------------------------------------
		public string bytesSentStr
		{
			get {
				if ( iBytesSent == 1 )
					return "1 byte";
				else if ( iBytesSent < 1024 )
					return iBytesSent.ToString() + " bytes";
				else
					return String.Format( "{0:0.#}", Convert.ToSingle(iBytesSent)/1024.0 ) + "kB";
			}
        }//Property: bytesSentStr       
        

        //---------------------------------------------------------------------
		// Property: bytesReceived
		//---------------------------------------------------------------------
		public int bytesReceived
		{
			get {
				return iBytesReceived;
			}
        }//Property: bytesReceived 
        
   
		//---------------------------------------------------------------------
		// Property: bytesReceivedStr
		//---------------------------------------------------------------------
		public string bytesReceivedStr
		{
			get {
				if ( iBytesReceived == 1 )
					return "1 byte";
				else if ( iBytesReceived < 1024 )
					return iBytesReceived.ToString() + " bytes";
				else
					return String.Format( "{0:0.#}", Convert.ToSingle(iBytesReceived)/1024.0 ) + "kB";
			}
        }//Property: bytesReceivedStr     
        
   
		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		public static bool supportsWindows { get { return false;} }
        
   
		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		public static bool supportsLinux { get { return false;} }
        
   
		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		public static bool supportsMac { get { return false;} }
		
				
		//---------------------------------------------------------------------
		// ResetCounters()
		//---------------------------------------------------------------------	
		public void ResetCounters() 
		{
			iBytesSent = iBytesReceived = 0;
		}// ResetCounters()	


	}// Class: clsPortBase
}
