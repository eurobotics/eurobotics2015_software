﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  

using System;
using System.Text;
using System.IO;
using GHelper;


namespace ds30Loader
{
    //-------------------------------------------------------------------------
	// Class: clsHexFileValidateEventArgs
	//-------------------------------------------------------------------------
	public class clsHexFileValidateEventArgs
	{
        //---------------------------------------------------------------------
        // Enum: EventType
        //---------------------------------------------------------------------
	    public enum EventType {
		    started,
		    failed,
            success
	    }//Enum: EventType
				
		//---------------------------------------------------------------------
		// Constructor
		//---------------------------------------------------------------------
		public clsHexFileValidateEventArgs( EventType peEventType, string pstrMessage, int piTabLevel )
		{
			eventType = peEventType;
			message = pstrMessage;
            tabLevel = piTabLevel;
		}//Constructor		


		//---------------------------------------------------------------------
		// Property: eventType
		//---------------------------------------------------------------------
		public EventType eventType { get; set; }
		
		
		//---------------------------------------------------------------------
		// Property: message
		//---------------------------------------------------------------------
		public string message { get; set; }
		

		//---------------------------------------------------------------------
		// Property: tabLevel
		//---------------------------------------------------------------------
		public int tabLevel { get; set; }
		
	}// Class: clsHexFileValidateEventArgs
		
}   