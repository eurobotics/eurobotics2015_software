﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  
using System.Xml;
using System.Xml.Serialization;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsDevice
	//-------------------------------------------------------------------------
    [XmlRoot("device")]
    //[XmlInclude(typeof(clsDevice))]
	public class clsDevice
	{
		//---------------------------------------------------------------------
		// Size suffixes
		//---------------------------------------------------------------------
        // P - pages
        // R - rows
		// W - words
		// Pcu - program counter units
		// B - bytes
		
			
		//---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
		private clsDeviceFamily objParentDeviceFamily = null;

		
		//---------------------------------------------------------------------
		// Constructor()
        // Description: regquired for serialization
		//---------------------------------------------------------------------	
		public clsDevice() 
		{
			/*objParentDeviceFamily = null;
			id = -1;
			nameWithoutFamily = string.Empty;
			flashSizePcu = -1;
			eepromSizeB = -1;
			configCount = -1;
            configCount = -1;

            iPageSizeR = -1;
            iRowSizeW = -1;*/
		}// Constructor()
		

		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public clsDevice( clsDeviceFamily pobjParentDeviceFamily, int piID, string pstrName, int piFlashSizePcu, int piEepromSizeB, int piConfigCount, bool pbHasCanModule ) 
		{
			objParentDeviceFamily = pobjParentDeviceFamily;
			id = piID;
			nameWithoutFamily = pstrName;
			flashSizePcu = piFlashSizePcu;
			eepromSizeB = piEepromSizeB;
            configCount = piConfigCount;
            hasCanModule = pbHasCanModule;

            iPageSizeR = 0;
            iRowSizeW = 0;
        }// Constructor()

		
		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public clsDevice( clsDeviceFamily pobjParentDeviceFamily, int piID, string pstrName, int piFlashSizePcu, int piEepromSizeB, int piConfigCount, bool pbHasCanModule, int piPageSizeR, int piRowSizeW ) 
		{
			objParentDeviceFamily = pobjParentDeviceFamily;
			id = piID;
			nameWithoutFamily = pstrName;
			flashSizePcu = piFlashSizePcu;
            eepromSizeB = piEepromSizeB;
            configCount = piConfigCount;
            hasCanModule = pbHasCanModule;

            iPageSizeR = piPageSizeR;
            iRowSizeW = piRowSizeW;
		}// Constructor()

        
        //---------------------------------------------------------------------
		// Serializable properties
		//---------------------------------------------------------------------
        public int id { get; set; }
		public string nameWithoutFamily { get; set; }
        public int flashSizePcu { get; set; }
		public int eepromSizeB { get; set; }
        public int configCount { get; set; }
        //public int testus { get; set; }
		public bool hasCanModule { get; set; }
		
        int iPageSizeR;
        public int pageSizeR
		{
			get {
                if ( iPageSizeR == 0 ) {
				    return objParentDeviceFamily.pageSizeR;
                } else {
                    return iPageSizeR;
                }
			} set {
                iPageSizeR = value;
            }
        }        
        int iRowSizeW;
		public int rowSizeW
		{
			get {
                if ( iRowSizeW == 0 ) {
				    return objParentDeviceFamily.rowSizeW;
                } else {
                    return iRowSizeW;
                }
			} set {
                iRowSizeW = value;
            }
        }


		//---------------------------------------------------------------------
		// Property: configWordSizeB
		// Description: size in instructions
		//---------------------------------------------------------------------
		public int configWordSizeB
		{
			get {
				return family.configWordSizeB;
			}
        }//Property: configWordSizeB
        
              	
   		//---------------------------------------------------------------------
		// Property: EepromStartAddress
		//---------------------------------------------------------------------
		public int eepromStartAddress
		{
			get {
				return  0x800000 - eepromSizeB;
			}
        }//Property: EepromStartAddress
             
              
 		//---------------------------------------------------------------------
		// Property: family
		//---------------------------------------------------------------------
		public clsDeviceFamily family
		{
			get {
				return objParentDeviceFamily;
			}
        }//Property: family  
        

		//---------------------------------------------------------------------
		// Property: flashSizeB
		//---------------------------------------------------------------------
		public int flashSizeB
		{
			get {
				return (flashSizePcu / family.pcuPerWord * family.flashWordSizeBits) / 8;
			}
        }//Property: flashSizeB


		//---------------------------------------------------------------------
		// Property: flashSizeP
		//---------------------------------------------------------------------
		public int flashSizeP
		{
			get {
				return flashSizePcu / family.pcuPerWord / rowSizeW / pageSizeR;
			}
        }//Property: flashSizeP
				
        
        //---------------------------------------------------------------------
		// Property: flashSizeR
		//---------------------------------------------------------------------
		public int flashSizeR
		{
			get {
				return flashSizePcu / family.pcuPerWord / rowSizeW;
			}
        }//Property: flashSizeR
        
        
        //---------------------------------------------------------------------
		// Property: hasPages
		//---------------------------------------------------------------------
		public bool hasPages
		{
			get {
				return objParentDeviceFamily.hasPages;
			}
        }//Property: hasPages

               	
		//---------------------------------------------------------------------
		// Property: name
		//---------------------------------------------------------------------
		public string name
		{
			get {
                if ( objParentDeviceFamily != null ) {
				    return objParentDeviceFamily.name + nameWithoutFamily;
                } else {
                    return nameWithoutFamily;
                }
			}
        }//Property: name 	
        
                		        
		//---------------------------------------------------------------------
		// SetParent()
		// Description:
		//---------------------------------------------------------------------
		public void SetParent( clsDeviceFamily pobjDeviceFamily )
		{
			objParentDeviceFamily = pobjDeviceFamily;
        }//Property: SetParent()
        
		        
		//---------------------------------------------------------------------
		// ToString()
		// Description:
		//---------------------------------------------------------------------
		override public string ToString()
		{
			return nameWithoutFamily;
        }//ToString()
        
	}// Class: clsDevice
}
