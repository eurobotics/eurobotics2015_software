﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  

using System;
using System.IO;
using GHelper;


namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsHex18FJ
	//-------------------------------------------------------------------------
	public class clsHex18FJ : clsHex
	{
		//---------------------------------------------------------------------
		// Size suffixes
		//---------------------------------------------------------------------
		// R - rows
		// W - words
		// P - program counter units
		// B3 - bytes		
	

		//---------------------------------------------------------------------
		// 
		//---------------------------------------------------------------------
		// 1 page = 16 rows = 512 words = 512 pcu = 1024 bytes


		//---------------------------------------------------------------------
		// Constants
		//---------------------------------------------------------------------
        public const int i18FJDefaultBlPlacementP = 2;  //page from the end
        public const int i18FJDefaultBlSizeP = 1;       //[pages]

        private const int iPageSizeR = 16;
        public const int iProgPageUsedBufferSize = 128;
		public const int iProgRowUsedBufferSize = iProgPageUsedBufferSize * iPageSizeR;
		public const int iProgMemBufferSize = iProgRowUsedBufferSize * 32 * 2;		
        
        public const int iEEWordsUsedBufferSize = 0;
        public const int iEEMemBufferSize = iEEWordsUsedBufferSize * 2;	
		
        public const int iConfigWordsUsedBufferSize = 0;
        public const int iConfigMemBufferSize = iConfigWordsUsedBufferSize * 2;

        //---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		public clsHex18FJ( string pstrFilename ) : base ( pstrFilename )
		{
            SizeBuffers( 
                iProgPageUsedBufferSize, iProgRowUsedBufferSize, iProgMemBufferSize, 
                iEEWordsUsedBufferSize, iEEMemBufferSize, 
                iConfigWordsUsedBufferSize, iConfigMemBufferSize 
            );

            iDefaultBlPlacementP = i18FJDefaultBlPlacementP;
            iDefaultBlSizeP = i18FJDefaultBlSizeP;
		}// Constructor()


        //---------------------------------------------------------------------
		// ParseHexFile()
		//---------------------------------------------------------------------
        override public void ParseHexFile( clsParseSettings pobjSettings, bool pbForce, int iTabLevel, ref bool pbResult )
		{ 
            //---------------------------------------------------------------------
		    // Allready parsed?
		    //---------------------------------------------------------------------
            pobjSettings.fileTimestamp = File.GetLastWriteTime( filename );
            if ( NeedsParsing(pobjSettings) == false && pbForce == false ) {
                pbResult = true;
                return; 
            }


            //
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.started, "Parsing hexfile...", iTabLevel++) );
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "File timestamp: " + pobjSettings.fileTimestamp.ToString(), iTabLevel) );

            //
            bIsParsed = false;
			bHasValidProgram = true;
			bHasValidEeprom = true;
			bHasValidConfigs = true;
			
		    
		    //---------------------------------------------------------------------
		    // Validate hex-file
		    //---------------------------------------------------------------------
            bool bValidateResult = false;
            ValidateHexFile( iTabLevel, ref bValidateResult );
            if ( bValidateResult == false ) {
                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.failed, "Parsing of hex-file aborted", iTabLevel++) );
                pbResult = false;
                return;
            }


            //--------------------------------------------------------------------------
            // 
            //--------------------------------------------------------------------------            
            InitBuffers( pobjSettings, iTabLevel );
            ParseHexFile8( pobjSettings, iTabLevel );
            CheckForBlOverwrite( pobjSettings, iTabLevel );
            CheckForGotoAt0( pobjSettings, iTabLevel );
            SwapGoto( pobjSettings, iTabLevel );   
            SetGotoToBl( pobjSettings, iTabLevel );                  
            AddChecksum( pobjSettings, iTabLevel );           
            CalcHexContent( pobjSettings, iTabLevel );    


            //--------------------------------------------------------------------------
            // Debug output
            //--------------------------------------------------------------------------
            if ( clsds30Loader.debugMode ) {
                OutputBlDebugInfo( pobjSettings, iTabLevel );
            }


			//--------------------------------------------------------------------------
			// Return
			//--------------------------------------------------------------------------
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.success, "Hex-file successfully parsed", iTabLevel) );            
            UpdateParsedSettings( pobjSettings );
			pbResult = true;
		}// ParseHexFile()
         
	}// Class: clsHex18FJ
}
