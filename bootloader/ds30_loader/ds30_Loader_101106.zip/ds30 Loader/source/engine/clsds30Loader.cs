﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader
//
// Copyright:		Copyright © 08-10, Mikael Gustafsson
//
// Version:			1.4.5 september 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			1.4.5 Bugfix: problem when switching between com- and can-ports when using "check for bl"
//                        Improvement: added handling for data thats not 4-byte aligned, 16-bit devices
//                  1.4.4 Improvement: correct handling of eeprom and config data for enhanced PIC16F 
//                        Improvement: handles unknown command response
//                        Improvement: lower cpu usage when waiting for data
//                  1.4.3 Bugfix: tried to write to the nonexisting page efter the last page on PIC18FJ devices when configs where present in the hex-file, reintroduced in 1.4.0
//                        Bugfix: baudrate for download was also used for device reset, introduced in 1.4.0
//                  1.4.2 Bugfix: won't crash when non hexfile/broken hex-fil is loaded
//                        Improvement: added support for 12 "new" PIC16F devices
//                        New feature: add checksum                        
//                  1.4.1 Bugfix: erase was not done on devices with pagesize=1 row
//                        Bugfix: porttype was not changed when checking for bl. after download
//                        New devices: dsPIC33FJ: 32GSxxx, 64GSxxx (8devices)
//                  1.4.0 New feature: port plugin system
//                        New feature: external device database
//                        Improvement: debug output performance  
//                        Improvement: address output in debug mode
//                        Improvement: PIC16 configs are detected now
//                        Improvement: code size reduced
//                        Improvement: user app can be located anywhere for PIC16
//                        Bugfix: timeout in GetResponse() was static at 2s
//                        Bugfix: PIC16F, invalid bootloader properties for 882,883, 884, 886, and 887
//                        Bugfix: PIC16F hex file parsing was messed up
//                        Bugfix: problem with byte data stored in flash on PIC18 was reintroduced in 1.3.3
//                  1.3.3 Bugfix: ds30 Loader engine tried to write to the nonexisting page efter the last page on PIC18FJ devices when configs where present in the hex-file
//                        New feature: auto baudrate detection
//                        New feature: tx echo verification
//                        New feature: PIC16F support
//                        Improvement: FindLoader() discards all leading null bytes
//                        Improvement: debug output
//                  1.3.2 Bugfix: serious bug that may cause overwrite of bootloader when using custom bootlooader
//                  1.3.1 Major code rework for WriteFlash() and ParseHex() to allow for easier maintenance
//                        Improved hex file validation
//                        Improved debug output
//                        Fixed broken dtr activation 
//                        Added activations in FindLoader()
//                        If row and page 0 is not found in hex file, goto at 0x00 is not written
//                        Now reports if unknown data is found in the hex file
//                  1.3.0 Added possibility to use custom bootloader placement and size
//                  1.2.5 Fixed broken dtr activation
//                        Improved pic18 hex parse
//                  1.2.4 Fixed dtr and rts reset, probably not working previously
//                        Improved info to user
//                        Minor non-functional code improvements in ParseHex()*.*
//                        Dtr and rts are brought low when port is closed
//                  1.2.3 Input buffer is cleared when resetting
//                        New reset method: command sequence
//                  1.2.2 More improvements in FindLoader() to reduce time from hello to download
//                        Added public versionstring
//                        Alot of non-functional code improvements
//                        PIC18FJ: fixed bug in WriteFlash()
//                        PIC18FJ: fixed incorrect flashsize for most devices
//                        PIC18FJ: fixed bootloader placement to 2nd last page, configs are stored in last page
//                  1.2.1 Added support for PIC18F 1.5 version
//                        Minor improvements in FindLoader()
//                  1.2.0 Added a settings class that's to be passed to Download()
//                        Reset device options added
//                        Activate device options added
//                        Added debug output for all devicefamilies/firmware versions
//                        Improvements in FindLoader()
//                        Fixed Eeprom and config write for dsPIC30F firmware >= 2.0
//                  1.1.1 Fixed dsPIC30F3011 device id, from 3 to 13
//                  1.1.0 Major code rework making it more independent and easier to integrate to 3rd party gui
//                  1.0.4 Some improvements in clsSerialPort
//                        GUI and actual bootloader code is now separated
//                        clsSerialport and debugtext moved to separate helper library
//                  1.0.3 Added recognition of new fw versions
//                  1.0.2 Added support for PIC18FJ
//                        Added debugmode
//                  1.0.1 Fixed incorrect bootloder size for PIC18 with rowsize <> 16 words
//                  1.0.0 Added support for PIC24H
//                        Split PIC24F to PIC24F and PIC24FJ
//                        Added support for PIC18F
//                        Fixed som copy/paste errors
//                  0.9.9 Fixed configs not found in dsPIC33
//                        Fixed dsPIC33F config write, byte instead of word
//                  0.9.9 Added support for PIC24F
//                        Fixed incorrect addresscheck in ParseHex()
//                  0.9.8 Eeprom buffer is now properly sized
//						  Optimized ParseHex()
//						  Added support for dsPIC33F
//					0.9.7 Added support for Eeprom programming
//						  Better error handling
//						  Added chek for config count
//					0.9.6 Fixed checksum calc for configs
//                  0.9.5 Fixed broken support for dsPIC30F3013
//                        Added support for 1010, 2020, 2023, 5016 and 6015
//					0.9.4 Fixed a bug that caused invalid goto on devices with flash size > ??
//					0.9.3 Fixed a bug in ParseHex()
//					0.9.2 Support for new 0.9.2 algoritm where only 96bytes are sent for each row instead of 128, ~25% faster
//					0.9.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  
using System;
using System.Threading;
using System.Windows.Forms;

using GHelper;

using System.Text.RegularExpressions;

namespace ds30Loader
{
    //-------------------------------------------------------------------------
	// Class: clsds30Loader
	//-------------------------------------------------------------------------
	static public class clsds30Loader
	{
		//---------------------------------------------------------------------
		// Size suffixes
		//---------------------------------------------------------------------
		// R - rows
		// W - words
		// P - program counter units
		// B3 - bytes				
		// B4 - bytes		

			
		//---------------------------------------------------------------------
		// Variables 
		//---------------------------------------------------------------------        
		static private bool bAbort = false;			//external abortsignal
        static private bool bDebugmode = false;
        static private IPort objPort = null;
        static private clsDownloadSettings objDownloadSettings = null;
        static private int iBytesWritten;


		//---------------------------------------------------------------------
		// Test-mode
		//--------------------------------------------------------------------- 
        static public bool testMode { get; set; }
        static public int testDeviceID { get; set; }
        static public Version testFwVer { get; set; }
        static public char testResponse { get; set; }


		//---------------------------------------------------------------------
		// Constants
		//---------------------------------------------------------------------        
        public const string strVersion = "1.4.5";

        public const byte cHello = 0xC1;
		public const char cOK = 'K';
		public const char cChecksumErr = 'N';
        public const char cVerifyErr = 'V';
        public const char cBlProtTrip = 'P';
        public const char cUnknownCommand = 'U';
		
		private const byte cCmdErasePage = 1;   //bit 0
		private const byte cCmdWriteRow = 2;    //bit 1
        private const byte cCmdWriteEEWord = 4; //bit 2
		private const byte cCmdWriteConfig = 8; //bit 3
        private const byte cCmdRead = 16;       //bit 4


		// 
		public delegate void DownloadingDelegate( object sender, clsDownloadingEventArgs e );
		static public event DownloadingDelegate Downloading;

        //---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		static clsds30Loader()
        {
            testMode = false;
		}//Constructor()


		//---------------------------------------------------------------------
		// Event: Downloading
		//---------------------------------------------------------------------
		static internal void OnDownloading( clsDownloadingEventArgs e )
		{
			// Event will be null if no client has hooked up a delegate to the event
			if ( Downloading != null ) {
				Downloading( null, e );
			}
		}//Event: FileValidated
		

 		//---------------------------------------------------------------------
		// Property: debugMode
		//---------------------------------------------------------------------
		static public bool debugMode
		{
			get {
				return bDebugmode;
			} set {
                 bDebugmode = value;
            }
        }//Property: family  	
	

		//---------------------------------------------------------------------
		// Abort()
		//---------------------------------------------------------------------
		static public void Abort()
		{
			bAbort = true;
		}// Abort()   
    

        //---------------------------------------------------------------------
		// Download()
		//---------------------------------------------------------------------
		static public void Download ( clsDevice pobjDevice, clsHex pobjHex, clsDownloadSettings pobjDownloadSettings, int iTabLevel, ref bool pbResult )
        {
            objDownloadSettings = pobjDownloadSettings;

            //-----------------------------------------------------------------
            // Increase process priority if polltime is low
            //-----------------------------------------------------------------
            if ( objDownloadSettings.polltime < 100 ) {
                try {
                    System.Diagnostics.Process.GetCurrentProcess().PriorityClass = System.Diagnostics.ProcessPriorityClass.AboveNormal;
                } catch {
                    clsDebugTextbox.OutputInfo( "Setting proccess priority failed." );
                }
            }

  
            //-----------------------------------------------------------------
            // Download
            //-----------------------------------------------------------------
            int iStartTime = Environment.TickCount;
            DownloadInternal( pobjDevice, pobjHex, 0, ref pbResult );
            int iEndTime = Environment.TickCount;


            //-----------------------------------------------------------------
            // Restore process priority
            //-----------------------------------------------------------------
            if ( objDownloadSettings.polltime < 100 ) {
                try {
                    System.Diagnostics.Process.GetCurrentProcess().PriorityClass = System.Diagnostics.ProcessPriorityClass.Normal;
                } catch {
                    clsDebugTextbox.OutputInfo( "Setting proccess priority failed." );
                }
            }


            //-----------------------------------------------------------------
            // Output some info
            //-----------------------------------------------------------------     
            if ( objPort != null ) {
                clsDebugTextbox.OutputInfo( 
                    "Tx " + objPort.bytesSentStr + " / " + 
                    "Rx " + objPort.bytesReceivedStr + " / " + 
                    String.Format( "{0:0.#}", Convert.ToSingle(iEndTime - iStartTime) / 1000.0 ) + "s"
                    , 1 
                );

                objPort.ResetCounters();
            }

            // 
            objPort = null;
        }//Download()

        
		//---------------------------------------------------------------------
		// DownloadInternal()
		//---------------------------------------------------------------------
		static private void DownloadInternal( clsDevice pobjDevice, clsHex pobjHex, int iTabLevel, ref bool pbResult )
		{
            //
            bool bWriteSuccess = false;
            bool bParseResult = false;

            pbResult = false;
            bAbort = false;
            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.started, "Initiating download...", iTabLevel++) );
            
            // Test-mode
            if ( testMode == true ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.warning, "Simulation mode is active", iTabLevel) );
            }


            //--------------------------------------------------------------------------
            // Create port object
            //--------------------------------------------------------------------------
            bool bPortCreateResult = false;
            PortCreate( ref bPortCreateResult, iTabLevel );
            if ( bPortCreateResult == false ) return;



			//--------------------------------------------------------------------------
			// Reset device
			//--------------------------------------------------------------------------
            bool bResetResult = false;
            clsds30Loader.ResetDevice( iTabLevel, ref bResetResult );
            if ( bResetResult == false ) {
                return;
            }

    			
		    //--------------------------------------------------------------------------
		    // Open port
		    //--------------------------------------------------------------------------
		    bool bOpenPortResult = false;
            PortOpen( objDownloadSettings.baudRate, true, ref bOpenPortResult, iTabLevel );
            if ( bOpenPortResult == false ) {
                return;
            }


            //--------------------------------------------------------------------------
			// Find loader
			//--------------------------------------------------------------------------
            bool bFindLoaderResult = false;
            Version verFw = null;
            FindLoaderInternal( pobjDevice, objDownloadSettings, ref verFw, iTabLevel, ref bFindLoaderResult );
            if ( bFindLoaderResult == false ) {
				PortClose( false, iTabLevel );
                return;
            }
            string strFwVer = verFw.ToString();
            		    

			//--------------------------------------------------------------------------
			// Init progressbar
			//--------------------------------------------------------------------------
            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.progressStarted, "", 0) );


			//--------------------------------------------------------------------------
			// Determine properties of the bootloader found
			//--------------------------------------------------------------------------
            int iBlSizeP;
            int iBlPlacementP;

            if ( objDownloadSettings.customBl == false ) {
                // Placement
                {
                    bool bGetBLPlacementResult = false;
                    iBlPlacementP = GetDefaultBlPlacementP( pobjDevice, verFw, ref bGetBLPlacementResult );
                    if ( bGetBLPlacementResult == false ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Unknown firmware version", iTabLevel) );
                        PortClose( false, iTabLevel );
                        return;
                    }
                    if ( debugMode == true ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Bootloader placement: " + iBlPlacementP.ToString(), iTabLevel) );
                    }
                }

                // Size
                {
                    bool bGetBLSizeResult = false;
                    iBlSizeP = GetDefaultBLSizeP( pobjDevice, verFw, ref bGetBLSizeResult );
                    if ( bGetBLSizeResult == false ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Unknown firmware version", iTabLevel) );
                        PortClose( false, iTabLevel );
                        return;
                    }
                    if ( debugMode == true ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Bootloader size: " + iBlSizeP.ToString(), iTabLevel) );
                    }

                }

			//--------------------------------------------------------------------------
			// Custom bootloader properties
			//--------------------------------------------------------------------------
            } else {
                iBlPlacementP = objDownloadSettings.customBlPlacementP;
                iBlSizeP = objDownloadSettings.customBlSizeP;
            }


			//--------------------------------------------------------------------------
			// Wait for response
			//--------------------------------------------------------------------------
            bool WaitBLReadyResponseResult = false;
            WaitBLReadyResponse( iTabLevel, ref WaitBLReadyResponseResult );
            if ( WaitBLReadyResponseResult == false ) {
                PortClose( false, iTabLevel );
                return;
            }


			//--------------------------------------------------------------------------
			// Setup parse settings
			//--------------------------------------------------------------------------
            clsParseSettings objParseSettings = new clsParseSettings( iBlSizeP, pobjDevice, objDownloadSettings.allowBlOverwrite, objDownloadSettings.noGoto, iBlPlacementP, objDownloadSettings.addChecksum );

            //--------------------------------------------------------------------------
            // PIC16F
            //--------------------------------------------------------------------------
            if ( pobjDevice.family.name == "PIC16F" ) {
                clsHex16F objHex16F = (clsHex16F)pobjHex;	
                
                // Parse				
                objHex16F.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {
                    PortClose( false, iTabLevel );
                    return;
				}

                bWriteSuccess = WriteFlash( pobjDevice, objHex16F, true, objDownloadSettings.writeProgram, objDownloadSettings.writeEeprom, objDownloadSettings.writeConfigs, iTabLevel );

            

            //--------------------------------------------------------------------------
            // PIC18F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC18F" ) {
                clsHex18F objHex18F = (clsHex18F)pobjHex;	
                
                // Parse				
                objHex18F.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {
                    PortClose( false, iTabLevel );
                    return;
				}

                // Write versions 1.5, mini version without eeprom and config write
                if ( strFwVer == "1.5.0" ) {                    
                    bWriteSuccess = WriteFlash( pobjDevice, objHex18F, true, objDownloadSettings.writeProgram, false, false, iTabLevel );
                
                // All other versions
                } else {
                    bWriteSuccess = WriteFlash( pobjDevice, objHex18F, true, objDownloadSettings.writeProgram, objDownloadSettings.writeEeprom, objDownloadSettings.writeConfigs, iTabLevel );
                }


            //--------------------------------------------------------------------------
            // PIC18FJ
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC18FJ" ) {
                clsHex18FJ objHex18FJ = (clsHex18FJ)pobjHex;	
                
                // Parse
                objHex18FJ.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {		
			        PortClose( false, iTabLevel );
                    return;
				}

                bWriteSuccess = WriteFlash( pobjDevice, objHex18FJ, true, objDownloadSettings.writeProgram, false, false, iTabLevel );
                

            //--------------------------------------------------------------------------
            // PIC24F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24F" ) {
                clsHex24F objHex24F = (clsHex24F)pobjHex;
                
                // Parse
                objHex24F.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {
                    PortClose( false, iTabLevel );
                    return;
				}

                bWriteSuccess = WriteFlash( pobjDevice, objHex24F, true, objDownloadSettings.writeProgram, objDownloadSettings.writeEeprom, objDownloadSettings.writeConfigs, iTabLevel );


            //--------------------------------------------------------------------------
            // PIC24FJ
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24FJ" ) {
                clsHex24FJ objHex24FJ = (clsHex24FJ)pobjHex;
                
                // Parse
                objHex24FJ.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {	
				    PortClose( false, iTabLevel );
                    return;
				}

                bWriteSuccess = WriteFlash( pobjDevice, objHex24FJ, true, objDownloadSettings.writeProgram, false, false, iTabLevel );

                
            //--------------------------------------------------------------------------
            // PIC24H
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24HJ" ) {
                clsHex24H objHex24H = (clsHex24H)pobjHex;	
                
                // Parse
                objHex24H.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {		
			        PortClose( false, iTabLevel );
                    return;
				}

                bWriteSuccess = WriteFlash( pobjDevice, objHex24H, true, objDownloadSettings.writeProgram, false, objDownloadSettings.writeConfigs, iTabLevel );


            //--------------------------------------------------------------------------
            // dsPIC30F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC30F" ) {
                clsHex30F objHex30F = (clsHex30F)pobjHex;
                
                // Parse
                objHex30F.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {					
                    PortClose( false, iTabLevel );
                    return;
				}

                // Write versions 0.9.4 - 1.0.1
                if ( 
					( strFwVer == "0.9.4" ) ||
					( strFwVer == "1.0.0" ) ||
                    ( strFwVer == "1.0.1" )
				) {
                    bWriteSuccess = WriteFlash( pobjDevice, objHex30F, false, objDownloadSettings.writeProgram, objDownloadSettings.writeEeprom, objDownloadSettings.writeConfigs, iTabLevel );
                
                // Versions 2.0.0 - 2.5.0
                } else {
                    bWriteSuccess = WriteFlash( pobjDevice, objHex30F, true, objDownloadSettings.writeProgram, objDownloadSettings.writeEeprom, objDownloadSettings.writeConfigs, iTabLevel );
                }

            
            //--------------------------------------------------------------------------
            // dsPIC33F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC33FJ" ) {
                clsHex33FJ objHex33F = (clsHex33FJ)pobjHex;	
                
                // Parse
                objHex33F.ParseHexFile( objParseSettings, false, iTabLevel, ref bParseResult );
                if ( bParseResult == false ) {					
                    PortClose( false, iTabLevel );
                    return;
				}

                bWriteSuccess = WriteFlash( pobjDevice, objHex33F, true, objDownloadSettings.writeProgram, false, objDownloadSettings.writeConfigs, iTabLevel );
            }
						
					    
			//--------------------------------------------------------------------------
			// Download completed
			//--------------------------------------------------------------------------
            PortClose( false, iTabLevel );

            if ( bWriteSuccess == true ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.completed, "Download finished", iTabLevel) );	                
            }

            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.progressEnded, "", 0) );
            pbResult = bWriteSuccess;
		}// DownloadInternal()
		
		
		//---------------------------------------------------------------------
		// FindLoader()
		//---------------------------------------------------------------------
		static public void FindLoader( clsDevice pobjDevice, clsDownloadSettings pobjDownloadSettings, ref Version pverFw, int iTabLevel, ref bool pbResult )
		{
            objDownloadSettings = pobjDownloadSettings;
            // Open port in non test mode
            if ( testMode == false ) {
                 bool bOpenPortResult = false;
                PortOpen( objDownloadSettings.baudRate, true, ref bOpenPortResult, iTabLevel );
                if ( bOpenPortResult == false || objPort.isOpen == false ) {
                    return;
                }
			}
            FindLoaderInternal( pobjDevice, pobjDownloadSettings, ref pverFw, iTabLevel, ref pbResult );			
            PortClose( true, iTabLevel );
		}// FindLoader()

        
        //---------------------------------------------------------------------
		// FindLoaderInternal()
		//---------------------------------------------------------------------
		static private void FindLoaderInternal( clsDevice pobjDevice, clsDownloadSettings pobjDownloadSettings, ref Version pverFw, int iTabLevel, ref bool pbResult )
		{
            int iDeviceIdFound = 0;
            bool bGetResponseResult = false;
            int iFWVerMaj = 9;
            int iFWVerMin = 9;
            int iFWVerRev = 9;
            bool bFirmwareVersionTimedOut = false;
            bool bUnexpectedData = false;

            pbResult = false;
            
            objDownloadSettings = pobjDownloadSettings;

            //-----------------------------------------------------------------
            // Test-mode
            //-----------------------------------------------------------------
            if ( testMode == true ) {
                iFWVerMaj = testFwVer.Major;
                iFWVerMin = testFwVer.Minor;
                iFWVerRev = testFwVer.Build;
                iDeviceIdFound = testDeviceID;
            
                
            //-----------------------------------------------------------------
            // Real-mode
            //-----------------------------------------------------------------
            } else {
                // Empty buffers prior to hello command in case there's some crap
                objPort.EmptyBuffers( true, false );


			    //--------------------------------------------------------------------------
			    // Auto baudrate
			    //--------------------------------------------------------------------------                    
		        if ( objDownloadSettings.autoBaudrate == true ) {
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Sending auto baudrate sync character ", iTabLevel) );
                    int iLastSend = Environment.TickCount - objDownloadSettings.polltime;
                    int iLastPoll = Environment.TickCount - objDownloadSettings.polltime;
                    int iStartTime = Environment.TickCount;                    
                    bool bOkReceived = false;
                    int iResponse;
                    bool bTimedOut = false;

                    do {  
                        // Check first byte, discard if null
                        if ( Environment.TickCount - iLastPoll >= objDownloadSettings.polltime/10) {     
                            iLastPoll = Environment.TickCount;                            
                            
                            if ( objPort.inBufferCount > 0 ) {
                                iResponse = GetResponse( ref bGetResponseResult );

                                if ( iResponse == 0 ) {
                                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "(discarded null byte) ", -1) );
                                } else if ( iResponse != cOK ) {
                                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "unknown response from auto baudrate detection(" + iResponse.ToString() + "), aborting", -1) );
                                    
                                    return;                           
                                } else {
                                    bOkReceived = true;
                                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
                                    break;
                                }                          
                            }
                        }

                        // Send sync char                    
                       if ( Environment.TickCount - iLastSend >= objDownloadSettings.polltime ) {                        
                            iLastSend = Environment.TickCount;
                            objPort.SendByte( 0x55 );
                            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, ". ", -1) );
                            // The sync char wont be echoed
                            objPort.EchoClearQueue();
                        }

                        // Check for timeout
                        bTimedOut = ( Environment.TickCount - iStartTime >= objDownloadSettings.timeout );

                        // Handle message queue
                        Application.DoEvents();                        
                        Thread.Sleep(1);
                    } while ( 
                        bAbort == false && 
                        bTimedOut == false &&
                        bOkReceived == false
                    );
                    
                    if ( bAbort == true  ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "aborted", -1) );
                        bAbort = false;
                        
                        return;
                    } else if ( bTimedOut == true ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "timed out", -1) );
                        
                        return;
                    }                                      
                }


			    //--------------------------------------------------------------------------
			    // Send hello to bootloader and receive device id
			    //--------------------------------------------------------------------------			    
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Searching for bl ", iTabLevel) );
                int iTimeDeviceIdReceived = 0;                
                {
                    int iLastSend = Environment.TickCount - objDownloadSettings.polltime;
                    int iLastPoll = Environment.TickCount - objDownloadSettings.polltime;
                    int iStartTime = Environment.TickCount;
                    bool bTimedOut = false;

                    do {
                        if ( Environment.TickCount - iLastPoll >= objDownloadSettings.polltime/10) {     
                            iLastPoll = Environment.TickCount;                            
                            
                            if ( objPort.inBufferCount > 0 ) {
                                iDeviceIdFound = GetResponse( ref bGetResponseResult );
   
                                if ( iDeviceIdFound == 0 ) {
                                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "(discarded null byte) ", -1) );
                                } else {
                                    iTimeDeviceIdReceived = Environment.TickCount;
                                    break;                            
                                }                          
                            }
                        }
                        
                        // Send hello                    
                       if ( Environment.TickCount - iLastSend >= objDownloadSettings.polltime ) {                        
                            objPort.EchoClearQueue();
                            iLastSend = Environment.TickCount;
                            objPort.SendByte( cHello );
                            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, ". ", -1) );
                        }

                        // Check for timeout
                        bTimedOut = ( Environment.TickCount - iStartTime >= objDownloadSettings.timeout );

                        // Handle message queue
                        Application.DoEvents();                        
                        Thread.Sleep(1);
                    } while ( 
                        bAbort == false && 
                        bTimedOut == false
                    );
                    
                    if ( bAbort == true  ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "aborted", -1) );
                        bAbort = false;
                        
                        return;
                    } else if ( bTimedOut == true ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "timed out", -1) );
                        
                        return;
                    }
                }

    			
			    //--------------------------------------------------------------------------
			    // Delay to receive firmware version if any
			    //--------------------------------------------------------------------------
                int iTime = 1 + 30000 / (int)objPort.baudrate;
                /*if ( objPort.portType == PortType.CAN ) {
                    iTime = 5000;
                }*/
                while ( Environment.TickCount - iTimeDeviceIdReceived < iTime && objPort.inBufferCount < 3 ) {            
                }
                if ( objPort.portType == PortType.CAN ) {
                    Thread.Sleep( 300 );
                }
    			

                //--------------------------------------------------------------------------
                // Firmware doesn´t send version, assume 0.9.4
                //--------------------------------------------------------------------------
                int iRcvVerMaj = 0, iRcvVerMinRev = 0;
                if ( objPort.inBufferCount == 1 ) {
                        iFWVerMaj = 0;
                        iFWVerMin = 9;
                        iFWVerRev = 4;
                
                    
                //--------------------------------------------------------------------------
                // Firmware that sends major and minor
                //--------------------------------------------------------------------------                
                } else if ( objPort.inBufferCount == 2 ) {
                    iRcvVerMaj = GetResponse( ref bGetResponseResult );
                    if ( bGetResponseResult == false ) {
                        
			            return;
                    } 
                    iFWVerMaj = ( (iRcvVerMaj & 0x70) >> 4 );
                    iFWVerMin = ( iRcvVerMaj & 0xF );
                    iFWVerRev = 0;


                //--------------------------------------------------------------------------
                // Firmware that sends major, minor and revision
                //--------------------------------------------------------------------------
                } else if ( objPort.inBufferCount == 3 ) {
                    iRcvVerMaj = GetResponse( ref bGetResponseResult );
                    if ( bGetResponseResult == false ) {
                        
			            return;
                    } 
                    iRcvVerMinRev = GetResponse( ref bGetResponseResult );
		            if ( bGetResponseResult == false ) {
                        
			            return;
		            }		    			
        
                    iFWVerMaj = ( iRcvVerMaj & 0x7F );
                    iFWVerMin = ( (iRcvVerMinRev & 0xF0) >> 4 );
                    iFWVerRev = ( iRcvVerMinRev & 0xF );


                //--------------------------------------------------------------------------
                // Firmware version timed out
                //--------------------------------------------------------------------------
                } else if ( objPort.inBufferCount == 0 ) {
                    bFirmwareVersionTimedOut = true;

                //--------------------------------------------------------------------------
                // Unexpected data received
                //--------------------------------------------------------------------------
                } else {
                    bUnexpectedData = true;
                }


                //--------------------------------------------------------------------------
                // PIC18 indicated by msb in fw ver major
                //--------------------------------------------------------------------------
                if ( (iRcvVerMaj & 0x80) > 0 ) {
                    iDeviceIdFound += 300;
                }
            }//Test-/real-mode


			//--------------------------------------------------------------------------
			// Version object
			//--------------------------------------------------------------------------
            pverFw = new Version( iFWVerMaj, iFWVerMin, iFWVerRev );

            
			//--------------------------------------------------------------------------
			// Find device from device id
			//--------------------------------------------------------------------------
			clsDevice objFoundDevice = clsDeviceDb.DeviceGet( iDeviceIdFound );

			
            //--------------------------------------------------------------------------
            // Invalid ID returned
            //--------------------------------------------------------------------------
			if ( objFoundDevice == null ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Found unknown device id(" + iDeviceIdFound.ToString() + ") fw ver. " + pverFw.ToString(), iTabLevel) );
                
				return;
			}


            //--------------------------------------------------------------------------
            // Bootloader found
            //--------------------------------------------------------------------------
            if ( bUnexpectedData == false && bFirmwareVersionTimedOut == false ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "Found " + objFoundDevice.name + " fw ver. " + pverFw.ToString(), iTabLevel) );
            } else if ( bFirmwareVersionTimedOut == true ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Firmware version timed out", iTabLevel) );
            } else if ( bUnexpectedData == true ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Unexpected data received, aborting", iTabLevel) );
            }
            
            //--------------------------------------------------------------------------
            // Different device found from choosen
            //--------------------------------------------------------------------------
            if ( objFoundDevice.id != pobjDevice.id ) {
                OnDownloading(new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Wrong pic detected(" + objFoundDevice.id.ToString() + ")/selected(" + pobjDevice.id.ToString() + "), aborting", iTabLevel));
                
				return;
			}

			pbResult = true;
		}// FindLoaderInternal()


        //---------------------------------------------------------------------
		// WaitBLReadyResponse()
		//---------------------------------------------------------------------
		static private void WaitBLReadyResponse( int iTabLevel, ref bool pbResult )
        {
            int iResponse = -1;
            pbResult = false;

            //--------------------------------------------------------------------------
			// Get bootloader ready response
			//--------------------------------------------------------------------------
            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Waiting for bootloader to be ready...", iTabLevel) );
			if ( testMode == false ) {
                bool bGetResponseResult = false;
                iResponse = GetResponse( ref bGetResponseResult);
                if ( bGetResponseResult == false ) {
				    return;
			    }
            } else {
                iResponse = cOK;
            }
		    
			if ( iResponse != cOK ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "unknown response (0x" + iResponse.ToString("X2") + ") aborting", -1) );
				return;
			}
            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
            pbResult = true;
        }//WaitBLReadyResponse()


        //---------------------------------------------------------------------
		// GetDefaultBlPlacementP()
		//---------------------------------------------------------------------
		static private int GetDefaultBlPlacementP( clsDevice pobjDevice, Version pverFw, ref bool pbResult )
		{
            pbResult = true;
            string strVersion = pverFw.ToString();


            //--------------------------------------------------------------------------
            // PIC16F
            //--------------------------------------------------------------------------
            if ( pobjDevice.family.name == "PIC16F" ) {
                // Firmware version 0.9.0 - 0.9.3
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.3" ) ||
                    ( strVersion == "0.9.4" ) ||
                    ( strVersion == "1.0.0" )
                ){
                    return 192 / (pobjDevice.pageSizeR * pobjDevice.rowSizeW);

                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}


            //--------------------------------------------------------------------------
            // PIC18F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC18F" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" )
                ){
                    return 4;
                
                } else if ( 
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "2.0.0" ) ||
                    ( strVersion == "2.0.1" ) 
                ){
                    return 5;
                
                }
                else if (
                    (strVersion == "2.0.2") ||
                    (strVersion == "2.0.3")
                ) {
                    return 7;
                 
                } else if ( 
                    ( strVersion == "1.5.0" ) ||
                    ( strVersion == "1.5.0" )
                ){
                    return 3;
    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}


            //--------------------------------------------------------------------------
            // PIC18FJ
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC18FJ" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.0.3" )
                ){
                    return 2;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	


            //--------------------------------------------------------------------------
            // PIC24F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24F" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.3" )
                ){
                    return 4;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	
   

            //--------------------------------------------------------------------------
            // PIC24FJ
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24FJ" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.0.3" ) ||
                    ( strVersion == "1.0.4" ) ||
                    ( strVersion == "1.1.0" )  ||
                    ( strVersion == "1.1.1" ) 
                ){
                    return 2;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	
            
                
            //--------------------------------------------------------------------------
            // PIC24H
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24HJ" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.1.0" )
                ){
                    return 1;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	


            //--------------------------------------------------------------------------
            // dsPIC30F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC30F" ) {
                if ( 
					( strVersion == "0.9.4" ) ||
					( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" )					
				) {
                    return 3;
                
                } else if ( 
                    ( strVersion == "2.0.0" ) ||
                    ( strVersion == "2.0.1" ) ||
                    ( strVersion == "2.0.2" ) ||
                    ( strVersion == "2.0.3" )
                ) {
					return 4;

                } else if ( 
                    ( strVersion == "2.0.4" )
                ) {
					return 5;

                } else if ( 
                    ( strVersion == "2.1.0" ) ||
                    ( strVersion == "2.5.0" ) 
                ) {
					return 7;

                } else if ( 
                    ( strVersion == "2.6.0" )
                ) {
					return 9;

                } else if ( 
                    ( strVersion == "3.0.0" )
                ) {
					return 8;

                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
                }

            
            //--------------------------------------------------------------------------
            // dsPIC33F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC33FJ" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.3" ) ||
                    ( strVersion == "0.9.4" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.0.3" ) ||
                    ( strVersion == "1.0.4" ) ||
                    ( strVersion == "1.1.0" ) ||
                    ( strVersion == "2.0.0" )
                ) {
                    return 1;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	
            }

            pbResult = false;
            return 0;           
        }// GetDefaultBlPlacement()


        //---------------------------------------------------------------------
		// GetDefaultBLSizeP()
		//---------------------------------------------------------------------
		static private int GetDefaultBLSizeP( clsDevice pobjDevice, Version pverFw, ref bool pbResult )
		{
            pbResult = true;
            string strVersion = pverFw.ToString();
            
            
            //--------------------------------------------------------------------------
            // PIC16F
            //--------------------------------------------------------------------------
            if ( pobjDevice.family.name == "PIC16F" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.3" ) ||
                    ( strVersion == "0.9.4" ) ||
                    ( strVersion == "1.0.0" )
                ){
                    return 192 / (pobjDevice.pageSizeR * pobjDevice.rowSizeW); 
    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}


			//--------------------------------------------------------------------------
            // PIC18F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC18F" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" )
                ){
                    return 4;
                
                } else if ( 
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "2.0.0" ) ||
                    ( strVersion == "2.0.1" )
                ){
                    return 5;
                 
                }
                else if (
                    (strVersion == "2.0.2") ||
                    (strVersion == "2.0.3")
                ) {
                    return 7;
                
                } else if ( 
                    ( strVersion == "1.5.0" ) ||
                    ( strVersion == "1.5.0" )
                ){
                    return 3;
    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}


            //--------------------------------------------------------------------------
            // PIC18FJ
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC18FJ" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.0.3" )
                ){
                    return 1;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	


            //--------------------------------------------------------------------------
            // PIC24F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24F" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.3" )
                ){
                    return 4;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	
   

            //--------------------------------------------------------------------------
            // PIC24FJ
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24FJ" ) {
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.0.3" ) ||
                    ( strVersion == "1.0.4" ) ||
                    ( strVersion == "1.1.0" ) ||
                    ( strVersion == "1.1.1" ) 
                ){
                    return 1;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	
            
                
            //--------------------------------------------------------------------------
            // PIC24H
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "PIC24HJ" ) {
                // Firmware version 0.9.0 - 1.0.1 
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.1.0" ) 
                ){
                    return 1;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	


            //--------------------------------------------------------------------------
            // dsPIC30F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC30F" ) {
                // Firmware version 0.9.4 - 1.0.1
                if ( 
					( strVersion == "0.9.4" ) ||
					( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" )					
				) {
                    return 3;
                
                // Firmware version 2.0.0 - 2.0.2
                } else if ( 
                    ( strVersion == "2.0.0" ) ||
                    ( strVersion == "2.0.1" ) ||
                    ( strVersion == "2.0.2" ) ||
                    ( strVersion == "2.0.3" )
                ) {
					return 4;
                
                // Firmware version 2.0.4 - 2.0.4
                } else if ( 
                    ( strVersion == "2.0.4" )
                ) {
					return 5;

                // Firmware version 2.5.0 - 2.5.0
                } else if ( 
                    ( strVersion == "2.1.0" ) ||
                    ( strVersion == "2.5.0" )
                ) {
					return 7;

                // Firmware version 2.6.0
                } else if ( 
                    ( strVersion == "2.6.0" )
                ) {
					return 9;

                } else if ( 
                    ( strVersion == "3.0.0" )
                ) {
					return 8;

                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
                }

            
            //--------------------------------------------------------------------------
            // dsPIC33F
            //--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC33FJ" ) {
                // Firmware version 0.9.0 - 1.0.1
                if ( 
                    ( strVersion == "0.9.0" ) ||
                    ( strVersion == "0.9.1" ) ||
                    ( strVersion == "0.9.2" ) ||
                    ( strVersion == "0.9.3" ) ||
                    ( strVersion == "0.9.4" ) ||
                    ( strVersion == "1.0.0" ) ||
                    ( strVersion == "1.0.1" ) ||
                    ( strVersion == "1.0.2" ) ||
                    ( strVersion == "1.0.3" ) ||
                    ( strVersion == "1.0.4" ) ||
                    ( strVersion == "1.1.0" ) ||
                    ( strVersion == "2.0.0" )
                ) {
                    return 1;
                    
                // Unknown firmware version
                } else {
					pbResult = false;
                    return 0;
				}	
            }

            pbResult = false;
            return 0;
		}// GetDefaultBLSizeP()
		
		
		//---------------------------------------------------------------------
		// GetResponse()
		//---------------------------------------------------------------------
		static public int GetResponse( ref bool pbResult )
		{
            int iResponse = -1;
            pbResult = false;

            // Test-mode
            if ( testMode == true ) {
                pbResult = true;
                return testResponse;
            }

            //
			int iStartTime = System.Environment.TickCount;
		    while ( objPort.inBufferCount < 1 && System.Environment.TickCount - iStartTime < objDownloadSettings.timeout && bAbort == false ) {
				Application.DoEvents();
                Thread.Sleep( 1 );
			}

            // Abort
            if ( bAbort == true ) {
                return -1;
            }	
		
			// Timeout
			if ( objPort.inBufferCount < 1 ) {     
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "response timed out", -1) );
				return -1;
			}			
		    
			objPort.ReadByte( ref iResponse );
			pbResult = true;
            return iResponse;
		}// GetResponse()


        //---------------------------------------------------------------------
		// ParseCanCommand()
		//---------------------------------------------------------------------
        static public uint[] ParseCanCommand(String str, ref bool bResult)
        {
            Match m;
            GroupCollection gc;
            CaptureCollection cc;
            uint[] iBytes = new uint[9];
            Regex Pattern = new Regex("^(?<ID>[0-9a-fA-F]{1,3})(?<DATA>[ ]{1}[0-9a-fA-F]{1,2}){1,8}$");

            bResult = Pattern.IsMatch(str);

            if (bResult)
            {
                m = Pattern.Match(str);
                gc = m.Groups;

                cc = gc["ID"].Captures;
                iBytes[0] = uint.Parse(cc[0].ToString(), System.Globalization.NumberStyles.HexNumber);
                if ( iBytes[0] > 0x7FF )
                {
                    bResult = false;
                }

                cc = gc["DATA"].Captures;
                // Loop through each capture in group.
                for (int i = 0; i < cc.Count; i++)
                {
                    iBytes[i + 1] = byte.Parse(cc[i].ToString(), System.Globalization.NumberStyles.HexNumber);
                }
                Array.Resize(ref iBytes, cc.Count + 1);
                return iBytes;
            }
            return null;
        }// ParseCanCommand()     


        //---------------------------------------------------------------------
		// PortCreate()
		//---------------------------------------------------------------------
		static private void PortCreate( ref bool pbResult, int piTabLevel )
		{
            pbResult = false;

            // Don't recreate port if not necesery
            if (objPort != null ) {
                if ( objDownloadSettings.portName.Contains(objPort.portName) ) { // not using == because serial port can be human readable from gui
                    pbResult = true;
                    return;
                } else if ( objPort.isOpen ) {
                    objPort.Close();
                }

            }

            objPort = clsds30LoaderPorts.GetPortObjectFromName( objDownloadSettings.portName );
            if ( objPort == null ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Unknown port: " + objDownloadSettings.portName, piTabLevel) );                  
                return;
            }
            
            pbResult = true;
            return;
		}// PortCreate()


        //---------------------------------------------------------------------
		// PortClose()
		//---------------------------------------------------------------------
		static private void PortClose( bool pbResetCounters, int piTabLevel )
		{
            if ( debugMode == true ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Closing port", piTabLevel) );  
            }
            objPort.dtrEnable = false;
            objPort.rtsEnable = false;
            objPort.Close();
            if ( pbResetCounters == true ) {
                objPort.ResetCounters();
            }
		}// PortClose()


		//---------------------------------------------------------------------
		// PortOpen()
        // Condition: PortCreate() has been called with without error
		//---------------------------------------------------------------------
		static private void PortOpen( int piBaudRate, bool pbDoActivation, ref bool pbResult, int piTabLevel )
		{
            pbResult = false;


            //--------------------------------------------------------------------------
            // Create port object
            //--------------------------------------------------------------------------
            bool bPortCreateResult = false;
            PortCreate( ref bPortCreateResult, piTabLevel );
            if ( bPortCreateResult == false ) return;
            

            //
            if ( debugMode == true ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Opening port " + objDownloadSettings.portName + "@" + piBaudRate.ToString(), piTabLevel) );  
            }

            // Activation
            if ( pbDoActivation == true ) {
                // Dtr activation
                if ( objDownloadSettings.activateDtr == true ) {
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Bringing dtr high...", piTabLevel) );  
                    try {
			            objPort.dtrEnable = true;
                    } catch {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "failed", -1) );  
                        return;
                    }
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );  
                } else {
                    objPort.dtrEnable = false;
                }

                // Rts activation
                if ( objDownloadSettings.activateRts == true ) {
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Bringing rts high...", piTabLevel) );  
                    try {
			            objPort.rtsEnable = true;
                    } catch {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "failed", -1) );  
                        return;
                    }
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );  
                } else {
                    objPort.rtsEnable = false;
                }
            }

            // Return if port is allready opened with same baud/bitrate
            if ( objPort.isOpen ) {
                if ( objPort.baudrate == piBaudRate ) {
                    pbResult = true;
                    return;
                } else {
                    objPort.Close();
                }
            }

            objPort.portName = objDownloadSettings.portName;
            objPort.baudrate = piBaudRate;

            if ( objPort.portType == PortType.CAN ) {
                ((IPortCAN)objPort).remoteID = objDownloadSettings.remoteId;
                ((IPortCAN)objPort).localID = objDownloadSettings.localId;
            }
            objPort.echoVerification = objDownloadSettings.echoVerification;
            
            try {
                objPort.Open();
            } catch {
            }

            if ( objPort.isOpen == false ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "Failed to open port " + objPort.portName, piTabLevel) );  
            }

            pbResult = objPort.isOpen;
		}// PortOpen()


		//---------------------------------------------------------------------
		// ProcessWriteResponse()
		//---------------------------------------------------------------------
		static private void ProcessWriteResponse( ref int piRetries, int piTabLevel, string pstrWriteType, ref bool pbRetry, ref bool pbResult )
		{
            int iResponse = -1;
            pbResult = false;

            // Get response
            bool bGetResponseResult = false;
            iResponse = GetResponse( ref bGetResponseResult );
            if ( bGetResponseResult == false ) {
                return;
            }

            // Check response
		    if ( iResponse != cOK ) {
			    if ( ++piRetries == 3 ) {
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "download failed", -1) );
				    return;
			    } else {
				    if ( iResponse == cChecksumErr ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "checksum error," + piRetries.ToString() + " try", -1) );
                        pbRetry = true;
                    } else if ( iResponse == cVerifyErr ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "verification error," + piRetries.ToString() + " try", -1) );
                        pbRetry = true;
                    } else if ( iResponse == cBlProtTrip ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "bl protection tripped", -1) );
                        pbRetry = false;
                        return;
                    } else if ( iResponse == cUnknownCommand ) {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "firmware responded unknown command", -1) );
                        pbRetry = false;
                        return;
                    } else {
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "unknown response 0x" + iResponse.ToString("X2") + ", " + piRetries.ToString() + " try", -1) );
                        pbRetry = true;
                    }
                    
                    if ( debugMode == false ) {
				        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing " + pstrWriteType + "...", piTabLevel) );
                    }
			    }
		    } else {
                pbRetry = false;
            }

            pbResult = true;
		}// ProcessWriteResponse()


		//---------------------------------------------------------------------
		// ResetDevice()
		//---------------------------------------------------------------------
		static private void ResetDevice( int iTabLevel, ref bool pbResult )
		{
            pbResult = false;

            // Get port object
            //objPort = clsds30LoaderPorts.GetPortObjectFromName(objDownloadSettings.portName);

            
            //--------------------------------------------------------------------------
            // Create port object / close port
            //--------------------------------------------------------------------------
            /*bool bPortCreateResult = false;
            PortCreate( ref bPortCreateResult, iTabLevel );
            if ( bPortCreateResult == false ) return;
            if ( objPort.isOpen ) objPort.Close();*/


            //--------------------------------------------------------------------------
		    // Reset - command
		    //--------------------------------------------------------------------------
            if ( objDownloadSettings.resetCommand == true ) {
                // Remember port settings
                int iOldBaudrate = objDownloadSettings.baudRate;
                uint uiOldId = objDownloadSettings.remoteId;
                if ( objPort != null ) {
                    iOldBaudrate = objPort.baudrate;
                    uiOldId = objDownloadSettings.remoteId;
                }

                // Parse resetcommand
                bool bSplitResult = false;
                byte[] bBytes = new byte[8];                
                int iDlc = 0;

                
                switch ( objPort.portType ) {
                    case  PortType.CAN:
                        uint[] iBytes = ParseCanCommand(objDownloadSettings.resetCommandSequence, ref bSplitResult);
                        if (bSplitResult == false) {
                            clsDebugTextbox.OutputError( "Failed to parse CAN reset command", iTabLevel );
                            return;
                        }
                        iDlc = iBytes.Length-1;
                        for (int iTer=0; iTer < iDlc; iTer++)
                        {
                            bBytes[iTer] = (byte)iBytes[iTer+1];
                        }
                        objDownloadSettings.remoteId = iBytes[0];
                        break;

                    case PortType.Serial:
                        bBytes = GHelper.clsMisc.Split8bitHexStringToBytes( objDownloadSettings.resetCommandSequence, ref bSplitResult );
                        break;

                    default:
                        clsDebugTextbox.OutputError( "Port type not implemented in ResetDevice()", iTabLevel );
                        break;
                }

                if ( bSplitResult == false ) {
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "couldn't parse reset command sequence", -1) );
                    return;
                }

                // Open port 
                bool bOpenPortResult = false;
                PortOpen( objDownloadSettings.resetBaudrate, false, ref bOpenPortResult, iTabLevel );  
                if ( bOpenPortResult == false ) {
                    return;
                }
                
                // Send reset command and close port         
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Sending reset command...", iTabLevel) );  
                if ( objPort.portType == PortType.CAN ) {
                    ((IPortCAN)objPort).SendBytes( ref bBytes, 0, iDlc, iDlc );
                } else { 
                    objPort.SendBytes( ref bBytes, 0, bBytes.Length );
                }
                while ( objPort.outBufferCount > 0 );
                objPort.EmptyBuffers( true, false );
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
                PortClose( false, iTabLevel );
                

                // Restore baudrate & id
                objPort.baudrate = iOldBaudrate;
                objDownloadSettings.remoteId = uiOldId;

                SleepResponsive( objDownloadSettings.resetTime );


		    //--------------------------------------------------------------------------
		    // Reset - dtr
		    //--------------------------------------------------------------------------            
            } else if ( objDownloadSettings.resetDtr == true ) {
                // Notify user
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Resetting by dtr...", iTabLevel) );
                // Open port
                bool bPortOpenResult = false;
                PortOpen( objDownloadSettings.baudRate, false, ref bPortOpenResult, iTabLevel );
                if ( bPortOpenResult == false ) {
                    return;
                }
                // Do reset
                objPort.dtrEnable = true;
                SleepResponsive( objDownloadSettings.resetTime );
                objPort.dtrEnable = false;
                // Close port
                PortClose( false, iTabLevel );
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );


		    //--------------------------------------------------------------------------
		    // Reset - rts
		    //--------------------------------------------------------------------------           
            } else if ( objDownloadSettings.resetRts == true ) {
                // Notify user
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Resetting by rts...", iTabLevel) );
                // Open port
                bool bPortOpenResult = false;
                PortOpen( objDownloadSettings.baudRate, false, ref bPortOpenResult, iTabLevel );
                if ( bPortOpenResult == false ) {
                    return;
                }                
                // Do reset
                objPort.rtsEnable = true;
                SleepResponsive( objDownloadSettings.resetTime );
                objPort.rtsEnable = false;
                // Close port
                PortClose( false, iTabLevel );
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
            }

            pbResult = true;
        }//ResetDevice()


        //---------------------------------------------------------------------
		// SleepResponsive()
		//---------------------------------------------------------------------
		static private void SleepResponsive( int piTimeMs )
		{
            int iStartTime = Environment.TickCount;
            while ( Environment.TickCount - iStartTime <= piTimeMs ) {
                Application.DoEvents();                
                Thread.Sleep( 1 );
            }
        }//SleepResponsive()

        
        //---------------------------------------------------------------------
        // WriteConfigs()
        //---------------------------------------------------------------------
        static private bool WriteConfigs( clsDevice pobjDevice, clsHex pobjHex, int iBytesToWrite, bool pbSendCommand, int iTabLevel)
        {
            int     iChecksum;
            int     iSum;
            int     iAddrP;
            int     iRetries;
            byte[]  bBuffer = new byte[256];
            int     iBufferIndx;
            byte    bAddrU, bAddrH, bAddrL, bSize, bProg;
            bool    bRetry = false; 
            bool    bProcessWriteResponseResult = false;

			if ( clsds30Loader.debugMode == false) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing configs...", iTabLevel) );
            }


            //--------------------------------------------------------------------------
			// PIC18F PIC18FJ
			//--------------------------------------------------------------------------
            if ( pobjDevice.family.name == "PIC18F" || pobjDevice.family.name == "PIC18FJ" ) {							
                for ( int iConfig = 0; iConfig < pobjHex.bConfigWordUsed.Length; iConfig++ ) {
					if ( pobjHex.bConfigWordUsed[iConfig] == true ) {
                        iRetries = 0;
						do {
                            if ( clsds30Loader.debugMode ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing config byte " + iConfig.ToString() + " (0x" + pobjHex.iConfigMem[iConfig].ToString("X2") + ")...", iTabLevel) );
                            }

						    iBufferIndx = 0;
						    iSum = 0;						
						
						    // Calculate
						    iAddrP = 0x300000 + iConfig;               				//24-bit address in memory to write to
						    bAddrU = Convert.ToByte( (iAddrP & 0xff0000) >> 16 );	//address upper byte			               
						    bAddrH = Convert.ToByte( (iAddrP & 0x00ff00) >> 8 );	//address high byte
						    bAddrL = Convert.ToByte( (iAddrP & 0x0000ff) );			//address low byte
						    bSize = Convert.ToByte( 1 + 1/*checksum*/ );
							
						    //
						    bBuffer[ iBufferIndx++ ] = bAddrU;	iSum += bAddrU;
						    bBuffer[ iBufferIndx++ ] = bAddrH;	iSum += bAddrH;
						    bBuffer[ iBufferIndx++ ] = bAddrL;	iSum += bAddrL;
						    bBuffer[ iBufferIndx++ ] = cCmdWriteConfig;iSum += cCmdWriteConfig;
						    bBuffer[ iBufferIndx++ ] = bSize;	iSum += bSize;	
		                    
						    // Buffer config word
						    bProg = Convert.ToByte( pobjHex.iConfigMem[ iConfig ] );
						    bBuffer[ iBufferIndx++ ] = bProg; iSum = (iSum + bProg) % 256;	
							
						    // Calculate checksum and add to buffer
						    iSum %= 256;
						    iChecksum = Convert.ToInt16( (256 - iSum) % 256 );
						    bBuffer[ iBufferIndx++ ] = Convert.ToByte(iChecksum);
							
						    // Send row+checksum
						    objPort.SendBytes( ref bBuffer, 0, iBufferIndx );
		                    
						    // Get response, checksum ok
                            ProcessWriteResponse( ref iRetries, iTabLevel, "config", ref bRetry, ref bProcessWriteResponseResult );
                            if ( bProcessWriteResponseResult == false ) {
                                return false;
                            } else if ( clsds30Loader.debugMode == true && bRetry == false ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );				
                            }

                            Application.DoEvents();
						} while ( bRetry == true && bAbort == false );
		                
						//
						if ( bAbort == true ) {
							OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "aborted by user", -1) );
							return false;
						}
						
                        //
						iBytesWritten += 1;
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.progress, "", (100 * iBytesWritten) / iBytesToWrite ) );
					}//if ( bConfigUsed[iIter] == true ) {
					
				}//for ( iIter = 0;  iIter < iConfigUsedBufferSize; iIter++ ) { 
				
                if ( clsds30Loader.debugMode == false ) {
				    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );				
                }


            //--------------------------------------------------------------------------
			// dsPIC30F
			//--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC30F" ) {							
			    for ( int iConfig = 0;  iConfig < clsHex30F.iConfigWordsUsedBufferSize; iConfig++ ) {
				    if ( pobjHex.bConfigWordUsed[iConfig] == true ) {
					    iRetries = 0;
    					
					    do {
                            if ( clsds30Loader.debugMode == true ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing config word " + iConfig.ToString() + " (0x" + ((pobjHex.iConfigMem[iConfig * 2+1]<<8)+pobjHex.iConfigMem[iConfig * 2]).ToString("X4") + ")...", iTabLevel) );
                            }

						    iBufferIndx = 0;
						    iSum = 0;						
    					
						    // Calculate
						    iAddrP = 0xF80000 + iConfig * 2;						//24-bit address in memory to write to
					        bAddrU = Convert.ToByte( (iAddrP & 0xff0000) >> 16 );	//address upper byte			               
					        bAddrH = Convert.ToByte( (iAddrP & 0x00ff00) >> 8 );	//address high byte
					        bAddrL = Convert.ToByte( (iAddrP & 0x0000ff) );			//address low byte                            
						    bSize = Convert.ToByte( 2 + 1/*checksum*/ );
    						
						    //
						    bBuffer[ iBufferIndx++ ] = bAddrU;	iSum += bAddrU;
						    bBuffer[ iBufferIndx++ ] = bAddrH;	iSum += bAddrH;
						    bBuffer[ iBufferIndx++ ] = bAddrL;	iSum += bAddrL;
                            if ( pbSendCommand ) bBuffer[ iBufferIndx++ ] = cCmdWriteConfig; iSum += cCmdWriteConfig;
						    bBuffer[ iBufferIndx++ ] = bSize;	iSum += bSize;	
    	                    
						    // Buffer config word
						    for ( int iIter = 0; iIter < 2; iIter++ ) {
							    bProg = Convert.ToByte( pobjHex.iConfigMem[ iConfig * 2 + iIter ] );
							    bBuffer[ iBufferIndx++ ] = bProg; iSum = (iSum + bProg) % 256;	
						    }
    						
						    // Calculate checksum and add to buffer
						    iSum %= 256;
						    iChecksum = Convert.ToInt16( (256 - iSum) % 256 );
						    bBuffer[ iBufferIndx++ ] = Convert.ToByte(iChecksum);
    						
						    // Send row+checksum
						    objPort.SendBytes( ref bBuffer, 0, iBufferIndx );
    	                    
						    // Get response, checksum ok
                            ProcessWriteResponse( ref iRetries, iTabLevel, "configs", ref bRetry, ref bProcessWriteResponseResult );
                            if ( bProcessWriteResponseResult == false ) {
                                return false;
                            } else if ( clsds30Loader.debugMode == true && bRetry == false ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
                            }

                            //
                            Application.DoEvents();
					    } while ( bRetry == true && bAbort == false );
    	                
					    //
					    if ( bAbort == true ) {
						    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "aborted by user", -1) );
						    return false;
					    }
    					
                        //
					    iBytesWritten += 2;
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.progress, "", (100 * iBytesWritten) / iBytesToWrite ) );
				    }//if ( bConfigWordUsed[iIter] == true ) {
    				
			    }//for ( iIter = 0;  iIter < iConfigUsedBufferSize; iIter++ ) { 
    			
                if ( clsds30Loader.debugMode == false ) {
			        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );				
                }


            //--------------------------------------------------------------------------
			// PIC24H & dsPIC33FJ
			//--------------------------------------------------------------------------
            } else if ( pobjDevice.family.name == "dsPIC33FJ" || pobjDevice.family.name == "PIC24HJ" ) {				
				for ( int iConfig = 0; iConfig < clsHex33FJ.iConfigWordsUsedBufferSize; iConfig++ ) {
					if ( pobjHex.bConfigWordUsed[iConfig] == true ) {
                        iRetries = 0;
						do {
                            for ( int iByte = 0; iByte < 2; iByte++ ) {
                                if ( clsds30Loader.debugMode ) {
                                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing config word " + iConfig.ToString() + " byte " + iByte.ToString() + "(0x" + pobjHex.iConfigMem[iConfig * 2 + iByte].ToString("X") + ")...", iTabLevel) );
                                }

                                iBufferIndx = 0;
							    iSum = 0;						
    						
							    // Calculate
							    iAddrP = 0xF80000 + iConfig * 2 + iByte;				//24-bit address in memory to write to
							    bAddrU = Convert.ToByte( (iAddrP & 0xff0000) >> 16 );	//address upper byte			               
							    bAddrH = Convert.ToByte( (iAddrP & 0x00ff00) >> 8 );	//address high byte
							    bAddrL = Convert.ToByte( (iAddrP & 0x0000ff) );			//address low byte
							    bSize = Convert.ToByte( 1 + 1/*checksum*/ );
    							
							    //
							    bBuffer[ iBufferIndx++ ] = bAddrU;	iSum += bAddrU;
							    bBuffer[ iBufferIndx++ ] = bAddrH;	iSum += bAddrH;
							    bBuffer[ iBufferIndx++ ] = bAddrL;	iSum += bAddrL;
							    if ( pbSendCommand ) bBuffer[ iBufferIndx++ ] = cCmdWriteConfig;iSum += cCmdWriteConfig;
							    bBuffer[ iBufferIndx++ ] = bSize;	iSum += bSize;	
    		                    
							    // Buffer config byte
							    bProg = Convert.ToByte( pobjHex.iConfigMem[ iConfig * 2 + iByte ] );
							    bBuffer[ iBufferIndx++ ] = bProg; iSum = (iSum + bProg) % 256;	
    							
							    // Calculate checksum and add to buffer
							    iSum %= 256;
							    iChecksum = Convert.ToInt16( (256 - iSum) % 256 );
							    bBuffer[ iBufferIndx++ ] = Convert.ToByte(iChecksum);
    							
							    // Send row+checksum
							    objPort.SendBytes( ref bBuffer, 0, iBufferIndx );
    		                    
							    // Get response, checksum ok
                                ProcessWriteResponse( ref iRetries, iTabLevel, "configs", ref bRetry, ref bProcessWriteResponseResult );
                                if ( bProcessWriteResponseResult == false ) {
                                    return false;
                                } else if ( clsds30Loader.debugMode == true && bRetry == false ) {
                                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
                                }
                            }
                            Application.DoEvents();
						} while ( bRetry == true && bAbort == false );
		                
						//
						if ( bAbort == true ) {
							OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "aborted by user", -1) );
							return false;
						}
						
                        //
						iBytesWritten += 2;
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.progress, "", (100 * iBytesWritten) / iBytesToWrite ) );
					}//if ( bConfigUsed[iIter] == true ) {
					
				}//for ( iIter = 0;  iIter < iConfigUsedBufferSize; iIter++ ) { 
				
                if ( clsds30Loader.debugMode == false ) {
				    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );				
                }
			}

            return true;
        }//WriteConfigs()


        //---------------------------------------------------------------------
        // WriteEeprom()
        //---------------------------------------------------------------------
        static private bool WriteEeprom( clsDevice pobjDevice, clsHex pobjHex, int iBytesToWrite, bool pbSendCommand, int iTabLevel)
        {
            int     iChecksum;
            int     iSum;
            int     iAddrP;
            int     iRetries;
            byte[]  bBuffer = new byte[256];
            int     iBufferIndx;
            byte    bAddrU, bAddrH, bAddrL, bSize, bProg;
            bool    bRetry = false;                        
            bool    bProcessWriteResponseResult = false;


            if ( clsds30Loader.debugMode == false ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing eeprom...", iTabLevel) );
            }
			
		    for ( int iEepromWord = 0; iEepromWord < pobjDevice.eepromSizeB / pobjDevice.family.eepromWordSizeB; iEepromWord++ ) {					
			    if ( pobjHex.bEEWordUsed[iEepromWord] == true ) {
					iRetries = 0;
					
				    do {
                        if ( clsds30Loader.debugMode ) {
                            string strEepromWordValue = string.Empty;
                            if ( pobjDevice.family.eepromWordSizeB == 1 ) {
                                strEepromWordValue = pobjHex.iEEMem[iEepromWord].ToString( "X2" );
                            } else if ( pobjDevice.family.eepromWordSizeB == 2 ) {
                                strEepromWordValue = ((pobjHex.iEEMem[iEepromWord*2+1]<<8)+pobjHex.iEEMem[iEepromWord * 2]).ToString( "X4" ) ;                           
                            }
                            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing eeprom word " + iEepromWord.ToString() + " (0x" + strEepromWordValue + ")...", iTabLevel) );
                        }

					    iBufferIndx = 0;
					    iSum = 0;
		                
	                    // Calculate
	                    iAddrP = pobjDevice.eepromStartAddress + iEepromWord * pobjDevice.family.eepromWordSizeB;		//24-bit address in memory to write to
					    bAddrU = Convert.ToByte( (iAddrP & 0xff0000) >> 16 );	        //address upper byte			               
					    bAddrH = Convert.ToByte( (iAddrP & 0x00ff00) >> 8 );	        //address high byte
					    bAddrL = Convert.ToByte( (iAddrP & 0x0000ff) );			        //address low byte
					    bSize = Convert.ToByte( pobjDevice.family.eepromWordSizeB + 1/*checksum*/ );
						
					    //
					    bBuffer[ iBufferIndx++ ] = bAddrU;	iSum += bAddrU;
					    bBuffer[ iBufferIndx++ ] = bAddrH;	iSum += bAddrH;
					    bBuffer[ iBufferIndx++ ] = bAddrL;	iSum += bAddrL;
                        if ( pbSendCommand ) bBuffer[ iBufferIndx++ ] = cCmdWriteEEWord; iSum += cCmdWriteEEWord;
					    bBuffer[ iBufferIndx++ ] = bSize;	iSum += bSize;

                        for ( int iByte = 0; iByte < pobjDevice.family.eepromWordSizeB; iByte++ ) {
					        bProg = Convert.ToByte( pobjHex.iEEMem[ iEepromWord * pobjDevice.family.eepromWordSizeB + iByte ] );
					        bBuffer[ iBufferIndx++ ] = bProg; iSum += bProg;
                        }
		                
					    // Calculate checksum and add to buffer
					    iSum %= 256;
					    iChecksum = Convert.ToInt16( (256 - iSum) % 256 );
					    bBuffer[ iBufferIndx++ ] = Convert.ToByte(iChecksum);
						
					    // Send address, size, word and checksum
					    objPort.SendBytes( ref bBuffer, 0, iBufferIndx );
		                
	                    // Get response, checksum ok
                        ProcessWriteResponse( ref iRetries, iTabLevel, "eeprom", ref bRetry, ref bProcessWriteResponseResult );
                        if ( bProcessWriteResponseResult == false ) {
                            return false;
                        } else if ( clsds30Loader.debugMode == true && bRetry == false ) {
                            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
                        }
		                
	                    //
					    Application.DoEvents();
				    } while ( bRetry == true && bAbort == false );
		            
	                //
				    if ( bAbort == true ) {
					    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "aborted by user", -1) );
					    return false;
				    }
		            
		            //
				    iBytesWritten += pobjDevice.family.eepromWordSizeB;
                    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.progress, "", (100 * iBytesWritten) / iBytesToWrite ) );
			     }//if (  bEEWordUsed[iEepromWord] == true ) {				     
			     
		    }//for ( iIter = 0; iIter < pobjDevice.EepromSizeB/2; iIter++ ) {
		    
            if ( clsds30Loader.debugMode == false ) {
			    OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
            }

            return true;
        }//WriteEeprom()
        

        //---------------------------------------------------------------------
        // WriteFlash()
        //---------------------------------------------------------------------
        static private bool WriteFlash( clsDevice pobjDevice, clsHex pobjHex, bool pbSendCommand, bool pbWriteProgram, bool pbWriteEeprom, bool pbWriteConfigs, int iTabLevel)
        {
            // Calculate 
            int iBytesToWrite = pobjHex.BytesToWrite( objDownloadSettings, pobjDevice );
            iBytesWritten = 0;
            
            // Write program
            if ( pbWriteProgram ) {
                WriteProgram( pobjDevice, pobjHex, iBytesToWrite, pbSendCommand, iTabLevel );
            }

            // Write eeprom
            if ( pbWriteEeprom == true ) {
		        WriteEeprom( pobjDevice, pobjHex, iBytesToWrite, pbSendCommand, iTabLevel );
            }
 
            // Write configs
            if ( pbWriteConfigs == true ) {
		        WriteConfigs( pobjDevice, pobjHex, iBytesToWrite, pbSendCommand, iTabLevel );
            }

            // Write completed
            return true;
        }// WriteFlash()        
            

        //---------------------------------------------------------------------
        // WriteProgram()
        //---------------------------------------------------------------------        
        static private bool WriteProgram( clsDevice pobjDevice, clsHex pobjHex, int iBytesToWrite, bool pbSendCommand, int iTabLevel )
        {
            int     iChecksum;
            int     iSum;
            int     iAddrP;
            int     iRetries;
            byte[]  bBuffer = new byte[256];
            int     iBufferIndx;
            byte    bAddrU, bAddrH, bAddrL, bSize, bProg;
            bool    bRetry = false;
            bool    bProcessWriteResponseResult = false;

            if ( debugMode == false ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing flash...", iTabLevel) );
            }                

            //-------------------------------------------------------------
            // Iterate pages
            //-------------------------------------------------------------
            for ( int iPage = 0; iPage < pobjHex.bProgPageUsed.Length; iPage++ ) {
                if ( pobjHex.bProgPageUsed[iPage] == true ) {

                    // Erase page only on devices with "page-structured memory"
                    if ( pobjDevice.hasPages ) {
                        iRetries = 0;
                        do {
                            if ( clsds30Loader.debugMode ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Erasing page " + iPage.ToString() + "...", iTabLevel) );
                            }

                            //---------------------------------------------------------
                            // Erase page
                            //---------------------------------------------------------
                            iSum = 0;
                            iBufferIndx = 0;

                            // Calculate
                            iAddrP = iPage * pobjDevice.pageSizeR * pobjDevice.rowSizeW * pobjDevice.family.pcuPerWord;	//24-bit address in memory to write to
                            bAddrU = (byte)((iAddrP & 0xff0000) >> 16);				//address upper byte			               
                            bAddrH = (byte)((iAddrP & 0x00ff00) >> 8);				//address high byte
                            bAddrL = (byte)((iAddrP & 0x0000ff) >> 0);				//address low byte
                            bSize = (byte)1/*checksum*/;

                            //
                            bBuffer[iBufferIndx++] = bAddrU; iSum += bAddrU;
                            bBuffer[iBufferIndx++] = bAddrH; iSum += bAddrH;
                            bBuffer[iBufferIndx++] = bAddrL; iSum += bAddrL;
                            if ( pbSendCommand ) bBuffer[iBufferIndx++] = cCmdErasePage; iSum += cCmdErasePage;
                            bBuffer[iBufferIndx++] = bSize; iSum += bSize;

                            // Calculate checksum and add to buffer
                            iSum %= 256;
                            iChecksum = Convert.ToInt16((256 - iSum) % 256);
                            bBuffer[iBufferIndx++] = Convert.ToByte(iChecksum);

                            // Send address, command, packetsize & checksum
                            objPort.SendBytes(ref bBuffer, 0, iBufferIndx);
                            
                            // Get response, checksum ok
                            ProcessWriteResponse( ref iRetries, iTabLevel, "flash", ref bRetry, ref bProcessWriteResponseResult );
                            if ( bProcessWriteResponseResult == false ) {
                                return false;
                            } else if ( debugMode == true && bRetry == false ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
                            }

                            //
                            Application.DoEvents();
                        } while (bRetry == true && bAbort == false);
                    }//if ( pobjDevice.pageSizeR > 1 ) {


                    //---------------------------------------------------------
                    // Iterate rows, write all rows in page (even if not in hex-file)
                    //---------------------------------------------------------
                    for ( int iRow = iPage * pobjDevice.pageSizeR; iRow < iPage * pobjDevice.pageSizeR + pobjDevice.pageSizeR; iRow++ ) {
                        iRetries = 0;
                        do {
                            if ( clsds30Loader.debugMode ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.info, "Writing row " + iRow.ToString() + "...", iTabLevel) );
                            }

                            iBufferIndx = 0;
                            iSum = 0;

                            // Calculate
                            iAddrP = iRow * pobjDevice.rowSizeW * pobjDevice.family.pcuPerWord;				//24-bit address in memory to write to
                            bAddrU = (byte)( (iAddrP & 0xff0000) >> 16 );	//address upper byte			               
                            bAddrH = (byte)( (iAddrP & 0x00ff00) >> 8 );	//address high byte
                            bAddrL = (byte)( (iAddrP & 0x0000ff) >> 0 );	//address low byte
                            bSize = (byte)( pobjDevice.rowSizeW * pobjDevice.family.flashWordSizeB + 1/*checksum*/ );

                            //
                            bBuffer[iBufferIndx++] = bAddrU; iSum += bAddrU;
                            bBuffer[iBufferIndx++] = bAddrH; iSum += bAddrH;
                            bBuffer[iBufferIndx++] = bAddrL; iSum += bAddrL;
                            if ( pbSendCommand ) bBuffer[iBufferIndx++] = cCmdWriteRow; iSum += cCmdWriteRow;
                            bBuffer[iBufferIndx++] = bSize; iSum += bSize;

                            // Calculate startindex in hex-buffer
                            iAddrP = iRow * pobjDevice.rowSizeW * pobjDevice.family.flashWordSizeB;

					        // Buffer row
					        for ( int iByte = 0; iByte < pobjDevice.rowSizeW * pobjDevice.family.flashWordSizeB; iByte++ ) {
							    bProg = pobjHex.iProgMem[iAddrP + iByte];
						        bBuffer[ iBufferIndx++ ] = bProg; iSum = (iSum + bProg) % 256;
					        }

                            // Calculate checksum and add to buffer
                            iSum %= 256;
                            iChecksum = Convert.ToInt16((256 - iSum) % 256);
                            bBuffer[iBufferIndx++] = Convert.ToByte(iChecksum);

                            // Send address, command, packetsize, row & checksum
                            objPort.SendBytes(ref bBuffer, 0, iBufferIndx);

                            // Get response, checksum ok
                            ProcessWriteResponse( ref iRetries, iTabLevel, "flash", ref bRetry, ref bProcessWriteResponseResult );
                            if ( bProcessWriteResponseResult == false ) {
                                return false;
                            } else if ( clsds30Loader.debugMode == true && bRetry == false ) {
                                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
                            }

                            //
                            Application.DoEvents();
                        } while ( bRetry == true && bAbort == false );

                        //
                        if (bAbort == true) {
                            OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.error, "aborted by user", -1) );
                            return false;
                        }

                        //
                        iBytesWritten += pobjDevice.rowSizeW * pobjDevice.family.flashWordSizeB;
                        OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.progress, "", (100 * iBytesWritten) / iBytesToWrite ) );

                    }//for ( iRow = 0; iRow < iRowUsedBufferSize; iRow++ ) {

                } //if ( bPageUsed[iIter] == true ) {

            }//for ( iPage = 0; iPage < iPageUsedBufferSize; iPage++ ) {

            if ( clsds30Loader.debugMode == false ) {
                OnDownloading( new clsDownloadingEventArgs(clsDownloadingEventArgs.EventType.success, "ok", -1) );
            }

            return true;
        }//WriteProgram()

    }// Class: clsds30Loader
}
