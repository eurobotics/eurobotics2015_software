﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  

using System;
using System.Text;
using System.IO;
using GHelper;


namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsHex
	//-------------------------------------------------------------------------
	public class clsHex
	{
        public enum HexRecordType{ Data=0, EndOfFile, ExtendedSegmentAddress, StartSegmentAddress, ExtendedLinearAddress, StartLinearAddress };
         
		//---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------
        protected int iDefaultBlPlacementP = -1;  //page from the end
        protected int iDefaultBlSizeP = -1;       //[pages]
        
        protected string strFilename = "";
		
        protected bool bIsParsed = false;        
        
        public clsParseSettings objParsedSettings;

        protected bool bHasValidProgram = false;
		protected bool bHasValidEeprom = false;
		protected bool bHasValidConfigs = false;
        

		// These are filled in by ParseHexFile(), not all families use all of theese	
        public byte [] iProgMem;		
        UInt16 iChecksum16;
        UInt16 iChecksum14;

        protected int iProgPagesUsed;
        public bool [] bProgPageUsed;

		public bool [] bProgRowUsed;		        
        protected int iProgRowsUsed;	
	
		protected int iProgWordsUsed;

		public int [] iEEMem;
		public bool [] bEEWordUsed;
		protected int iEEWordsUsed;
				
		public int [] iConfigMem;
		public bool [] bConfigWordUsed;		
		protected int iConfigWordsUsed;

        //
        int iUserAppAddress = 0;

		// 
		public delegate void HexFileValidateDelegate( object sender, clsHexFileValidateEventArgs e );
		public event HexFileValidateDelegate HexFileValidate;	

		// 
		public delegate void HexFileParseDelegate( object sender, clsHexFileParseEventArgs e );
		public event HexFileParseDelegate HexFileParse;	


        //---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		public clsHex()
		{
            objParsedSettings = new clsParseSettings();
		}// Constructor()


		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		public clsHex( string pstrFilename )
		{
            objParsedSettings = new clsParseSettings();
            strFilename = pstrFilename;
		}// Constructor()
		
						        
		//---------------------------------------------------------------------
		// Event: HexFileParse
		//---------------------------------------------------------------------
		protected internal void OnHexFileParse( clsHexFileParseEventArgs e )
		{
			// Event will be null if no client has hooked up a delegate to the event
			if ( HexFileParse != null ) {
				HexFileParse( this, e );
			}
		}//Event: HexFileParse	
		
		        
		//---------------------------------------------------------------------
		// Event: FileValidate
		//---------------------------------------------------------------------
		protected internal void OnHexFileValidate( clsHexFileValidateEventArgs e )
		{
			// Event will be null if no client has hooked up a delegate to the event
			if ( HexFileValidate != null ) {
				HexFileValidate( this, e );
			}
		}//Event: FileValidated

 		  		
        //---------------------------------------------------------------------
		// Property: configWordsUsed
		//---------------------------------------------------------------------
		public int configWordsUsed
		{
			get {
				return iConfigWordsUsed;
			}
        }//Property: configWordsUsed

 		  		
        //---------------------------------------------------------------------
		// Property: defaultBlPlacementP
		//---------------------------------------------------------------------
        public int defaultBlPlacementP 
        {
            get {
                return iDefaultBlPlacementP;
            }
        }//Property: defaultBlPlacementP
 		  		
        //---------------------------------------------------------------------
		// Property: defaultBlSizeP
		//---------------------------------------------------------------------
        public int defaultBlSizeP 
        {
            get {
                return iDefaultBlSizeP;
            }
        }//Property: defaultBlSizeP


 		//---------------------------------------------------------------------
		// Property: eeWordsUsed
		//---------------------------------------------------------------------
		public int eeWordsUsed
		{
			get {
				return iEEWordsUsed;
			}
        }//Property: eeWordsUsed


 		//---------------------------------------------------------------------
		// Property: filename
		//---------------------------------------------------------------------
		public string filename
		{
			get {
				return strFilename;
			} set {
				if ( value != strFilename ) {
					strFilename = value.Trim();
                    
                    bIsParsed = false;
                    bHasValidProgram = false;
		            bHasValidEeprom = false;
		            bHasValidConfigs = false;
				}
			}
        }//Property: filename
       

 		//---------------------------------------------------------------------
		// Property: hasValidProgram
		//---------------------------------------------------------------------
		public bool hasValidProgram
		{
			get {
				return bHasValidProgram;
			}
        }//Property: hasValidProgram

        
 		//---------------------------------------------------------------------
		// Property: hasValidEeprom
		//---------------------------------------------------------------------
		public bool hasValidEeprom
		{
			get {
				return bHasValidEeprom;
			}
        }//Property: hasValidEeprom

        
 		//---------------------------------------------------------------------
		// Property: hasValidConfigs
		//---------------------------------------------------------------------
		public bool hasValidConfigs
		{
			get {
				return bHasValidConfigs;
			}
        }//Property: hasValidConfigs


 		//---------------------------------------------------------------------
		// Property: isParsed
		//---------------------------------------------------------------------
		protected bool isParsed
		{
			get {
				return bIsParsed;
			}
        }//Property: isParsed


 		//---------------------------------------------------------------------
		// Property: progPagesUsed
		//---------------------------------------------------------------------
		public int progPagesUsed
		{
			get {
				return iProgPagesUsed;
			}
        }//Property: progPagesUsed


 		//---------------------------------------------------------------------
		// Property: progRowsUsed
		//---------------------------------------------------------------------
		public int progRowsUsed
		{
			get {
				return iProgRowsUsed;
			}
        }//Property: progRowsUsed


  		//---------------------------------------------------------------------
		// Property: progWordsUsed
		//---------------------------------------------------------------------
		public int progWordsUsed
		{
			get {
				return iProgWordsUsed;
			}
        }//Property: progWordsUsed
        

  		//---------------------------------------------------------------------
		// Property: userApplAddress
		//---------------------------------------------------------------------
		public int userApplAddress
		{
			get {
				return iUserAppAddress;
			}
        }//Property: userApplAddress


        //---------------------------------------------------------------------
		// AddChecksum()
		//---------------------------------------------------------------------
		public void AddChecksum( clsParseSettings pobjSettings, int piTabLevel )
		{
			if ( pobjSettings.addChecksum == false ) return;

            int iBlStartAddress = GetBootloaderStartAddress( pobjSettings );
            int iChecksumAddress; 

            // Calculate checksum address
            if ( pobjSettings.device.family.ToString() == "PIC16F" ) {
                iChecksumAddress = iBlStartAddress - 3/*goto*/ - 1/*checksum*/;
            } else {
                iChecksumAddress = iBlStartAddress - 4/*goto*/ - 2/*checksum*/;
            }
            int iFirstChecksumIndex = iChecksumAddress / pobjSettings.device.family.pcuPerWord * pobjSettings.device.family.flashWordSizeB;

            // Calculate checksum
            iChecksum16 = 0;
            iChecksum14 = 0;
            
            
            for ( int iIter = 0; iIter < iFirstChecksumIndex; iIter++ ) {
                iChecksum16 += iProgMem[ iIter ];
                iChecksum14 += iProgMem[ iIter ];
                iChecksum14 %= 255;

                // Mark page as used
                //bProgPageUsed[ (int)Math.Floor((decimal)((iIter/pobjSettings.device.family.flashWordSizeB)  / (pobjSettings.device.pageSizeR * pobjSettings.device.rowSizeW)))  ] = true;
                bProgPageUsed[ (iIter/pobjSettings.device.family.flashWordSizeB)  / (pobjSettings.device.pageSizeR * pobjSettings.device.rowSizeW)  ] = true;

            }
            iChecksum16 = (UInt16)(0x10000 - iChecksum16);
            iChecksum14 = (UInt16)(0x4000 - iChecksum14);
            
            switch ( pobjSettings.device.family.flashWordSizeBits ) {
                // 16-bit devices
                case 24:
                    iProgMem[ iFirstChecksumIndex + 2 ] = (byte)( iChecksum16 >> 8 );    //high byte
                    iProgMem[ iFirstChecksumIndex + 1 ] = (byte)( iChecksum16 & 0xff );  //low byte
                    break;
            
                // PIC18
                case 16:
                    iProgMem[ iFirstChecksumIndex + 1 ] = (byte)( iChecksum16 >> 8 );
                    iProgMem[ iFirstChecksumIndex + 0 ] = (byte)( iChecksum16 & 0xff );
                    break;
            
                // PIC16
                case 14:
                    iProgMem[ iFirstChecksumIndex + 1 ] = (byte)( (iChecksum14 & 0x3f) >> 8 );
                    iProgMem[ iFirstChecksumIndex + 0 ] = (byte)( iChecksum14 & 0xff );
                    break;
                default:
                    throw new Exception( "Unknown word size in AddChecksum()" );
            }
		}// AddChecksum()


        //---------------------------------------------------------------------
		// BytesToWrite()
		//---------------------------------------------------------------------
		virtual public int BytesToWrite( clsDownloadSettings pobjDownloadSettings, clsDevice pobjDevice )
		{
			return 
				Convert.ToInt32(pobjDownloadSettings.writeProgram) * (iProgPagesUsed * pobjDevice.pageSizeR * pobjDevice.rowSizeW * pobjDevice.family.flashWordSizeB) + 
				Convert.ToInt32(pobjDownloadSettings.writeEeprom) * iEEWordsUsed * pobjDevice.family.eepromWordSizeB +
				Convert.ToInt32(pobjDownloadSettings.writeConfigs) * iConfigWordsUsed * pobjDevice.family.configWordSizeB
			;
		}// BytesToWrite()


        //---------------------------------------------------------------------
		// CalcHexContent()
		//---------------------------------------------------------------------
        public void CalcHexContent( clsParseSettings pobjSettings, int piTabLevel )
		{
            clsDebugTextbox.buffer = true;

            //--------------------------------------------------------------------------
            // Find out how many pages are used
            //--------------------------------------------------------------------------   
            {
                iProgPagesUsed = 0;
                for ( int iPageIter = 0; iPageIter < bProgPageUsed.Length; iPageIter++ ) {
                    if ( bProgPageUsed[ iPageIter ] == true ) {
                        ++iProgPagesUsed;
                        if ( clsds30Loader.debugMode == true ) {
                            if ( pobjSettings.device.pageSizeR > 1 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Flash page " + iPageIter.ToString() + " is used, 0x" + (iPageIter * pobjSettings.device.pageSizeR*pobjSettings.device.rowSizeW*pobjSettings.device.family.pcuPerWord).ToString("X2") + " - 0x" + ((iPageIter+1) * pobjSettings.device.pageSizeR*pobjSettings.device.rowSizeW*pobjSettings.device.family.pcuPerWord - 1).ToString("X2"), piTabLevel) );
                            }
                        
                            for ( int iRow = iPageIter * pobjSettings.device.pageSizeR; iRow < iPageIter * pobjSettings.device.pageSizeR + pobjSettings.device.pageSizeR; iRow++ ) {
                                if ( bProgRowUsed[ iRow ] == true ) {
                                    OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Flash row " + iRow.ToString() + " is used, 0x" + (iRow*pobjSettings.device.rowSizeW*pobjSettings.device.family.pcuPerWord).ToString("X2") + " - 0x" + ((iRow+1) * pobjSettings.device.rowSizeW*pobjSettings.device.family.pcuPerWord - 1).ToString("X2"), piTabLevel) );
                                }
                            }
                        }
                    }
                }
                if ( iProgPagesUsed == 0 ) {
                    bHasValidProgram = false;
                }
            }


            //--------------------------------------------------------------------------
            // Find out how many program rows are used
            //--------------------------------------------------------------------------
            {
                iProgRowsUsed = 0;
                for ( int iIter = 0; iIter < bProgRowUsed.Length; iIter++ ) {
                    if ( bProgRowUsed[ iIter ] == true ) {
                        ++iProgRowsUsed;
                    }
                }
                if ( iProgRowsUsed == 0 ) {
                    bHasValidProgram = false;
                }
            }
			
			
			//--------------------------------------------------------------------------
			// Eeprom
			//--------------------------------------------------------------------------
		    {
                if ( iEEWordsUsed == 0 ) {
			        bHasValidEeprom = false;
		        }	

                if ( clsds30Loader.debugMode == true && pobjSettings.device.eepromSizeB > 0 ) {
                    //iEEWordsUsed = 0;
		            for ( int iIter = 0; iIter < bEEWordUsed.Length; iIter++ ) {
			            if ( bEEWordUsed[iIter] == true) { 
                            if ( pobjSettings.device.configWordSizeB == 1 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Eeprom word " + iIter.ToString() + " is used, value: 0x" + iEEMem[iIter].ToString("X2"), piTabLevel) );
                            } else if ( pobjSettings.device.configWordSizeB == 2 ) {
				                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Eeprom word " + iIter.ToString() + " is used, value: 0x" + ((iEEMem[iIter*2+1]<<8)+iEEMem[iIter*2]).ToString("X4"), piTabLevel) );
                            }
			            }
                        //++iEEWordsUsed;
                    }
                }
            }
	    

			//--------------------------------------------------------------------------
			// Configs
			//--------------------------------------------------------------------------
 		    {
                if ( iConfigWordsUsed > pobjSettings.device.configCount ) {
			        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "The hex-file contains more config words than the device has", piTabLevel) );
			        bHasValidConfigs = false;
		        } else if ( iConfigWordsUsed == 0 || pobjSettings.device.family.name == "PIC16F" ) {
			        bHasValidConfigs = false;
		        }
                
                if ( clsds30Loader.debugMode == true && pobjSettings.device.configCount > 0 ) {
		            for ( int iIter = 0; iIter < bConfigWordUsed.Length; iIter++ ) {
			            if ( bConfigWordUsed[iIter] == true ) { 
				            if ( pobjSettings.device.configWordSizeB == 1 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Config word " + iIter.ToString() + " is used, value: 0x" + iConfigMem[iIter].ToString("X2"), piTabLevel) );
                            } else if ( pobjSettings.device.configWordSizeB == 2 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Config word " + iIter.ToString() + " is used, value: 0x" + ((iConfigMem[iIter*2+1]<<8)+iConfigMem[iIter*2]).ToString("X4"), piTabLevel) );
                            }
			            }
			        }
                }
            }
            clsDebugTextbox.buffer = false;
        }// CalcHexContent()


        //---------------------------------------------------------------------
		// CheckForBlOverwrite()
		//---------------------------------------------------------------------
		public void CheckForBlOverwrite( clsParseSettings pobjSettings, int piTabLevel )
		{
            bool bBlOverwrite = false;
            
            int iBlStartRow = GetBootloaderStartRow( pobjSettings );
            int iBlEndRow = GetBootloaderEndRow( pobjSettings );

            for ( int iIter = iBlStartRow; iIter <= iBlEndRow; iIter++ ) {
                if ( bProgRowUsed[ iIter ] == true ) {
                    bBlOverwrite = true;
                    break;
                }
            }
			if ( bBlOverwrite == true ) {
                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "The hex-file contains code that will overwrite the bootloader", piTabLevel) );
				if ( pobjSettings.allowBlOverwrite == false ) {
					bHasValidProgram = false;
				}
			}
		}// BytesToWrite()  


        //---------------------------------------------------------------------
		// CheckForGotoAt0()
		//---------------------------------------------------------------------
		public void CheckForGotoAt0( clsParseSettings pobjSettings, int piTabLevel )
		{
            string strFamily = pobjSettings.device.family.name;


            //---------------------------------------------------------------------
		    // PIC16F
		    //---------------------------------------------------------------------            
            if ( strFamily == "PIC16F" ) {
                 if ( pobjSettings.noGoto == false ) {
                    bool bGotoFound = 
                        (
                            (iProgMem[1] & 0x38) == 0x28 ||
                            (iProgMem[3] & 0x38) == 0x28 ||
                            (iProgMem[5] & 0x38) == 0x28
                        )
                        &&
                        bProgRowUsed[0] == true
                    ;

                    if ( bGotoFound == false ) {
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "There's no GOTO at location 0x00", piTabLevel) );
                        bHasValidProgram = false;
                    }
                }               
            

            //---------------------------------------------------------------------
		    // PIC18F  PIC18FJ
		    //---------------------------------------------------------------------            
            } else if ( strFamily == "PIC18F" || strFamily == "PIC18FJ" ) {
                if ( pobjSettings.noGoto == false ) {
                    bool bGotoFound = 
                        iProgMem[1] == 0xEF &&
                        (iProgMem[3] & 0xF0) == 0xF0 &&
                        bProgRowUsed[0] == true
                    ;

                    if ( bGotoFound == false ) {
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "There's no GOTO at location 0x00", piTabLevel) );
                        bHasValidProgram = false;
                    }
                }
          
                
            //---------------------------------------------------------------------
		    // PIC24F  PIC24FJ  PIC24H  dsPIC30F  dsPIC33FJ
		    //---------------------------------------------------------------------            
            } else { 
                if ( pobjSettings.noGoto == false ) {
                    bool bGotoFound = 
                        iProgMem[0] == 0x04 &&
                        bProgRowUsed[0] == true
                    ;

                    if ( bGotoFound == false ) {
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "There's no GOTO at location 0x00", piTabLevel) );
                        bHasValidProgram = false;
                    }
                }
            }
        }// CheckForGotoAt0()

        

        //---------------------------------------------------------------------
		// GetBootloaderEndRow()
		//---------------------------------------------------------------------
		public int GetBootloaderEndRow( clsParseSettings pobjParseSettings ) 
		{
			return GetBootloaderStartRow(pobjParseSettings) + pobjParseSettings.blSizeP * pobjParseSettings.device.pageSizeR - 1;
        }// GetBootloaderEndRow() 
       

        //---------------------------------------------------------------------
		// GetBootloaderStartAddress()
		//---------------------------------------------------------------------
		public int GetBootloaderStartAddress( clsParseSettings pobjParseSettings ) 
		{
			clsDevice objDev = pobjParseSettings.device;
            
            if ( objDev == null ) {
                return 0;
            }
            
            return objDev.flashSizePcu - pobjParseSettings.blPlacementP * objDev.pageSizeR * objDev.rowSizeW * objDev.family.pcuPerWord;
        }// GetBootloaderStartAddress()
 		
        
        //---------------------------------------------------------------------
		// GetBootloaderStartRow()
		//---------------------------------------------------------------------
		public int GetBootloaderStartRow( clsParseSettings pobjParseSettings ) 
		{
            return GetBootloaderStartAddress(pobjParseSettings) / ( pobjParseSettings.device.family.pcuPerWord * pobjParseSettings.device.rowSizeW );
        }// GetBootloaderStartRow()


        //---------------------------------------------------------------------
		// InitBuffers()
		//---------------------------------------------------------------------
		public void InitBuffers( clsParseSettings pobjSettings, int piTabLevel ) 
		{
            int iIter;
            for ( iIter = 0; iIter < bProgPageUsed.Length; iIter++ ) bProgPageUsed[iIter] = false;
            for ( iIter = 0; iIter < bProgRowUsed.Length; iIter++ ) bProgRowUsed[iIter] = false;
            
            if ( pobjSettings.device.family.name == "PIC16F" ) {
                for ( iIter = 0; iIter < iProgMem.Length; iIter++ ) iProgMem[iIter] = 0x00; //NOP
            } else {
                for ( iIter = 0; iIter < iProgMem.Length; iIter++ ) iProgMem[iIter] = 0xFF; //NOP
            }

            for ( iIter = 0; iIter < bEEWordUsed.Length; iIter++ ) bEEWordUsed[iIter] = false;
		    for ( iIter = 0; iIter < iEEMem.Length; iIter++ ) iEEMem[iIter] = 0xFF;
			
            for ( iIter = 0; iIter < bConfigWordUsed.Length; iIter++ ) bConfigWordUsed[iIter] = false;
		    for ( iIter = 0; iIter < iConfigMem.Length; iIter++ ) iConfigMem[iIter] = 0xFF;	
        }// InitBuffers()


  		//---------------------------------------------------------------------
		// NeedsParsing()
		//---------------------------------------------------------------------
		protected bool NeedsParsing( clsParseSettings pobjSettings )
		{
			return ( pobjSettings.CompareTo(objParsedSettings) == false || isParsed == false );
        }//Property: NeedsParsing()


        //---------------------------------------------------------------------
		// OutputBlDebugInfo()
		//---------------------------------------------------------------------
		public void OutputBlDebugInfo( clsParseSettings pobjSettings, int iTabLevel )
		{
            int iStartRow = GetBootloaderStartRow(pobjSettings);
            int iEndRow = GetBootloaderEndRow(pobjSettings);
            int iStartPage = iStartRow / pobjSettings.device.pageSizeR;
            int iEndPage = iEndRow / pobjSettings.device.pageSizeR;

            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Bootloader start address: 0x" + GetBootloaderStartAddress(pobjSettings).ToString("X2"), iTabLevel) );
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Bootloader start page: " + iStartPage.ToString(), iTabLevel) );
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Bootloader end page: " + iEndPage.ToString(), iTabLevel) );
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Bootloader start row: " + iStartRow.ToString(), iTabLevel) );
            OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Bootloader end row: " + iEndRow.ToString(), iTabLevel) );
            if ( pobjSettings.addChecksum ) {
                if ( pobjSettings.device.family.flashWordSizeBits == 14 ) {
                    OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Flash checksum: 0x" + iChecksum14.ToString("X4"), iTabLevel) );
                } else {
                    OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Flash checksum: 0x" + iChecksum16.ToString("X4"), iTabLevel) );
                }
            }            
        }// OutputBlDebugInfo()
        
        
        //---------------------------------------------------------------------
		// ParseHexFilePIC16()
		//---------------------------------------------------------------------
		public void ParseHexFilePIC16( clsParseSettings pobjSettings, int iTabLevel )
		{
            iProgWordsUsed = 0;
            iEEWordsUsed = 0;
            iConfigWordsUsed = 0;

            //--------------------------------------------------------------------------
			// Hex-file format
			// : 10 8000 00 0800 fa00 000f 8001
			// | |  |    |  |-Data
			// | |  |    |----Line record type
			// | |  |---------Line address
			// | |------------Line byte count
			// |--------------Start code (just a simple colon)
			//--------------------------------------------------------------------------
			int iLineAddrHigh = 0;
            int iAddress;
            int iOutAddr;
			
            string strFileLine;
			string strLineStartCode;
            int iLineByteCount;
            int iLineAddress;
            HexRecordType iLineRecordType;
            string strLineData;
            int iUnknownData = 0;

            // Open hex-file
            TextReader textReader = new StreamReader( strFilename );            
 
            while ( textReader.Peek() != -1 ) {
                strFileLine = textReader.ReadLine();
                strLineStartCode = strFileLine.Substring(0, 1);

               if ( strLineStartCode == ":" ) {
                    //Parse the line
                    iLineByteCount = int.Parse( strFileLine.Substring( 1, 2 ), System.Globalization.NumberStyles.HexNumber );
                    iLineAddress = ( int.Parse( strFileLine.Substring( 3, 4 ), System.Globalization.NumberStyles.HexNumber ) & 65535 );
                    iLineRecordType = (HexRecordType)int.Parse( strFileLine.Substring( 7, 2 ), System.Globalization.NumberStyles.HexNumber );
                    strLineData = strFileLine.Substring( 9, ( iLineByteCount * 2 ) );

                    // Calculate address
                    iAddress = ((iLineAddrHigh << 16) + iLineAddress)/2;

                    // Data record
                    if ( iLineRecordType == HexRecordType.Data ) {

                        // Regular program memory
                        if ( iAddress < pobjSettings.device.flashSizePcu ) {
							iOutAddr = iAddress*2;
                            iProgWordsUsed += iLineByteCount/2;

						    for ( int iByte = 0; iByte < iLineByteCount; iByte++ ) {
							    iProgMem[iOutAddr + iByte] = byte.Parse( strLineData.Substring(iByte*2 + 0, 2), System.Globalization.NumberStyles.HexNumber );
                                
                                int iWord = Convert.ToInt32( Math.Floor((iOutAddr + iByte) / 2.0) );
                                int iRow = iWord / pobjSettings.device.rowSizeW;
                                int iPage = iRow / pobjSettings.device.pageSizeR;
                                
                                bProgPageUsed[ iPage ] = true;
							    bProgRowUsed[ iRow ] = true;
						    }	
                            

						// Eeprom memory 0x2100
						} else if ( pobjSettings.device.eepromSizeB > 0 && iAddress >= 0x2100 && iAddress < (0x2100 + pobjSettings.device.eepromSizeB) ) {
                            iOutAddr = iAddress - 0x2100;

							for ( int iByte = 0; iByte < iLineByteCount/2; iByte++ ) {
								iEEMem[ iOutAddr + iByte ] = int.Parse( strLineData.Substring(iByte*4 + 0, 2), System.Globalization.NumberStyles.HexNumber );								
								bEEWordUsed[ iOutAddr + iByte ] = true;
                                ++iEEWordsUsed;
							}                            

						// Eeprom memory 0xF000 (enhanced devices)
						} else if ( pobjSettings.device.eepromSizeB > 0 && iAddress >= 0xF000 && iAddress < (0xF000 + pobjSettings.device.eepromSizeB) ) {
                            iOutAddr = iAddress - 0xF000;

							for ( int iByte = 0; iByte < iLineByteCount/2; iByte++ ) {
								iEEMem[ iOutAddr + iByte ] = int.Parse( strLineData.Substring(iByte*4 + 0, 2), System.Globalization.NumberStyles.HexNumber );								
								bEEWordUsed[ iOutAddr + iByte ] = true;
                                ++iEEWordsUsed;
							}
							                        
						// Config memory 0x2100
						} else if ( pobjSettings.device.configCount > 0 && iAddress >= 0x2007 && iAddress <= 0x2008) {	
							iOutAddr = iAddress - 0x2007;
                            int iWordCount = iLineByteCount / 2;
							iConfigWordsUsed += iWordCount;

							for ( int iWord = 0; iWord < iWordCount; iWord++ ) {
								iConfigMem[iOutAddr + iWord*2 + 0] = int.Parse( strLineData.Substring(iWord*4 + 0, 2), System.Globalization.NumberStyles.HexNumber );
								iConfigMem[iOutAddr + iWord*2 + 1] = int.Parse( strLineData.Substring(iWord*4 + 2, 2), System.Globalization.NumberStyles.HexNumber );	
								bConfigWordUsed[ iOutAddr + iWord ] = true;
							}
							                        
						// Config memory 0x8000 (enhanced devices)
						} else if ( pobjSettings.device.configCount > 0 && iAddress >= 0x8007 && iAddress <= 0x8008) {	
							iOutAddr = iAddress - 0x8007;
                            int iWordCount = iLineByteCount / 2;
							iConfigWordsUsed += iWordCount;

							for ( int iWord = 0; iWord < iWordCount; iWord++ ) {
								iConfigMem[iOutAddr + iWord*2 + 0] = int.Parse( strLineData.Substring(iWord*4 + 0, 2), System.Globalization.NumberStyles.HexNumber );
								iConfigMem[iOutAddr + iWord*2 + 1] = int.Parse( strLineData.Substring(iWord*4 + 2, 2), System.Globalization.NumberStyles.HexNumber );	
								bConfigWordUsed[ iOutAddr + iWord ] = true;
							}

                        // Unknown data
                        } else {
                            ++iUnknownData;
                            if ( iUnknownData < 5 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Unknown data found, " + iLineByteCount.ToString() + " bytes at 0x" + iAddress.ToString("X4"), iTabLevel) );
                            } else if ( iUnknownData == 5 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "More unknown data...", iTabLevel) );
                            }                            
                        }

                    // End Of File record
                    } else if ( iLineRecordType == HexRecordType.EndOfFile ) {
                        break;

                    // Extended Linear Address Record
                    // The two data bytes represent the upper 16 bits of the 32 bit address, when combined with the address of the 00 type record.
                    } else if ( iLineRecordType == HexRecordType.ExtendedLinearAddress ) {
                        iLineAddrHigh = ( int.Parse( strFileLine.Substring( 9, 4 ), System.Globalization.NumberStyles.HexNumber ) & 65535 );
                    }
                }
            }

            // Close files
            textReader.Close();            
		}// ParseHexFilePIC16()
       

        //---------------------------------------------------------------------
		// ParseHexFile8()
		//---------------------------------------------------------------------
		public void ParseHexFile8( clsParseSettings pobjSettings, int iTabLevel )
		{
            iProgWordsUsed = 0;
            iEEWordsUsed = 0;
            iConfigWordsUsed = 0;

            //--------------------------------------------------------------------------
			// Hex-file format
			// : 10 8000 00 0800 fa00 000f 8001
			// | |  |    |  |-Data
			// | |  |    |----Line record type
			// | |  |---------Line address
			// | |------------Line byte count
			// |--------------Start code (just a simple colon)
			//--------------------------------------------------------------------------
			int iLineAddrHigh = 0;
            int iAddress;
            int iOutAddr;
			
            string strFileLine;
			string strLineStartCode;
            int iLineByteCount;
            int iLineAddress;
            HexRecordType iLineRecordType;
            string strLineData;
            int iUnknownData = 0;

            // Open hex-file
            TextReader textReader = new StreamReader( strFilename );            
 
            while ( textReader.Peek() != -1 ) {
                strFileLine = textReader.ReadLine();
                strLineStartCode = strFileLine.Substring(0, 1);

               if ( strLineStartCode == ":" ) {
                    //Parse the line
                    iLineByteCount = int.Parse( strFileLine.Substring( 1, 2 ), System.Globalization.NumberStyles.HexNumber );
                    iLineAddress = ( int.Parse( strFileLine.Substring( 3, 4 ), System.Globalization.NumberStyles.HexNumber ) & 65535 );
                    iLineRecordType = (HexRecordType)int.Parse( strFileLine.Substring( 7, 2 ), System.Globalization.NumberStyles.HexNumber );
                    strLineData = strFileLine.Substring( 9, ( iLineByteCount * 2 ) );

                    // Calculate address
                    iAddress = (iLineAddrHigh << 16) + iLineAddress;

                    // Data record
                    if ( iLineRecordType == HexRecordType.Data ) {

                        // Regular program memory
                        if ( iAddress <= pobjSettings.device.flashSizePcu ) {
							iOutAddr = iAddress;
                            iProgWordsUsed += iLineByteCount/2;

						    for ( int iByte = 0; iByte < iLineByteCount; iByte++ ) {
							    iProgMem[iOutAddr + iByte] = byte.Parse( strLineData.Substring(iByte*2 + 0, 2), System.Globalization.NumberStyles.HexNumber );
                                
                                int iWord = Convert.ToInt32( Math.Floor((iAddress + iByte) / 2.0) );
                                int iRow = iWord / pobjSettings.device.rowSizeW;
                                int iPage = iRow / pobjSettings.device.pageSizeR;
                                
                                bProgPageUsed[ iPage ] = true;
							    bProgRowUsed[ iRow ] = true;
						    }	
                            

						// Eeprom memory
						} else if ( pobjSettings.device.eepromSizeB > 0 && iAddress >= 0xF00000 && iAddress < (0xF00000 + pobjSettings.device.eepromSizeB) ) {
                            iOutAddr = iAddress - 0xF00000;

							for ( int iByte = 0; iByte < iLineByteCount; iByte++ ) {
								iEEMem[ iOutAddr + iByte ] = int.Parse( strLineData.Substring(iByte*2 + 0, 2), System.Globalization.NumberStyles.HexNumber );								
								bEEWordUsed[ iOutAddr + iByte ] = true;
                                ++iEEWordsUsed;
							}

							                        
						// Config memory
						} else if ( pobjSettings.device.configCount > 0 && iAddress >= 0x300000 && iAddress <= 0x30000D) {	
							iOutAddr = iAddress - 0x300000;
							
							for ( int iByte = 0; iByte < iLineByteCount; iByte++ ) {
								iConfigMem[ iOutAddr + iByte ] = int.Parse( strLineData.Substring(iByte*2 + 0, 2), System.Globalization.NumberStyles.HexNumber );
								bConfigWordUsed[ iOutAddr + iByte ] = true;
                                ++iConfigWordsUsed;
							}	
                        
                        // Unknown data
                        } else {
                            ++iUnknownData;
                            if ( iUnknownData < 5 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Unknown data found, " + iLineByteCount.ToString() + " bytes at 0x" + iAddress.ToString("X4"), iTabLevel) );
                            } else if ( iUnknownData == 5 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "More unknown data...", iTabLevel) );
                            }                            
                        }

                    // End Of File record
                    } else if ( iLineRecordType == HexRecordType.EndOfFile ) {
                        break;

                    // Extended Linear Address Record
                    // The two data bytes represent the upper 16 bits of the 32 bit address, when combined with the address of the 00 type record.
                    } else if ( iLineRecordType == HexRecordType.ExtendedLinearAddress ) {
                        iLineAddrHigh = ( int.Parse( strFileLine.Substring( 9, 4 ), System.Globalization.NumberStyles.HexNumber ) & 65535 );
                    }
                }
            }

            // Close files
            textReader.Close();            
		}// ParseHexFile8()
        

        //---------------------------------------------------------------------
		// ParseHexFile16()
		//---------------------------------------------------------------------
		public void ParseHexFile16( clsParseSettings pobjSettings, int iTabLevel )
		{
            iProgWordsUsed = 0;
            iEEWordsUsed = 0;
            iConfigWordsUsed = 0;

            //--------------------------------------------------------------------------
			// Hex-file format
			// : 10 8000 00 0800 fa00 000f 8001
			// | |  |    |  |-Data
			// | |  |    |----Line record type
			// | |  |---------Line address
			// | |------------Line byte count
			// |--------------Start code (just a simple colon)
			//--------------------------------------------------------------------------
			int iLineAddrHigh = 0;
            int iAddress;
            int iOutAddr;
			int iWordCount;	
			
            string strFileLine;
			string strLineStartCode;
            int iLineByteCount;
            int iLineAddress;
            HexRecordType iLineRecordType;
            string strLineData;
            int iUnknownData = 0;

			// Open hex-file
			TextReader textReader = new StreamReader( strFilename );

			while ( textReader.Peek() != -1 ) {
                
				strFileLine = textReader.ReadLine();	        
                strLineStartCode = strFileLine.Substring(0, 1);
				
				if ( strLineStartCode == ":" ) {
					//Parse the line
					iLineByteCount = int.Parse( strFileLine.Substring(1, 2), System.Globalization.NumberStyles.HexNumber );
					iLineAddress = ( int.Parse(strFileLine.Substring(3, 4), System.Globalization.NumberStyles.HexNumber) & 65535 );
					iLineRecordType = (HexRecordType)int.Parse( strFileLine.Substring(7, 2), System.Globalization.NumberStyles.HexNumber );
					strLineData = strFileLine.Substring( 9, ((int)iLineByteCount * 2) );
					
                    // Calculate address
					iAddress = ( (iLineAddrHigh << 16) + iLineAddress ) / 2;
                    
					// Data record
					if ( iLineRecordType == HexRecordType.Data ) {
						iWordCount = iLineByteCount / 4;

						// Regular program memory
						if ( iAddress <= pobjSettings.device.flashSizePcu ) {
							iOutAddr = (iAddress * 3) / 2/*32bit-16bit*/;
                            int iWord = 0;
                            int iOffset = 0;
                            for ( int iByte = 0; iByte < iLineByteCount; iByte++ ) {
                                // bytes come low-high-upper-unused in the hex-file, transform to upper-low-high	
                                switch ( ((iByte+1) % 4) ) {
                                    case 3:
                                        iOffset = -2;
                                        break;
                                    case 2:
							            iOffset = 1;
                                        break;
                                    case 1:
							            iOffset = 1;                                    
                                        break;
                                    case 0:
                                        bProgPageUsed[ (iAddress/2 + iWord) / (pobjSettings.device.pageSizeR * pobjSettings.device.rowSizeW)  ] = true;
							            bProgRowUsed[  (iAddress/2 + iWord) / pobjSettings.device.rowSizeW  ] = true;
                                        ++iProgWordsUsed;
                                        ++iWord;
                                    break;
                                }
                                
                                if ( ((iByte+1) % 4) != 0 ) {
                                    iProgMem[iOutAddr + iByte + iOffset - iWord] = byte.Parse( strLineData.Substring(iByte*2, 2), System.Globalization.NumberStyles.HexNumber );
                                }
                            }
							 
						// Eeprom memory
						} else if ( pobjSettings.device.eepromSizeB > 0 && iAddress >= (0x800000 - pobjSettings.device.eepromSizeB) && iAddress < 0x800000 ) {
							iOutAddr = iAddress - ( 0x800000 - pobjSettings.device.eepromSizeB) ;
							int iWord = 0;
							for ( int iByte = 0; iByte < iLineByteCount; iByte++ ) {
                                
                                if ( (iByte%4) <= 1 ) {
								    iEEMem[iOutAddr + iWord*2 + (iByte%4)] = int.Parse( strLineData.Substring(iWord*8 + 2*(iByte%4), 2), System.Globalization.NumberStyles.HexNumber );														                                
                                }

                                if ( (iByte % 4) == 3 || (iLineByteCount < 4 && iByte == iLineByteCount-1) ) {
                                    bEEWordUsed[ iOutAddr/2 + iWord ] = true;
                                    ++iEEWordsUsed;
                                    ++iWord;
                                }
							}

                            /*for ( int iWord = 0; iWord < iWordCount; iWord++ ) {
								iEEMem[iOutAddr + iWord*2 + 0] = int.Parse( strLineData.Substring(iWord*8 + 0, 2), System.Globalization.NumberStyles.HexNumber );
								iEEMem[iOutAddr + iWord*2 + 1] = int.Parse( strLineData.Substring(iWord*8 + 2, 2), System.Globalization.NumberStyles.HexNumber );								
								bEEWordUsed[ iOutAddr/2 + iWord ] = true;
                                ++iEEWordsUsed;
							}*/
							                        
						// Config memory
						} else if ( pobjSettings.device.configCount > 0 && iAddress >= 0xF80000 && iAddress <= 0xF8000E) {	
							iOutAddr = iAddress - 0xF80000;
							
							for ( int iWord = 0; iWord < iWordCount; iWord++ ) {
								iConfigMem[iOutAddr + iWord*2 + 0] = int.Parse( strLineData.Substring(iWord*8 + 0, 2), System.Globalization.NumberStyles.HexNumber );
								iConfigMem[iOutAddr + iWord*2 + 1] = int.Parse( strLineData.Substring(iWord*8 + 2, 2), System.Globalization.NumberStyles.HexNumber );								
								bConfigWordUsed[iOutAddr/2 + iWord] = true;
                                ++iConfigWordsUsed;
							}	

                        // Unknown data
                        } else {
                            ++iUnknownData;
                            if ( iUnknownData < 5 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Unknown data found, " + iLineByteCount.ToString() + " bytes at 0x" + iAddress.ToString("X4"), iTabLevel) );
                            } else if ( iUnknownData == 5 ) {
                                OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "More unknown data...", iTabLevel) );
                            }
                        }
					
					// End Of File record
					} else if ( iLineRecordType == HexRecordType.EndOfFile ) {
							break;
					
					// Extended Linear Address Record
					// The two data bytes represent the upper 16 bits of the 32 bit address, when combined with the address of the 00 type record.
					} else if ( iLineRecordType == HexRecordType.ExtendedLinearAddress ) {
						iLineAddrHigh = ( int.Parse(strFileLine.Substring(9, 4), System.Globalization.NumberStyles.HexNumber) & 65535 );
					}
				}
			}

            textReader.Close();
		}// ParseHexFile16()


        //---------------------------------------------------------------------
		// ParseHexFile()
		//---------------------------------------------------------------------
		virtual public void ParseHexFile( clsParseSettings pobjSettings, bool pbForce, int iTabLevel, ref bool pbResult )
		{
			pbResult = false;
            return;
		}// ParseHexFile()


        //---------------------------------------------------------------------
		// SetGotoToBl()
		//---------------------------------------------------------------------
		public void SetGotoToBl( clsParseSettings pobjSettings, int iTabLevel )
		{           
            string strFamily = pobjSettings.device.family.name;
            
            
            //---------------------------------------------------------------------
		    // PIC16F
		    //---------------------------------------------------------------------            
            if ( strFamily == "PIC16F" ) {
                if ( bProgPageUsed[0] == true || bProgRowUsed[0] == true ) {
                    if ( pobjSettings.noGoto == false ) {
                        int iBootloaderStartAddress = GetBootloaderStartAddress( pobjSettings );
                        int iPCLATH = (iBootloaderStartAddress >> 11); 
                        
                        // Word 0: page select, PCLATH 3
                        if ( (iPCLATH & 1) == 0 ) {
                            iProgMem[0] = 0x8A; iProgMem[1] = 0x11; //bcf  PCLATH, 3
                        } else {                            
                            iProgMem[0] = 0x8A; iProgMem[1] = 0x15; //bsf  PCLATH, 3
                        }
                        
                        // Word 1: page select, PCLATH 4
                        if ( (iPCLATH & 2) == 0 ) {                            
                            iProgMem[2] = 0x0A; iProgMem[3] = 0x12; //bcf  PCLATH, 4
                        } else {                            
                            iProgMem[2] = 0x0A; iProgMem[3] = 0x16; //bsf  PCLATH, 4
                        }
                        
                        // Word 2: goto to bootloader
                        iProgMem[4] = (byte)(iBootloaderStartAddress & 0xFF);             //low address byte
                        iProgMem[5] = (byte)(0x28 + ((0x0700 & iBootloaderStartAddress) >> 8));  //goto instruction
                    }
                } else {
                    OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "Row/page 0 is not found in hex-file, goto at 0x00 is not written.", iTabLevel) );
                }
            

            //---------------------------------------------------------------------
		    // PIC18F  PIC18FJ
		    //---------------------------------------------------------------------            
            } else if ( strFamily == "PIC18F" || strFamily == "PIC18FJ" ) {
                if ( bProgPageUsed[0] == true || bProgRowUsed[0] == true ) {
                    if ( pobjSettings.noGoto == false ) {
                        int iBootloaderStartAddress = GetBootloaderStartAddress( pobjSettings ) / 2;
                        // First goto word
                        iProgMem[0] = (byte)(iBootloaderStartAddress & 0xFF);                //low address byte			
                        iProgMem[1] = 0xEF;                                                 //goto instruction
                        // Second goto word												
                        iProgMem[2] = (byte)((iBootloaderStartAddress & 0x00FF00) >> 8);	        //high address byte
                        iProgMem[3] = (byte)(0xF0/*goto instruction*/ + ((iBootloaderStartAddress & 0x0F0000) >> 16));	//goto instruction & upper address nibble
                    }
                } else {
                    OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "Row/page 0 is not found in hex-file, goto at 0x00 is not written.", iTabLevel) );
                }            
                
            //---------------------------------------------------------------------
		    // PIC24F  PIC24FJ  PIC24H  dsPIC30F  dsPIC33FJ
		    //---------------------------------------------------------------------            
            } else {
                if ( bProgPageUsed[0] == true || bProgRowUsed[0] == true ) {
                    if ( pobjSettings.noGoto == false ) {
                        int iBootloaderStartAddress = GetBootloaderStartAddress( pobjSettings );
				        // First goto word
				        iProgMem[0] = 0x04;												//goto instruction
				        iProgMem[1] = (byte)( (iBootloaderStartAddress & 0x0000FE) );			//low Address byte			
				        iProgMem[2] = (byte)( (iBootloaderStartAddress & 0x00FF00) >> 8 );		//high Address byte				
				        // Second goto word
				        iProgMem[3] = 0x00;												//not used by goto
				        iProgMem[4] = (byte)( (iBootloaderStartAddress & 0x7F0000) >> 16 );	//upper Address byte
				        iProgMem[5] = 0x00;												//not used by goto	
                    }
                } else {
                    OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.warning, "Row/page 0 is not found in hex-file, goto at 0x00 is not written.", iTabLevel) );
                }
            }
        }// SetGotoToBl()


        //---------------------------------------------------------------------
		// SizeBuffers()
		//---------------------------------------------------------------------
		public void SizeBuffers( 
            int piProgPageUsedBufferSize, int piProgRowUsedBufferSize, int piProgMemBufferSize, 
            int piEEWordsUsedBufferSize, int piEEMemBufferSize, 
            int piConfigWordsUsedBufferSize, int piConfigMemBufferSize 
        ) { 
			//bProgPageUsed = new bool[ piProgPageUsedBufferSize ];
            //bProgRowUsed = new bool[ piProgRowUsedBufferSize ];
            //iProgMem = new byte[ piProgMemBufferSize ];
            
            bProgPageUsed = new bool[ 16384 ];
            
            bProgRowUsed = new bool[ 16384 ];
            
            iProgMem = new byte[ 1000000 ];
			
			//bEEWordUsed = new bool[ piEEWordsUsedBufferSize ];			
			//iEEMem = new int[ piEEMemBufferSize ];
            bEEWordUsed = new bool[ 8192 ];			
			iEEMem = new int[ 16384 ];
			
			//bConfigWordUsed = new bool[ piConfigWordsUsedBufferSize ];
			//iConfigMem = new int[ piConfigMemBufferSize ];	
            bConfigWordUsed = new bool[ 16 ];
			iConfigMem = new int[ 32 ];	
        }// SizeBuffers()


        //---------------------------------------------------------------------
		// SwapGoto()
        // Description: swap user goto at 0x00 to bootloader usr:, se firmware code
        //              it´s important that this instruction is placed just before a new program row
		//---------------------------------------------------------------------
		public void SwapGoto( clsParseSettings pobjSettings, int piTabLevel )
		{           
            string strFamily = pobjSettings.device.family.name;

            //---------------------------------------------------------------------
		    // PIC16F
		    //---------------------------------------------------------------------            
            if ( strFamily == "PIC16F" ) {
                if ( pobjSettings.noGoto == false ) {
                    int iGotoUserAppAddress = GetBootloaderStartAddress( pobjSettings ) - 3;    //buffer index

                    bool bGotoFound = false;
                    bool bExpectedInstruction;
                    bool bPCLATH4=false, bPCLATH3=false, bMovlp=false;
                    int iBit;
                    int iGotoWord=0, iMovlpWord=0;

                    for ( int iWord = 0; iWord <= 2; iWord++ ) {
                        bExpectedInstruction = false;
                        
                        if ( (iProgMem[iWord*2+1] & 0x38) == 0x28 ) {           //goto
                            bExpectedInstruction = true;
                            bGotoFound = true;
                            iGotoWord = iWord;
                        
                        } else if ( (iProgMem[iWord*2+1] & 0x3C) == 0x14 ) {    //bsf                        
                            bExpectedInstruction = true;

                            iBit = ((iProgMem[iWord*2+1] & 0x3) << 1) + ((iProgMem[iWord*2+0] & 0x80) >> 7);
                            bPCLATH3 |= (iBit == 3);
                            bPCLATH4 |= (iBit == 4);
                        
                        } else if ( (iProgMem[iWord*2+1] & 0x3C) == 0x10 ) {    //bcf
                            bExpectedInstruction = true;

                            iBit = ((iProgMem[iWord*2+1] & 0x3) << 1) + ((iProgMem[iWord*2+0] & 0x80) >> 7);
                            bPCLATH3 &= !(iBit == 3);
                            bPCLATH4 &= !(iBit == 4);
                        
                        } else if (                                             //movlp
                            (iProgMem[iWord*2+1] & 0x3F) == 0x31 && 
                            (iProgMem[iWord*2+0] & 0x80) == 0x80 
                        ) {   
                            bExpectedInstruction = true;
                            iMovlpWord = iWord;
                        }

                        if ( bExpectedInstruction ) {
                            // Move to just before bootloader
                            iProgMem[ iGotoUserAppAddress*2 + iWord*2 + 0 ] = iProgMem[ iWord*2 + 0 ];
                            iProgMem[ iGotoUserAppAddress*2 + iWord*2 + 1 ] = iProgMem[ iWord*2 + 1 ];
                        }
                        
                        if ( bGotoFound ) {
                            break;
                        }
                    } 

                    if ( bGotoFound == false ) {
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.failed, "Goto in first three words not found", piTabLevel) );
                    }
                    
                    iUserAppAddress = 0;
                    if ( bPCLATH3 ) iUserAppAddress += ( 1<<11 );
                    if ( bPCLATH4 ) iUserAppAddress += ( 1<<12 );
                    if ( bMovlp ) iUserAppAddress += ( (iProgMem[iGotoWord*2] & 0x7f) << 11 );
                    iUserAppAddress += ((iProgMem[iGotoWord*2+1]&0x7)<<8) + iProgMem[iGotoWord*2];

                    bProgPageUsed[iGotoUserAppAddress / (pobjSettings.device.pageSizeR * pobjSettings.device.rowSizeW)] = true;
                    bProgRowUsed[iGotoUserAppAddress / (pobjSettings.device.rowSizeW)] = true;

                    if ( clsds30Loader.debugMode == true ) {                        
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Goto user app address: 0x" + iGotoUserAppAddress.ToString("X2"), piTabLevel) );
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "User app address: 0x" + iUserAppAddress.ToString("X2"), piTabLevel) );
                    }                   
                }
            

            //---------------------------------------------------------------------
		    // PIC18F  PIC18FJ
		    //---------------------------------------------------------------------            
            } else if ( strFamily == "PIC18F" || strFamily == "PIC18FJ" ) {
                if ( pobjSettings.noGoto == false ) {
                    int iGotoUserAppAddress = GetBootloaderStartAddress( pobjSettings ) - 4;    //buffer index
                    for ( int iIter = 0; iIter < 4; iIter++ ) {
                        iProgMem[iGotoUserAppAddress + iIter] = iProgMem[iIter];
                    }
                    bProgPageUsed[iGotoUserAppAddress / (pobjSettings.device.pageSizeR * pobjSettings.device.rowSizeW * 2)] = true;
                    bProgRowUsed[iGotoUserAppAddress / (pobjSettings.device.rowSizeW * 2)] = true;

                    iUserAppAddress = ((iProgMem[iGotoUserAppAddress+3]&0xf)<<16) + iProgMem[iGotoUserAppAddress];
                    if ( clsds30Loader.debugMode == true ) {                        
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Goto user app address: 0x" + iGotoUserAppAddress.ToString("X2"), piTabLevel) );
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "User app address: 0x" + iUserAppAddress.ToString("X2"), piTabLevel) );
                    }
                }
          
                
            //---------------------------------------------------------------------
		    // PIC24F  PIC24FJ  PIC24H  dsPIC30F  dsPIC33FJ
		    //---------------------------------------------------------------------            
            } else { 
                if ( pobjSettings.noGoto == false ) {
                    int iGotoUserAppAdress = GetBootloaderStartAddress( pobjSettings ) - 4;      
                    int iGotoUserAppAdressB3 = (iGotoUserAppAdress / 2) * 3;	//starting index in buffer

				    for ( int iIter = 0; iIter < 6; iIter++ ) {
					    iProgMem[ iGotoUserAppAdressB3 + iIter ] = iProgMem[ iIter ];
				    }
                    bProgPageUsed[iGotoUserAppAdress / (pobjSettings.device.pageSizeR * pobjSettings.device.rowSizeW * 2)] = true;
				    bProgRowUsed[ iGotoUserAppAdress / (pobjSettings.device.rowSizeW * 2) ] = true;

                    iUserAppAddress = (iProgMem[iGotoUserAppAdressB3+4]<<16) + (iProgMem[iGotoUserAppAdressB3+2]<<8) + iProgMem[iGotoUserAppAdressB3+1];
                    if ( clsds30Loader.debugMode == true ) {                        
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "Goto user app address: 0x" + iGotoUserAppAdress.ToString("X2"), piTabLevel) );
                        OnHexFileParse( new clsHexFileParseEventArgs(clsHexFileParseEventArgs.EventType.info, "User app address: 0x" + iUserAppAddress.ToString("X2"), piTabLevel) );
                    }
			    }
            }
        }// SwapGoto()


  		//---------------------------------------------------------------------
		// UpdateParsedSettings()
		//---------------------------------------------------------------------
        protected void UpdateParsedSettings( clsParseSettings pobjSettings )         
        {
            bIsParsed = true;
            objParsedSettings.CopyFrom( pobjSettings );
        }// UpdateParsedSettings()


        //---------------------------------------------------------------------
		// ValidateHexFile()
		// Description: validates an Intel hex-file
        //--------------------------------------------------------------------------
		// Hex-file format
		// : 10 8000 00 0800 fa00 000f 8001
		// | |  |    |  |-Data
		// | |  |    |----Line record type
		// | |  |---------Line address
		// | |------------Line byte count
		// |--------------Start code (just a simple colon)
		//---------------------------------------------------------------------
		public void ValidateHexFile( int iTabLevel, ref bool pbResult )
		{	
			OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.started, "Validating hexfile...", iTabLevel++ ) );
		    
			//--------------------------------------------------------------------------
			// Check file existense
			//--------------------------------------------------------------------------
			if ( strFilename == string.Empty || File.Exists(strFilename) == false) {
				OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "nonexisting file specified", -1) );
				pbResult = false;
                return;
			}
		    
		    
			//--------------------------------------------------------------------------
			// Create file reader object
			//--------------------------------------------------------------------------
		    TextReader textReader = new StreamReader( strFilename );
		    
		    
			//--------------------------------------------------------------------------
			// Check for an empty file
			//--------------------------------------------------------------------------
			if ( textReader.Peek() == -1 ) {
                OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "hex-file is empty", -1) );
				textReader.Close();
				pbResult = false;
                return;
			}
		    
		    
			//--------------------------------------------------------------------------
			// Do validation
			//--------------------------------------------------------------------------
			int iIter;            
            int iChecksum;
			string strInFileLine;
            int iLineNr;

            string strStartCode;
            int iLineByteCount;
			int iLineAddress;
            HexRecordType iLineRecordType;
			string strLineData;
            int iLineChecksum;			

            iLineNr = 0;
            while ( textReader.Peek() != -1 ) {
				strInFileLine = textReader.ReadLine();
                ++iLineNr;
                if ( strInFileLine.Length == 0 ) {
                    OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "line " + iLineNr.ToString() + " is empty", -1) );
				    textReader.Close();
				    pbResult = false;
                    return;                
                }
                strStartCode = strInFileLine.Substring(0, 1);


                //---------------------------------------------------------
                //
                //---------------------------------------------------------
				if ( strStartCode == ":" ) {	

				    //---------------------------------------------------------
                    // Parse the line
                    //---------------------------------------------------------
					try {
                        iLineByteCount = int.Parse( strInFileLine.Substring(1, 2), System.Globalization.NumberStyles.HexNumber );
					    iLineAddress = int.Parse( strInFileLine.Substring(3, 4), System.Globalization.NumberStyles.HexNumber ) & 65535;
                        iLineRecordType = (HexRecordType)int.Parse( strInFileLine.Substring(7, 2), System.Globalization.NumberStyles.HexNumber );
	                    strLineData = strInFileLine.Substring( 9, (iLineByteCount * 2) );
                        iLineChecksum = int.Parse( strInFileLine.Substring(9+(iLineByteCount*2), 2), System.Globalization.NumberStyles.HexNumber );
	                } catch {
                        OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "broken hex record on line " + iLineNr.ToString(), -1) );
						textReader.Close();
						pbResult = false;
                        return;                    
                    }

                    //---------------------------------------------------------
					// Check crc
                    //---------------------------------------------------------
                    iChecksum = 0;
                    int i8bitWords = (strInFileLine.Length-1-2) / 2;
					for ( iIter = 0; iIter < i8bitWords; iIter++ ) {
						iChecksum += int.Parse( strInFileLine.Substring((2 * iIter) + 1, 2), System.Globalization.NumberStyles.HexNumber ) & 0xFF;
					}           
					if ( ((iChecksum + iLineChecksum) & 0xff) != 0 ) {
                        OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "crc-error on line " + iLineNr.ToString(), -1) );
						textReader.Close();
						pbResult = false;
                        return;
					}

                    
                    //---------------------------------------------------------
					// End Of File record
                    //---------------------------------------------------------
					if ( iLineRecordType == HexRecordType.EndOfFile ) {
						break;

                    //---------------------------------------------------------
					// Unsupported hex record type?
                    //---------------------------------------------------------
                    } else if ( iLineRecordType != HexRecordType.ExtendedLinearAddress && iLineRecordType != HexRecordType.Data ) {
                        OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "Unsupported hex record type found: " + iLineRecordType.ToString(), iTabLevel+1) );
                    }


                //---------------------------------------------------------
                //This shouldn't happen(?)
                //---------------------------------------------------------
				} else if ( strStartCode == " " || strStartCode == "\t" || strStartCode == "\r" || strStartCode == "\n" ) {
                
                    
                //---------------------------------------------------------
                // Unknown starting character
                //---------------------------------------------------------
				} else {
                    OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "invalid start code: \"" + strStartCode + "\" on line " + iLineNr.ToString(), -1) );
					textReader.Close();
					pbResult = false;
                    return;
				}

		        
                //---------------------------------------------------------
                // End of file?
                //---------------------------------------------------------
				if ( textReader.Peek() == -1 ) {
                    OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.failed, "missing end of file record", -1) );
					textReader.Close();
					pbResult = false;
                    return;
				}
			} //while ( textReader.Peek() != -1 ) {
		    

            //            
            textReader.Close();

            //
            OnHexFileValidate( new clsHexFileValidateEventArgs(clsHexFileValidateEventArgs.EventType.success, "", -1) );		    
			pbResult = true;
            return;
		}// ValidateHexFile()
 
	}// Class: clsHex    
}
