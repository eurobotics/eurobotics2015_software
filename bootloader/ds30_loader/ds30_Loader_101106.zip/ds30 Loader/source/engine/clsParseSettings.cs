﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  

using System;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsParseSettings
	//-------------------------------------------------------------------------
	public class clsParseSettings
	{
 		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		public clsParseSettings()
		{
            device = null;
            fileTimestamp = new DateTime();
        }// Constructor()


 		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------
		public clsParseSettings( int plSizeP, clsDevice pobjDevice, bool pbIgnoreOverwrit, bool pbNoGoto, int piBlPlacementP, bool pbAddChecksum )
		{
            blSizeP = plSizeP;
            device = pobjDevice;
            allowBlOverwrite = pbIgnoreOverwrit;
            noGoto = pbNoGoto;
            blPlacementP = piBlPlacementP;
            addChecksum = pbAddChecksum;
        }// Constructor()


 		//---------------------------------------------------------------------
		// Properties
		//---------------------------------------------------------------------
		public int blSizeP { get; set; }                //size of bootloader [pages]
		public clsDevice device { get; set; }
		public DateTime fileTimestamp { get; set; }
		public bool allowBlOverwrite { get; set; }
		public bool noGoto { get; set; }
		public int blPlacementP { get; set; }
        public bool addChecksum { get; set; }
        

	    //---------------------------------------------------------------------
		// CompareTo()
        // Returns: true if equal, false if not equal
		//---------------------------------------------------------------------
		public bool CompareTo( clsParseSettings pobjSettings )
		{
            return (
                blSizeP == pobjSettings.blSizeP &&
                device == pobjSettings.device &&
                fileTimestamp == pobjSettings.fileTimestamp &&
                allowBlOverwrite == pobjSettings.allowBlOverwrite &&
                noGoto == pobjSettings.noGoto &&
                blPlacementP == pobjSettings.blPlacementP &&
                addChecksum == pobjSettings.addChecksum
            );
        }// CompareTo()


	    //---------------------------------------------------------------------
		// CopyFrom()
		//---------------------------------------------------------------------
		public void CopyFrom( clsParseSettings pobjSettings )
		{
            blSizeP = pobjSettings.blSizeP;
            device = pobjSettings.device;
            fileTimestamp = pobjSettings.fileTimestamp;
            allowBlOverwrite = pobjSettings.allowBlOverwrite;
            noGoto = pobjSettings.noGoto;
            blPlacementP = pobjSettings.blPlacementP;
            addChecksum = pobjSettings.addChecksum;
        }// CopyFrom()

	}// Class: clsParseSettings
}

