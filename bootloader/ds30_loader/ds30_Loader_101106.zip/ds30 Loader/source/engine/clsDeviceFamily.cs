﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  
using System.Collections;
using System.Xml;
using System.Xml.Serialization;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsDeviceFamily
	//-------------------------------------------------------------------------
    [XmlRoot("deviceFamily")]
    [XmlInclude(typeof(clsDeviceFamily))]
	public class clsDeviceFamily
	{
		//---------------------------------------------------------------------
		// Size suffixes
		//---------------------------------------------------------------------
		// R - rows
		// W - words
		// P - program counter units
		// B - bytes	
		
		
        //---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
		private Hashtable htDevices = null;

		
		//---------------------------------------------------------------------
		// Constructor()
        // Description: empty constructor required for serialization
		//---------------------------------------------------------------------	
		public clsDeviceFamily() 
		{
			htDevices = new Hashtable( 61 );

            name = "";

            pageSizeR = 0;
            rowSizeW = 0;

            pcuPerWord = 0;
            flashWordSizeBits = 0;
            eepromWordSizeB = 0;
            configWordSizeB = 0;
		}// Constructor()

        
        //---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public clsDeviceFamily( string pstrName, bool pbHasPages, int piPageSizeR, int piRowSizeW, int piPCUPerWord, int piFlashWordSizeB, int piFlashWordSizeBits, int piEepromWordSizeB, int piConfigWordSizeB ) 
		{
			name = pstrName;
            hasPages = pbHasPages;
			pageSizeR = piPageSizeR;
			rowSizeW = piRowSizeW;

            pcuPerWord = piPCUPerWord;
            flashWordSizeB = piFlashWordSizeB;
            flashWordSizeBits = piFlashWordSizeBits;
            eepromWordSizeB = piEepromWordSizeB;
            configWordSizeB = piConfigWordSizeB;
			
			htDevices = new Hashtable( 61 );
		}// Constructor()
		
		
		//---------------------------------------------------------------------
		// Properties
		//---------------------------------------------------------------------
		public string name { get; set; }
		public int configWordSizeB { get; set; }
        public int deviceCount { get{ return htDevices.Count;} }
		public int eepromWordSizeB { get; set; }
		public int flashWordSizeB { get; set;}
        public int flashWordSizeBits { get; set; }        
        public bool hasPages { get; set; }
		public int pageSizeR { get; set; }
		public int pcuPerWord { get; set; }
		public int rowSizeW { get; set; }

		private clsDevice[] lstDevices = null;
        public clsDevice[] devices { 
            get {
                lstDevices = new clsDevice[ htDevices.Count ];
                int iIndex = 0;
                foreach ( clsDevice objDevice in htDevices.Values ) {
                    lstDevices[iIndex++] = objDevice;
                }
                return lstDevices;
            }
            set {                
                lstDevices = value;
                htDevices.Clear();
                foreach ( clsDevice objDevice in lstDevices ) {
                    htDevices.Add( objDevice.id, objDevice );
                }
            }
        }
    
		          
		//---------------------------------------------------------------------
		// DeviceAdd()
		// Description: adds a device to this devicefamily
		//---------------------------------------------------------------------
		public void DeviceAdd( clsDevice pobjDevice, ref bool pbResult )
		{
			// Check for existence
			if ( DeviceExists( pobjDevice.id ) == true ) {
				pbResult = false;
                return;
			}
			
			//
			htDevices.Add( pobjDevice.id, pobjDevice );
			pbResult = true;
        }// DeviceAdd()   
		
		
		//---------------------------------------------------------------------
		// DeviceExists()
		// Description: checks if a devicename is added to this devicefamily
		//---------------------------------------------------------------------
		public bool DeviceExists( int piID )
		{
			return htDevices.Contains( piID );
        }// DeviceAdd() 
		
		
		//---------------------------------------------------------------------
		// DeviceGet()
		// Description: returns the device with the specified name if it exists
		//---------------------------------------------------------------------
		public clsDevice DeviceGet( string pstrDeviceName )
		{
			foreach ( clsDevice objDevice in htDevices.Values ) {
				if ( objDevice.name.ToLower() == pstrDeviceName.ToLower() ) {
					return objDevice;
				}
			}
			return null;
        }// DeviceGet()
        
                 
		//---------------------------------------------------------------------
		// DeviceGet()
		// Description: returns the device with the specified id if it exists
		//---------------------------------------------------------------------
		public clsDevice DeviceGet( int piID )
		{
			// Check for existence
			if ( DeviceExists(piID) == false ) {
				return null;
			}
			
			//
			return (clsDevice)htDevices[ piID ];
        }// DeviceGet()  
        		
		
		//---------------------------------------------------------------------
		// DevicesGet()
		// Description: returns devices hashtable
		//---------------------------------------------------------------------
		public Hashtable DevicesGet()
		{
			return htDevices;
        }// DevicesGet() 
        		
        
		//---------------------------------------------------------------------
		// UpdateChildren()
		// Description:
		//---------------------------------------------------------------------
		public void UpdateChildren()
		{
			foreach ( clsDevice objDevice in htDevices.Values ) {
                objDevice.SetParent( this );
            }
        }//UpdateChildren()
        
        		        
		//---------------------------------------------------------------------
		// ToString()
		// Description:
		//---------------------------------------------------------------------
		override public string ToString()
		{
			return name;
        }//ToString()
                		          
	}// Class: clsDeviceFamily
}
