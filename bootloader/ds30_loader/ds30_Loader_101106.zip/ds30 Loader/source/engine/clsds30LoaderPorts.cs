﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
  

using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;
using System.Collections;
using System.IO;

using System.Reflection;
using GHelper;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Enum: PortType
	//-------------------------------------------------------------------------
    public enum PortType { Serial, CAN };


	//-------------------------------------------------------------------------
	// Class: clsds30LoaderPorts
	//-------------------------------------------------------------------------
	static public class clsds30LoaderPorts
	{
        static private ArrayList lstPorts = null;
        static private Hashtable htPorts = null;
	      
        

		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
        static clsds30LoaderPorts()
        {
            lstPorts = new ArrayList( 11 );
            htPorts = new Hashtable( 11 );
        }// Constructor()


		//---------------------------------------------------------------------
		// Propery: ports
        // Description: returns an array with all available ports
		//---------------------------------------------------------------------	
        static public ArrayList ports
        {
            get {
                return lstPorts;
            }
        }// Propery: ports

        
        //---------------------------------------------------------------------
		// EnumPortPlugins()
        // Description: loads all port plugins and stores all available ports
		//---------------------------------------------------------------------	
		static private void EnumPortPlugins( string pstrPath, int piTabLevel ) 
        {
            string[] strPortPlugins = Directory.GetFiles( pstrPath, "ds30LoaderPort*.dll" );
            
            
            bool bOk;
            AssemblyName assemblyName = null;
            Assembly assembly = null;
            Type type = null;

            // Iterate available port plugins
            foreach ( string strPortPlugin in strPortPlugins ) {
                bOk = true;

                clsDebugTextbox.OutputInfo( "Loading port plugin " + Path.GetFileNameWithoutExtension(strPortPlugin) + ": ", piTabLevel );


                //-------------------------------------------------------------
                // Get assembly name
                //-------------------------------------------------------------
                if ( bOk == true ) {                    
                    try {
                        assemblyName = AssemblyName.GetAssemblyName( strPortPlugin );
                    } catch {   
                        bOk = false;
                        clsDebugTextbox.OutputError( "get assembly name ", piTabLevel );
                    }
                }

                //-------------------------------------------------------------
                // Load assembly
                //-------------------------------------------------------------
                if ( bOk == true ) {
                    try {
                        assembly = Assembly.Load( assemblyName );
                    } catch {
                        assembly = null;
                        clsDebugTextbox.OutputError( "load assembly ", piTabLevel );
                    }
                    if ( assembly == null ) {
                        bOk = false;
                    }
                }    
 
                //-------------------------------------------------------------
                // Debug
                //-------------------------------------------------------------
                /*Type[] types = null;
                if ( bOk == true ) {
                    types = assembly.GetTypes();
                    foreach ( Type typ in types ) {
                    }
                }*/
                    
                //-------------------------------------------------------------
                // Get port class type and add to list
                //-------------------------------------------------------------
				if ( bOk == true ) {
                    try {
                        type = assembly.GetType( "ds30Loader.cls" + Path.GetFileNameWithoutExtension(strPortPlugin) );
                    } catch {
                        type = null;
                        clsDebugTextbox.OutputError( "get type " );
                    }

                    if ( type == null ) {
                        bOk = false;
                    }
                }                               
                
                //-------------------------------------------------------------
                // Get available ports from static method GetPorts
                //-------------------------------------------------------------
                if ( bOk == true ) {
                    ArrayList lstLocalPorts = null;
                    
                    bool bGetPortsSuccess = false;
                    object[] objArgs = new object[] { bGetPortsSuccess};
                    try {                        
                        lstLocalPorts = (ArrayList)type.InvokeMember( "GetPorts", BindingFlags.InvokeMethod, null, null, objArgs );
                    } catch {
                        bOk = false;
                        lstLocalPorts = null;
                        clsDebugTextbox.OutputError( "invocation of GetPorts() " );
                    }
                    
                    bGetPortsSuccess = (bool)objArgs[0];

                    if ( bOk == true && bGetPortsSuccess == false ) {
                        clsDebugTextbox.OutputError( "GetPorts() reported fail  " );
                    
                    } else if ( bOk == true && bGetPortsSuccess == true && lstLocalPorts == null ) {
                        clsDebugTextbox.OutputError( "GetPorts() didn't return a valid list", piTabLevel );
                    
                    } else if ( bOk == true && bGetPortsSuccess == true && lstLocalPorts != null ) {
                        foreach ( string strPort in lstLocalPorts ) {
                            lstPorts.Add( strPort );
                            htPorts.Add( strPort, type );
                        }
                        clsDebugTextbox.OutputSuccess( "found " + lstLocalPorts.Count.ToString() + " ports" );
                    } else {
                        bOk = false;
                    }
                }
                
                if ( bOk == false ) {
                    clsDebugTextbox.OutputResult( false );
                }

            }
		}// EnumPortPlugins()

        
        //---------------------------------------------------------------------
		// GetPortObjectFromName()
        // Description: returns a port instance from a port name
		//---------------------------------------------------------------------	
		static public Ids30LoaderPort GetPortObjectFromName( string pstrPortName ) 
        {
            Ids30LoaderPort objPort = null;
            
            // Get type from name
            Type type = (Type)htPorts[ pstrPortName ];            
            
            // Unknown port name, return serial port
            if ( type == null ) {
                foreach ( Type typ in htPorts.Values ) {
                    if ( typ.Name.ToLower().Contains("serial") ) {
                        type = typ;
                    }
                }
            }

            // Instantiate the port class type
            try {
                objPort = (Ids30LoaderPort) Activator.CreateInstance( type );
            } catch ( Exception e ) {
                objPort = null;
                clsDebugTextbox.OutputError( "Port class instantiation failed: " + e.Message );
            }

            // Return port            
            return objPort;
		}// GetPortObjectFromName()


        //---------------------------------------------------------------------
		// Init()
		//---------------------------------------------------------------------	
		static public void Init( string pstrPath, int piTabLevel  ) 
        {
            EnumPortPlugins( pstrPath, piTabLevel );
		}// Init()

	}// Class: clsds30LoaderPorts
}
