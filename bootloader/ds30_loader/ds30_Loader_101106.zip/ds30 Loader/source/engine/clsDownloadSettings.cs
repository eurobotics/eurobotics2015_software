﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  


namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsDownloadSettings
	//-------------------------------------------------------------------------
	public class clsDownloadSettings
	{
        //---------------------------------------------------------------------
		// Default values
		//---------------------------------------------------------------------	
        public const int iPolltimeDefault = 100;
        public const int iTimeoutDefault = 5000;
        public const int iResetTimeDefault = 100;
        
        
        //---------------------------------------------------------------------
		// Constructor
        // Description: assign default values to all properties
		//---------------------------------------------------------------------
        public clsDownloadSettings() 
        {
            portName = string.Empty;
            baudRate = 9600;
            remoteId = 0;
            localId = 0;
            writeProgram = false;
            writeEeprom = false;

            writeConfigs = false;
            allowBlOverwrite = false;
            noGoto = false;
            customBl = false;
            customBlPlacementP = 0;
            customBlSizeP = 0;
            autoBaudrate = false;
            echoVerification = false;
            addChecksum = false;

            polltime = iPolltimeDefault;
            timeout = iTimeoutDefault;

            resetCommandSequence = string.Empty;
            resetBaudrate = 9600;
            resetDtr = false;
            resetRts = false;
            resetTime = iResetTimeDefault;

            activateDtr = false;
            activateRts = false;
        }


        //---------------------------------------------------------------------
		// Basic
		//---------------------------------------------------------------------
	    public string portName { get; set; }
        public int baudRate { get; set; }
        public uint remoteId { get; set; }
        public uint localId { get; set; }
        public bool writeProgram { get; set; }
        public bool writeEeprom { get; set; }

       	
		//---------------------------------------------------------------------
		// Advanced
		//---------------------------------------------------------------------
        public bool writeConfigs { get; set; }
		public bool allowBlOverwrite { get; set; }
        public bool noGoto { get; set; }
		public bool customBl { get; set; }
		public int customBlPlacementP { get; set; }
		public int customBlSizeP { get; set; }
		public bool autoBaudrate { get; set; }
        public bool echoVerification { get; set; }
        public bool addChecksum { get; set; }


		//---------------------------------------------------------------------
		// Timing
		//---------------------------------------------------------------------
        public int polltime { get; set; }
       	public int timeout { get; set; }
        

        //---------------------------------------------------------------------
		// Reset
		//---------------------------------------------------------------------
        public bool resetCommand { get; set; }
        public string resetCommandSequence { get; set; }
        public int resetBaudrate { get; set; }
		public bool resetDtr { get; set; }
        public bool resetRts { get; set; }
		public int resetTime { get; set; }


		//---------------------------------------------------------------------
		// Activation 
		//---------------------------------------------------------------------
		public bool activateDtr { get; set; }
        public bool activateRts { get; set; }

	}// Class: clsDownloadSettings
}