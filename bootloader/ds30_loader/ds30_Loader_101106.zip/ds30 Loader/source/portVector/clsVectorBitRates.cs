﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------------------------------------------------------  

using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using GHelper;


namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: clsVectorBitRates
	//-------------------------------------------------------------------------
	static public class clsVectorBitRates
	{
		//---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------
		static private Hashtable htBitRates = null;
        static private bool bIsInitialized = false;
        static public ArrayList lstBitRates = null;

        		
        //---------------------------------------------------------------------
		// Constructor()
		// Description:
		//---------------------------------------------------------------------
		static clsVectorBitRates()
		{   
        }// Constructor()	  		

        		
        //---------------------------------------------------------------------
		// Init()
		// Description:
		//---------------------------------------------------------------------
		static public void Init()
		{   
            if ( bIsInitialized == true ) return;

            bool bImportDbSuccess = false;
            ImportDB( "vectorBitRates.xml", ref bImportDbSuccess );
            if ( bImportDbSuccess == false ) {
                InitInternalDb();
            }

            //
            lstBitRates = new ArrayList( htBitRates.Count );
            foreach ( clsVectorBitRate objVectorBitRate in htBitRates.Values ) {
                lstBitRates.Add( (int)objVectorBitRate.bitRate );
            }
            
            bIsInitialized = true;
        }// Constructor()	

        
        //-------------------------------------------------------------------------
		// ExportDB()
		// Description: 
		//-------------------------------------------------------------------------
		static public void ExportDB( string pstrFileName )
		{	            
            // 
            clsVectorBitRate[] lstBitRates = new clsVectorBitRate[ htBitRates.Count ];
            int iIndex = 0;
            foreach ( clsVectorBitRate objVectorBitRate in htBitRates.Values ) {
                lstBitRates[iIndex++] = objVectorBitRate;
            }           
            
            XmlSerializer xmlSerializer = new XmlSerializer( typeof(clsVectorBitRate[]) );
            TextWriter textWriter = new StreamWriter( pstrFileName );

            xmlSerializer.Serialize( textWriter, lstBitRates );
            textWriter.Close();
		}//ExportDB()  

        
        //-------------------------------------------------------------------------
		// GetBitRate()
		// Description: 
		//-------------------------------------------------------------------------
		static public clsVectorBitRate GetBitRate( int piBitRate )
		{	 
            string strBitRate = piBitRate.ToString();
            if ( htBitRates.Contains(strBitRate) ) {
                return (clsVectorBitRate)htBitRates[ strBitRate ];
            }

            return null;
		}//ExportDB()  

        
        //-------------------------------------------------------------------------
		// ImportDB()
		// Description: 
		//-------------------------------------------------------------------------
		static private void ImportDB( string pstrFileName, ref bool pbSuccess )
		{	
            pbSuccess = false;
            // Check file existence
            if ( File.Exists(pstrFileName) == false ) {
                return;
            }

            clsDebugTextbox.OutputInfo( "Loading external Vector bit rates database...", 0 );
            
            // Setup serialization objects
            XmlSerializer xmlSerializer = new XmlSerializer( typeof(clsVectorBitRate[]) );               
            TextReader textReader = new StreamReader( pstrFileName );
            clsVectorBitRate[] lstObjBitRates = null;

            // Serialize
            try {                
                lstObjBitRates = (clsVectorBitRate[])xmlSerializer.Deserialize( textReader );
            } catch {
                clsDebugTextbox.OutputResult( false );
                textReader.Close();
                return;
            } finally {
                textReader.Close();
            }

            // Apply
            htBitRates = new Hashtable( lstObjBitRates.Length );
            if ( lstObjBitRates != null ) {
                foreach ( clsVectorBitRate objVectorBitRate in lstObjBitRates ) {
                    htBitRates.Add( objVectorBitRate.bitRate.ToString(), objVectorBitRate );
                }
            }

            //
            pbSuccess = true;
            clsDebugTextbox.OutputResult( true );
		}//ImportDB()  
        
        
        //---------------------------------------------------------------------
		// InitInternalDb()
		// Description: 
		//---------------------------------------------------------------------
		static public void InitInternalDb()
		{
            htBitRates = new Hashtable( 11 );

            htBitRates.Clear();
            clsVectorBitRate objBitRate = null;
            objBitRate = new clsVectorBitRate( 1000000, 1, 8, 7, 1 ); htBitRates.Add( objBitRate.bitRate.ToString(), objBitRate );
        }// InitInternalDb()  

    }// Class: clsVectorBitRates
}
