﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
using System;

namespace ds30Loader
{

	//-------------------------------------------------------------------------
	// Class: clsVectorBitRate
	//-------------------------------------------------------------------------
	public class clsVectorBitRate
	{
        //---------------------------------------------------------------------
		// Constructor
		//---------------------------------------------------------------------	
        public clsVectorBitRate() 
        {
        }// Constructor

        
        //---------------------------------------------------------------------
		// Constructor
		//---------------------------------------------------------------------	
        public clsVectorBitRate( uint pbitRate, byte psjw, byte ptseg1, byte ptseg2, byte psam ) 
        {
            bitRate = pbitRate;
            sjw = psjw;
            tseg1 = ptseg1;
            tseg2 = ptseg2;
            sam = psam;
        }// Constructor


        //---------------------------------------------------------------------
		// Properties
		//---------------------------------------------------------------------	
        public uint bitRate { get; set; }
        public byte sjw { get; set; }
        public byte tseg1 { get; set; }
        public byte tseg2 { get; set; }
        public byte sam { get; set; }

	}// Class: clsVectorBitRate
}
