﻿//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using vxlapi_NET20;

namespace ds30Loader
{
	//-------------------------------------------------------------------------
	// Class: frmds30LoaderPortVector
	//-------------------------------------------------------------------------
    public partial class frmds30LoaderPortVector : Form
    {
        private clsds30LoaderPortVector objParentPort = null;
        private XLDriver objXLDriver = null;		
        private uint iChannelIndex = 255;
        private XLClass.xl_driver_config objDriverConfig = null;

        
        //---------------------------------------------------------------------
		// Constructor
		//---------------------------------------------------------------------
        public frmds30LoaderPortVector( clsds30LoaderPortVector pobjParentPort, XLDriver pobjXLDriver, uint piChannelIndex )
        {
            InitializeComponent();
            
            objParentPort = pobjParentPort;
            objXLDriver = pobjXLDriver;
            iChannelIndex = piChannelIndex;
            
            // SJW
            objDriverConfig = new XLClass.xl_driver_config();
            XLClass.XLstatus iGetDriverConfigResult = objXLDriver.XL_GetDriverConfig( ref objDriverConfig ); 
            if ( iGetDriverConfigResult == XLClass.XLstatus.XL_SUCCESS && objDriverConfig != null ) {
                cboSJW.SelectedIndex = objDriverConfig.channel[iChannelIndex].busParams.sjw - 1;
            } else {
                MessageBox.Show( "Failed to retrieve driver config.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
            }     
       
            // 
            chkDebugMode.Checked = objParentPort.debugMode;
            lblVersion.Text = clsds30LoaderPortVector.strVersion;

            cboDlc.Items.Add( "1" );
            cboDlc.Items.Add( "8" );
            cboDlc.Text = objParentPort.txDlc.ToString();
        }// Constructor
        

		//---------------------------------------------------------------------
		// Apply
        // Description: update SJW
		//---------------------------------------------------------------------
        private void Apply()
        {
            /*if ( objDriverConfig != null ) {
                 objDriverConfig.channel[iChannelIndex].busParams.sjw = (byte)(cboSJW.SelectedIndex + 1);
            }*/
            try {
                objParentPort.txDlc = int.Parse( cboDlc.Text );
            } catch {
                MessageBox.Show( "Failed to parse Tx DLC. DLC is " + objParentPort.txDlc.ToString() );
            }
        }// Apply


		//---------------------------------------------------------------------
		// btnClose_Click
		//---------------------------------------------------------------------
        private void btnClose_Click(object sender, EventArgs e)
        {
            //
            Apply();

            // Save settings
            clsSettingsPortVector objSettings = new clsSettingsPortVector();
            objSettings.txDLC = objParentPort.txDlc;
            objParentPort.SaveSettings( objSettings );

            //
            this.Close();
        }// btnClose_Click


		//---------------------------------------------------------------------
		// btnVector_Click
		//---------------------------------------------------------------------
        private void btnVector_Click(object sender, EventArgs e)
        {
            if ( objXLDriver != null ) {
                objXLDriver.XL_PopupHwConfig();
            }
        }// btnClose_Click


		//---------------------------------------------------------------------
		// chkDebugMode_CheckedChanged
        // Description: toggle debug mode
		//---------------------------------------------------------------------
        private void chkDebugMode_CheckedChanged(object sender, EventArgs e)
        {
            objParentPort.debugMode = chkDebugMode.Checked;
        }// chkDebugMode_CheckedChanged
    }
}
