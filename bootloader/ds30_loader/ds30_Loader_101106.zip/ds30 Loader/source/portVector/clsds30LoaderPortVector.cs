﻿//-----------------------------------------------------------------------------
//
// Title:			ds30 Loader
//
// Copyright:		Copyright © 2010, Mikael Gustafsson
//
// Version:			1.0.1 october 2010
//
// Link:			http://mrmackey.no-ip.org/elektronik/ds30loader/
//
// History:			1.0.1 Bugfix: ReadText() fixed
//                        Change: default dlc is changed from 8 to 1
//                  1.0.0 Improvement: Proper close of driver when open fails
//                        Bugfix: corrected parameter for 1Mbit
//                        Bugfix: tx dlc setting is remebered
//                  0.9.2 Fixed filtering
//                  0.9.1 Added ReadText()
//                  0.9.0 Initial release
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//    This file is part of ds30 Loader.
//
//    ds30 Loader is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation.
//
//    ds30 Loader is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with ds30 Loader.  If not, see <http://www.gnu.org/licenses/>.
//----------------------------------------------------------------------------- 
  

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

using vxlapi_NET20;

using GHelper;
using ds30Loader;

namespace ds30Loader
{

	//-------------------------------------------------------------------------
	// Class: clsds30LoaderPortVector
	//-------------------------------------------------------------------------
	public class clsds30LoaderPortVector : clsPortBase, IPort, IPortCAN
	{
        //---------------------------------------------------------------------
		// Variables
		//---------------------------------------------------------------------	
        private int                         iBaudRate           = 0;
        private string                      strPortName         = string.Empty;
        private Boolean                     bIsOpen             = false;
        private Hashtable                   htPortNames         = null;             //channel name as key, index as value
        private bool                        bValidPortName      = false;
        private Queue                       queRx               = null;
        private int                         iOutBufferCount     = 0;

        private XLDriver                    objXLDriver         = null;
        private XLClass.xl_driver_config    objDriverConfig     = null;
        private XLClass.XLbusTypes          busType             = XLClass.XLbusTypes.XL_BUS_TYPE_CAN;
        private uint                        flags               = 0;
        private int                         portHandle          = -1;
        private int                         eventHandle         = -1;
        private UInt64                      accessMask          = 0;
        private UInt64                      permissionMask      = 0;
        private UInt64                      txMask              = 0;
        private uint                        iChannelIndex       = 0;
        private Thread                      trdRx               = null; 
        private const string                strAppName          = "ds30Loader";
        static public string                strVersion          = "1.0.1";

        [DllImport("kernel32.dll", SetLastError=true)] 
        static extern int WaitForSingleObject(int handle, int timeOut);

        private enum WaitResults : int
        {
            WAIT_OBJECT_0   = 0x0,
            WAIT_ABANDONED  = 0x80,
            WAIT_TIMEOUT    = 0x102,
            INFINITE        = 0xFFFF,
            WAIT_FAILED     = 0xFFFFFFF
        }

		
		//
		//public delegate void DataReceivedDelegate( object sender, EventArgs e );
		public event clsPortBase.DataReceivedDelegate DataReceived;


		//---------------------------------------------------------------------
		// Constructor()
		//---------------------------------------------------------------------	
		public clsds30LoaderPortVector() 
		{
            Init();
            clsVectorBitRates.Init();

            // Load settings first
            bool bLoadSettingsResult = false;
            clsSettingsPortVector objSettings = clsds30LoaderPortVector.LoadSettings( ref bLoadSettingsResult );
            if ( bLoadSettingsResult == false ) {
                objSettings = new clsSettingsPortVector();
            }
            
            // Apply settings
            txDlc = objSettings.txDLC;
		}// Constructor()

        
        //---------------------------------------------------------------------
        // Constructor()
        //---------------------------------------------------------------------	
        public clsds30LoaderPortVector( string pstrPortname, int piBaudrate )
        {
            Init();

            Setup( pstrPortname, piBaudrate );
        }// Constructor()
	

		//---------------------------------------------------------------------
		// Destructor()
		//---------------------------------------------------------------------	
        ~clsds30LoaderPortVector() 
		{
            // Close port
            Close();

            // Close driver
            objXLDriver.XL_CloseDriver();
		}// Destructor()
		
        
		//---------------------------------------------------------------------
		// Event: DataReceived
		//---------------------------------------------------------------------
		protected internal void OnDataReceived()
		{
			// ChangedEvent will be null if no client has hooked up a delegate to the event.
			if ( DataReceived != null ) {
				DataReceived( this, null );
			}
		}//Event: ChangesMade	


		//---------------------------------------------------------------------
		// Property: allowCustomBaudRate
		//---------------------------------------------------------------------
		public bool allowCustomBaudRate
		{
			get {
				return false;
			} set {
			}
        }//Property: allowCustomBaudRate 	 
        
        
        //---------------------------------------------------------------------
		// Property: baudrate
		//---------------------------------------------------------------------
		public int baudrate
		{
			get {
				return iBaudRate;
			} set {
                if ( isOpen == true ) {
                    throw new Exception( "Port is open" );
                }
				iBaudRate = value;
			}
        }//Property: baudrate 	 
        

 		//---------------------------------------------------------------------
		// Property: debugMode
		//---------------------------------------------------------------------
		public bool debugMode{ get; set; }
  

		//---------------------------------------------------------------------
		// Property: dtrEnable
		//---------------------------------------------------------------------
		public bool dtrEnable{ get; set; }
          
   
		//---------------------------------------------------------------------
		// Property: echoVerification
		//---------------------------------------------------------------------
		public bool echoVerification { get; set; }
            		

		//---------------------------------------------------------------------
		// Property: hasWindow
		//---------------------------------------------------------------------
		public bool hasWindow
		{
			get {
				return true;
			}
        }//Property: hasWindow


		//---------------------------------------------------------------------
		// Property: inBufferCount
		//---------------------------------------------------------------------
		public int inBufferCount
		{
			get {
				return queRx.Count;
			}
        }//Property: inBufferCount        		
		
		
		//---------------------------------------------------------------------
		// Property: isOpen
		//---------------------------------------------------------------------
		public bool isOpen
		{
			get {
				return bIsOpen;
			}
        }//Property: isOpen              		
            		

		//---------------------------------------------------------------------
		// Property: localID
		//---------------------------------------------------------------------
		public uint localID { get; set; }


		//---------------------------------------------------------------------
		// Property: outBufferCount
		//---------------------------------------------------------------------
		public int outBufferCount
		{
			get {
				return iOutBufferCount;
			}
        }//Property: outBufferCount  
        
        		
		//---------------------------------------------------------------------
		// Property: portName
		//---------------------------------------------------------------------
		public string portName
		{
			get {
                return strPortName;
            }
			set {
                if ( isOpen == true ) {
                    throw new Exception( "Port is open" );
                }
                string strPortName = value;

                if ( htPortNames.Contains(strPortName.ToLower()) == false ) {
                    bValidPortName = false;
                    return;
                }

                iChannelIndex = (uint)htPortNames[strPortName.ToLower()];
                accessMask = permissionMask = txMask = objDriverConfig.channel[iChannelIndex].channelMask;

                if ( debugMode ) {
                    clsDebugTextbox.OutputInfo( "Port name set to " + value, 0 );
                    clsDebugTextbox.OutputInfo( "Accessmask: " + accessMask.ToString(), 1 );
                }
                strPortName = value;
                bValidPortName = true;
            }
        }//Property: portName        
 

        //---------------------------------------------------------------------
        // Property: portType
        //---------------------------------------------------------------------
        public PortType portType { 
            get {
                return PortType.CAN;
            }
        }// Property: portType
            		

		//---------------------------------------------------------------------
		// Property: remoteID
		//---------------------------------------------------------------------
		public uint remoteID { get; set; }
  

		//---------------------------------------------------------------------
		// Property: rtsEnable
		//---------------------------------------------------------------------
		public bool rtsEnable{ get; set; }
  

		//---------------------------------------------------------------------
		// Property: supportsWindows
		//---------------------------------------------------------------------
		new public static bool supportsWindows{ get {return true;} }
  

		//---------------------------------------------------------------------
		// Property: supportsLinux
		//---------------------------------------------------------------------
		new public static bool supportsLinux{ get {return false;} }
  

		//---------------------------------------------------------------------
		// Property: supportsMac
		//---------------------------------------------------------------------
		new public static bool supportsMac{ get {return false;} }
  

		//---------------------------------------------------------------------
		// Property: txDlc
		//---------------------------------------------------------------------
		public int txDlc{ get; set; }
	        
   
		//---------------------------------------------------------------------
		// Property: version
		//---------------------------------------------------------------------
		public string version
		{
			get {
				return strVersion;
			}	
        }//Property: version 
		

        //---------------------------------------------------------------------
        // Close()
        //---------------------------------------------------------------------	
        public bool Close()
        {
		    // Stop RX thread
            if ( trdRx != null ) {
                trdRx.Abort();
                trdRx = null;
            }
            
            if ( isOpen == false ) {
                return !bIsOpen;
            }

            XLClass.XLstatus iClosePortResult = objXLDriver.XL_ClosePort( portHandle );
            
            bIsOpen = !(iClosePortResult == XLClass.XLstatus.XL_SUCCESS);
            if ( debugMode ) clsDebugTextbox.OutputInfo( "Close() = " + iClosePortResult.ToString(), 0 );


            queRx.Clear();

            return ( !bIsOpen );
        }// Close()  


		//---------------------------------------------------------------------
		// EchoClearQueue()
		//---------------------------------------------------------------------	
		public void EchoClearQueue() 
		{
		}// EchoRead()


		//---------------------------------------------------------------------
		// EmptyBuffers()
		//---------------------------------------------------------------------	
		public void EmptyBuffers( bool bRx, bool bTx ) 
		{			
		}// EmptyBuffers()


        //---------------------------------------------------------------------
        // Init()
        //---------------------------------------------------------------------
        private bool Init()
        {
            ResetCounters();
            htPortNames = new Hashtable( 11 );
            queRx = new Queue( 11 );

            debugMode = false;

            localID = 0x7ff;
            remoteID = 1;
            txDlc = 1;


            //-----------------------------------------------------------------
            // Create driver object
            //-----------------------------------------------------------------
            try {                
                objXLDriver = new XLDriver();
            } catch {
                return false;                
            }

            //-----------------------------------------------------------------
            // Open driver
            //-----------------------------------------------------------------
            {
                XLClass.XLstatus iOpenDriverResult = objXLDriver.XL_OpenDriver();
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Init() XL_OpenDriver() = " + iOpenDriverResult.ToString(), 0 );
                if ( iOpenDriverResult != XLClass.XLstatus.XL_SUCCESS ) {
                    return false;
                }

            }

            //-----------------------------------------------------------------
            // Get driver configuration
            //-----------------------------------------------------------------
            {
                objDriverConfig = new XLClass.xl_driver_config();
                XLClass.XLstatus iGetDriverConfigResult = objXLDriver.XL_GetDriverConfig( ref objDriverConfig );
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Init() XL_GetDriverConfig() = " + iGetDriverConfigResult.ToString(), 0 );
                if ( iGetDriverConfigResult != XLClass.XLstatus.XL_SUCCESS ) {
                    return false;
                }
            }

            //-----------------------------------------------------------------
            // Create one application for each channel
            //-----------------------------------------------------------------
            {
                XLClass.xl_channel_config objChannelConfig = null;
                for ( uint iIter = 0; iIter < objDriverConfig.channelCount; iIter++ ) {
                    objChannelConfig = objDriverConfig.channel[iIter];
                    XLClass.XLstatus iResult  = objXLDriver.XL_SetApplConfig( 
                        strAppName, 
                        iIter, 
                        objChannelConfig.hwType, 
                        objChannelConfig.hwIndex, 
                        objChannelConfig.hwChannel,
                        objChannelConfig.busParams.busType
                    );
                    if ( debugMode ) clsDebugTextbox.OutputInfo( "Init() XL_SetApplConfig() = " + iResult.ToString(), 0 );

                    string strPortName =  objDriverConfig.channel[iIter].name.ToLower().Trim( new char[] {'\0'});
                    htPortNames.Add( strPortName, iIter );
                }
            }

            //-----------------------------------------------------------------
            // Create application if not existing
            //-----------------------------------------------------------------
            {
                /*XLClass.XLstatus iResult = objXLDriver.XL_GetApplConfig( strAppName, 0, ref hwType, ref hwIndex, ref hwChannel, busType );
                XLClass.XLstatus iResult2 = objXLDriver.XL_GetApplConfig( strAppName, 1, ref hwType, ref hwIndex, ref hwChannel, busType );
                if ( iResult != XLClass.XLstatus.XL_SUCCESS || iResult2 != XLClass.XLstatus.XL_SUCCESS  ) {
                    iResult  = objXLDriver.XL_SetApplConfig( strAppName, 0, (int)XLClass.XLhwTypes.XL_HWTYPE_CANCASEXL, 0, 0, (int)XLClass.XLbusTypes.XL_BUS_TYPE_CAN );
                    iResult2 = objXLDriver.XL_SetApplConfig( strAppName, 1, (int)XLClass.XLhwTypes.XL_HWTYPE_CANCASEXL, 0, 0, (int)XLClass.XLbusTypes.XL_BUS_TYPE_CAN );
                    //xlPrintAssignError();
                }*/
            }

            
            return true;
        }// Init()
		
        
        //-------------------------------------------------------------------------
        // LoadSettings()
        // Description: 
        //-------------------------------------------------------------------------
        static public clsSettingsPortVector LoadSettings( ref bool pbResult ) 
        {
            pbResult = true;
            clsSettingsPortVector objSettings = null;

            //-----------------------------------------------------------------
			// Filename
            //-----------------------------------------------------------------			
            string strPath = Application.StartupPath;
			string strFilename = strPath + Path.DirectorySeparatorChar + "settingsPortVector.xml";


			//-----------------------------------------------------------------
			// No previous settings
			//-----------------------------------------------------------------
			if ( File.Exists(strFilename) == false ) {
                objSettings = new clsSettingsPortVector();

			
			//-----------------------------------------------------------------
			// Load settings
			//-----------------------------------------------------------------            
            } else {            
                //clsDebugTextbox.OutputInfo( "Loading serial port settings...", 0 );

                XmlSerializer xmlSerializer = new XmlSerializer( typeof( clsSettingsPortVector ) );
                TextReader textReader = new StreamReader( strFilename );
                bool bLoadSettingsFailed = false;
                try {                
                    objSettings = (clsSettingsPortVector)xmlSerializer.Deserialize( textReader );
                } catch {
                    clsDebugTextbox.OutputResult( false );
                    objSettings = new clsSettingsPortVector();
                    bLoadSettingsFailed = true;

                }
                if ( textReader != null ) {
                    textReader.Close();
                }
                if ( bLoadSettingsFailed == false ) {
                    //clsDebugTextbox.OutputResult( true );
                }
            } 


			//-----------------------------------------------------------------
			// Finished
			//-----------------------------------------------------------------
            pbResult = ( objSettings != null );
            return objSettings;
		}//LoadSettings()

        
        //---------------------------------------------------------------------
        // GetBaudRates()
        // Description: enumerates available baud rates
        //---------------------------------------------------------------------	
        public ArrayList GetBaudRates()
        {
            return clsVectorBitRates.lstBitRates;
        }// GetBaudRates()


        //---------------------------------------------------------------------
        // GetPorts()
        // Description: enumerates available ports
        //---------------------------------------------------------------------	
        static public ArrayList GetPorts( ref bool pbSuccess )
        {
            pbSuccess = false;
            ArrayList lstPorts = new ArrayList( 11 );   
            string strPortName;

            //
            try {
                // Create driver object
                XLDriver objXLDriver = new XLDriver();

                // Open driver
                XLClass.XLstatus iOpenDriverResult = objXLDriver.XL_OpenDriver();
                if ( iOpenDriverResult != XLClass.XLstatus.XL_SUCCESS ) {
                    return null;
                }

                // Get driver config
                XLClass.xl_driver_config objDriverConfig = new XLClass.xl_driver_config();
                XLClass.XLstatus iGetDriverConfigResult = objXLDriver.XL_GetDriverConfig( ref objDriverConfig );
                if ( iGetDriverConfigResult != XLClass.XLstatus.XL_SUCCESS ) {
                    return null;
                }
                
                // Add channels
                for ( int i = 0; i < objDriverConfig.channelCount; i++ ) {                    
                    //strPortName = "Vector hw" + objDriverConfig.channel[i].hwIndex.ToString() + " ch" + (i+1).ToString();
                    strPortName = objDriverConfig.channel[i].name.Trim( new char[] {'\0'});
                    lstPorts.Add( strPortName );

                    
                    /*if ( false ) {
                        clsDebugTextbox.OutputInfo( strPortName, 0);
                        clsDebugTextbox.OutputInfo("Channel Mask: " + objDriverConfig.channel[i].channelMask, 1);
                        clsDebugTextbox.OutputInfo("Transceiver Name: " + objDriverConfig.channel[i].transceiverName, 1);
                        clsDebugTextbox.OutputInfo("Serial Number: " + objDriverConfig.channel[i].serialNumber, 1);
                        clsDebugTextbox.OutputInfo("", 1);
                    }*/
                }

                // Close driver
                objXLDriver.XL_CloseDriver();
            } catch {
                return null;
            }

            pbSuccess = true;
            return lstPorts;
        }// GetPorts()


        //---------------------------------------------------------------------
        // Open()
        //---------------------------------------------------------------------	
        public bool Open()        
        {
            if ( isOpen == true || bValidPortName == false ) {
                return bIsOpen;
            }

		    //-----------------------------------------------------------------
		    // Open port
		    //-----------------------------------------------------------------
            {
                XLClass.XLstatus iOpenPortResult = objXLDriver.XL_OpenPort(
                    ref portHandle, 
                    strAppName,
                    accessMask, 
                    ref permissionMask, 
                    32,
                    (int)XLClass.XLmessageFlags.XL_INTERFACE_VERSION, 
                    (uint)busType
                );
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Open() XL_OpenPort() = " + iOpenPortResult.ToString(), 0 );
                if ( iOpenPortResult != XLClass.XLstatus.XL_SUCCESS ) return false;
                bIsOpen = true;

                // See if we got init access
                if ( (permissionMask & accessMask) == 0 ) {
                    clsDebugTextbox.OutputError( "Init access not granted.", 0 );
                    //return false;
                }
            }

		    //-----------------------------------------------------------------
		    // Close filter
		    //-----------------------------------------------------------------
            {
                // Close filters first, open by default
                XLClass.XLstatus iFilterResult = objXLDriver.XL_CanSetChannelAcceptance(
                    portHandle,
                    accessMask,
                    0xfff,
                    0xfff,
                    XLClass.XLacceptanceFilter.XL_CAN_STD
                );
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Open() XL_CanSetChannelAcceptance() = " + iFilterResult.ToString(), 0 );
                if ( iFilterResult != XLClass.XLstatus.XL_SUCCESS ) {
                    Close();
                    return false;
                }
            }
 
		    //-----------------------------------------------------------------
		    // Open filter for local ID
		    //-----------------------------------------------------------------
            {
                // Close filters first, open by default
                XLClass.XLstatus iFilterResult = objXLDriver.XL_CanAddAcceptanceRange(
                    portHandle,
                    accessMask,
                    localID,
                    localID
                );
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Open() XL_CanAddAcceptanceRange() = " + iFilterResult.ToString(), 0 );
                if ( iFilterResult != XLClass.XLstatus.XL_SUCCESS )  {
                    Close();
                    return false;
                }
            }

		    //-----------------------------------------------------------------
		    // Set birate
		    //-----------------------------------------------------------------
            {
                clsVectorBitRate objBitRate = clsVectorBitRates.GetBitRate( baudrate  );

                if ( objBitRate != null ) {
                    XLClass.xl_chip_params objParams = new XLClass.xl_chip_params();
                    objParams.bitrate = objBitRate.bitRate;
                    objParams.sjw = objBitRate.sjw;
                    objParams.tseg1 = objBitRate.tseg1;
                    objParams.tseg2 = objBitRate.tseg2;
                    objParams.sam = objBitRate.sam;

                    XLClass.XLstatus iCanSetChannelParamsResult = objXLDriver.XL_CanSetChannelParams(
                        portHandle, 
                        accessMask, 
                        objParams
                    ); 
                    if ( debugMode ) clsDebugTextbox.OutputInfo( "Open() XL_CanSetChannelParams() = " + iCanSetChannelParamsResult.ToString(), 0 );                
                    if ( iCanSetChannelParamsResult != XLClass.XLstatus.XL_SUCCESS )  {
                        Close();
                        return false;
                    }
                } else {
                    XLClass.XLstatus iCanSetChannelBitrateResult = objXLDriver.XL_CanSetChannelBitrate(
                        portHandle, 
                        accessMask, 
                        (uint)baudrate
                    ); 
                    if ( debugMode ) clsDebugTextbox.OutputInfo( "Open() XL_CanSetChannelBitrate() = " + iCanSetChannelBitrateResult.ToString(), 0 );                
                    if ( iCanSetChannelBitrateResult != XLClass.XLstatus.XL_SUCCESS )  {
                        Close();                    
                        return false;
                    }
                }
            }


		    //-----------------------------------------------------------------
		    // Activate channel
		    //-----------------------------------------------------------------
            {
                XLClass.XLstatus iActivateChannelResult = objXLDriver.XL_ActivateChannel(
                    portHandle, 
                    accessMask, 
                    (uint)busType, 
                    flags
                ); 
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Open() XL_ActivateChannel() = " + iActivateChannelResult.ToString(), 0 );        
                if ( iActivateChannelResult != XLClass.XLstatus.XL_SUCCESS ) return false;
            }

            //-----------------------------------------------------------------
            // Get RX event handle
            //-----------------------------------------------------------------
            {
                XLClass.XLstatus iResult = objXLDriver.XL_SetNotification( portHandle, ref eventHandle, 1 );
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Init() XL_SetNotification() = " + iResult.ToString(), 0 );

                // run Rx Thread
                trdRx = new Thread( new ThreadStart(RXThread) );
                trdRx.Start();
            }
 
		    //-----------------------------------------------------------------
		    // Reset clock
		    //-----------------------------------------------------------------
            {
                XLClass.XLstatus iResetClockResult = objXLDriver.XL_ResetClock(
                    portHandle
                ); 
                if ( debugMode ) clsDebugTextbox.OutputInfo( "Open() XL_ResetClock() = " + iResetClockResult.ToString(), 0 );                
                if ( iResetClockResult != XLClass.XLstatus.XL_SUCCESS ) return false;
            }

            //
            /*if ( debugMode ) {                
                clsDebugTextbox.OutputInfo( "Open() XL_OpenPort() = " + iOpenPortResult.ToString(), 0 );
                clsDebugTextbox.OutputInfo( "Open() XL_ActivateChannel() = " + iActivateChannelResult.ToString(), 0 );                
                clsDebugTextbox.OutputInfo( "Open() XL_ResetClock() = " + iResetClockResult.ToString(), 0 );                
                clsDebugTextbox.OutputInfo( "\tAccess mask: " + accessMask.ToString(), 0 );
                clsDebugTextbox.OutputInfo( "\tPermission mask: " + permissionMask.ToString(), 0 );
                clsDebugTextbox.OutputInfo( "\tPort handle: " + portHandle.ToString(), 0 );
            }*/

            //
            bIsOpen = true;
            return ( bIsOpen );    
        }// Open()

						
		//---------------------------------------------------------------------
		// OpenWindow()
		//---------------------------------------------------------------------	
		public void OpenWindow( System.Windows.Forms.Form pwndOwner ) 
		{
		    frmds30LoaderPortVector wndSettings = new frmds30LoaderPortVector( this, objXLDriver, iChannelIndex );
            wndSettings.ShowDialog( pwndOwner );
		}// OpenWindow()
		
				
		//---------------------------------------------------------------------
		// ReadByte()
		//---------------------------------------------------------------------	
		public bool ReadByte(ref int iByte) 
		{	
            if ( inBufferCount < 1 ) return false;
            iByte = (byte)queRx.Dequeue();
            ++iBytesReceived;
			return true;		
		}// ReadByte()	
		
						
		//---------------------------------------------------------------------
		// ReadBytes()
		//---------------------------------------------------------------------	
		public bool ReadBytes( ref byte []iBytes, int iCount ) 
		{
            if ( inBufferCount < iCount ) return false;

		    for ( int iIter = 0; iIter < iCount; iIter++ ) {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
		}// ReadBytes()
        
        
        //---------------------------------------------------------------------
		// ReadBytes()
		//---------------------------------------------------------------------	
		public bool ReadBytes( ref int []iBytes, int iCount ) 
		{
            if ( inBufferCount < iCount ) return false;

		    for ( int iIter = 0; iIter < iCount; iIter++ ) {
                iBytes[iIter] = (byte)queRx.Dequeue();
            }
            iBytesReceived += iCount;
            return true;
		}// ReadBytes()
		
						
		//---------------------------------------------------------------------
		// ReadInt16()
		//---------------------------------------------------------------------	
		public bool ReadInt16( ref int iInteger ) 
		{
            if ( inBufferCount < 2 ) return false;
            iInteger = (byte)queRx.Dequeue() + (((byte)queRx.Dequeue())<<8);
            iBytesReceived += 2;
			return true;	
		}// ReadInt16()
	  		
						
		//---------------------------------------------------------------------
		// ReadText()
		//---------------------------------------------------------------------	
		public string ReadText( ref bool pbResult ) 
		{
			pbResult = false;
            
            int iCount = inBufferCount;
            
            if ( inBufferCount == 0 ) {                
                return string.Empty;
            }
            
            byte[] bBytes = new byte[ iCount ];
            if ( ReadBytes(ref bBytes, iCount) == false ) {
                return string.Empty;                
            }

            pbResult = true;
            System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
            return enc.GetString( bBytes );
		}// ReadText()


        //---------------------------------------------------------------------
        // RXThread()
        //---------------------------------------------------------------------		
        public void RXThread() 
        {
            XLClass.xl_event   receivedEvent   = new XLClass.xl_event();            // create new object containing received data       
            XLClass.XLstatus   xlStatus        = XLClass.XLstatus.XL_SUCCESS;       // result of XL driver func. calls
            WaitResults        waitResult      = new WaitResults();                 // result values of WaitForSingleObject          

            // note: this thread is destroyed by MAIN
            while (true) {    
                // wait for hardware events
                waitResult = (WaitResults) WaitForSingleObject( eventHandle, 1000 ); 
                
                // if event occured...
                if ( waitResult !=  WaitResults.WAIT_TIMEOUT) {    
                    // ...init xlStatus first
                    xlStatus = XLClass.XLstatus.XL_SUCCESS;
          
                    // afterwards: while hw queue is not empty...
                    while ( xlStatus != XLClass.XLstatus.XL_ERR_QUEUE_IS_EMPTY ) {
                        // ...reveice data from hardware...
                        xlStatus =  objXLDriver.XL_Receive( portHandle, ref receivedEvent );     
                        
                        //  if receiving succeed....
                        if ( xlStatus == XLClass.XLstatus.XL_SUCCESS ) {
                            //if ( debugMode ) clsDebugTextbox.OutputInfo( "RXThread() XL_Receive() = " + xlStatus.ToString(), 0 );

                            // ...and data was Rx msg...
                            if ( receivedEvent.tag ==  (byte) XLClass.XLeventType.XL_RECEIVE_MSG)  {       
                                // ...check various flags
                                if (
                                    (receivedEvent.tagData.can_Msg.flags & (ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_ERROR_FRAME)
                                    == (ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_ERROR_FRAME
                                 ) {
                                    if ( debugMode ) clsDebugTextbox.OutputInfo( "ERROR FRAME", 0 );

                                } else if ((receivedEvent.tagData.can_Msg.flags & (ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_REMOTE_FRAME)
                                    == (ushort) XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_REMOTE_FRAME
                                ) {
                                    if ( debugMode ) clsDebugTextbox.OutputInfo( "REMOTE FRAME", 0 );

                                } else if( // filter various messages
                                    ((receivedEvent.tagData.can_Msg.flags & (ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_OVERRUN)        == 0) &&
                                    ((receivedEvent.tagData.can_Msg.flags & (ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_NERR)           == 0) &&
                                    ((receivedEvent.tagData.can_Msg.flags & (ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_TX_COMPLETED)   == 0) &&
                                    ((receivedEvent.tagData.can_Msg.flags & (ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_TX_REQUEST)     == 0)
                                ) {
                                    // Store received data in rx queue
                                    for ( int iIter = 0; iIter < receivedEvent.tagData.can_Msg.dlc; iIter++ ) {
                                        queRx.Enqueue( receivedEvent.tagData.can_Msg.data[iIter] );
                                    }
                                    if ( debugMode ) clsDebugTextbox.OutputInfo( objXLDriver.XL_GetEventString(receivedEvent), 0);
                                    OnDataReceived();
                                }
                            }  
                        }
                    }
                }
                // no event occured
            }
        }// RXThread()
      

        //-------------------------------------------------------------------------
		// SaveSettings()
		// Description: 
		//-------------------------------------------------------------------------
		public void SaveSettings( clsSettingsPortVector pobjSettings)
		{	            
            clsSettingsPortVector objSettings = new clsSettingsPortVector();

            //-----------------------------------------------------------------
			// Filename
            //-----------------------------------------------------------------			
            string strPath = Application.StartupPath;
			string strFilename = strPath + Path.DirectorySeparatorChar + "settingsPortVector.xml";
 
            
            //-----------------------------------------------------------------
            // Serialize
            //-----------------------------------------------------------------           
            XmlSerializer xmlSerializer = new XmlSerializer( typeof(clsSettingsPortVector) );
            TextWriter textWriter = new StreamWriter( strFilename );
            xmlSerializer.Serialize( textWriter, pobjSettings );
            textWriter.Close();
		}//SaveSettings()    


        //---------------------------------------------------------------------
        // SendByte()
        //---------------------------------------------------------------------		
        public bool SendByte( byte bByte )
        {
            XLClass.xl_event xlEvent = new XLClass.xl_event();

            xlEvent.tagData.can_Msg.id         = remoteID; 
            xlEvent.tagData.can_Msg.dlc        = 1;
            xlEvent.tagData.can_Msg.data[0]    = bByte;
            xlEvent.tag = (byte) XLClass.XLeventType.XL_TRANSMIT_MSG;

            XLClass.XLstatus iCanTransmitResult = objXLDriver.XL_CanTransmit( portHandle, txMask, xlEvent );
            if ( debugMode ) clsDebugTextbox.OutputInfo( "SendByte() XL_CanTransmit() = " + iCanTransmitResult.ToString(), 0 );

            ++iBytesSent;
            return (iCanTransmitResult == XLClass.XLstatus.XL_SUCCESS);
        }// SendByte()


		//---------------------------------------------------------------------
		// SendByte()
		//---------------------------------------------------------------------	
		public bool SendByte( int iByte ) 
		{
			return SendByte( Convert.ToByte(iByte) );
		}// SendByte()	


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes( ref byte[] bBytes, int iOffset, int iCount )
        {
            return SendBytes( ref bBytes, iOffset, iCount, txDlc );
        }// SendBytes()


        //---------------------------------------------------------------------
        // SendBytes()
        //---------------------------------------------------------------------	
        public bool SendBytes(ref byte[] bBytes, int iOffset, int iCount, int iDlc)
        {
            int iBytesLeft = iCount;
            int iBytesToSend;
            int iIter;
            int iSentBytes=0;
            //int iStart;
            XLClass.xl_event xlEvent = null;
            XLClass.XLstatus iCanTransmitResult;
            bool bAllOk = true;

            while ( iBytesLeft > 0 ) {
                iBytesToSend = Math.Min(iBytesLeft, iDlc);

                xlEvent = new XLClass.xl_event();
                xlEvent.tagData.can_Msg.id         = remoteID ; 
                xlEvent.tagData.can_Msg.dlc        = (ushort)iBytesToSend;
                for ( iIter = 0; iIter < iBytesToSend; iIter++ ) {
                    xlEvent.tagData.can_Msg.data[iIter] = bBytes[iSentBytes+iIter];
                }
                
                xlEvent.tag = (byte) XLClass.XLeventType.XL_TRANSMIT_MSG;

                iCanTransmitResult = objXLDriver.XL_CanTransmit( portHandle, txMask, xlEvent );
                if ( debugMode ) clsDebugTextbox.OutputInfo( "SendBytes() XL_CanTransmit() = " + iCanTransmitResult.ToString(), 0 );
                
                // Wait for packet to be sent
                /*iStart = Environment.TickCount;
                while ( 
                    Environment.TickCount - iStart < 20 &&                     
                    (xlEvent.tagData.can_Msg.flags & ((ushort)XLClass.XLmessageFlags.XL_CAN_MSG_FLAG_TX_COMPLETED)) == 0
                );*/                
                
                iSentBytes += iBytesToSend;
                iBytesLeft -= iBytesToSend;
                
                bAllOk &= (iCanTransmitResult == XLClass.XLstatus.XL_SUCCESS);
            }
            iBytesSent += iCount;
            return bAllOk;
        }// SendBytes()
		

		//---------------------------------------------------------------------
		// SendBytes()
		//---------------------------------------------------------------------	
		public bool SendBytes( ref int[] iBytes, int iOffset, int iCount ) 
		{
			byte [] bBytes = new byte [ iCount ];
			for ( int iIter = 0; iIter < iCount; iIter++ ) {
				bBytes[ iIter ] = (byte)iBytes[ iIter ];
			}
			
			return SendBytes( ref bBytes, 0, iCount );
		}// SendBytes()		
							
						
		//---------------------------------------------------------------------
		// SendText()
		//---------------------------------------------------------------------	
		public bool SendText( string pstrText ) 
		{
            char[] characters = pstrText.ToCharArray();
            byte[] bBytes = new byte[characters.Length];
            
            for ( int iIter = 0; iIter < characters.Length; iIter++ ) {
                bBytes[iIter] = Convert.ToByte( characters[iIter] );
            }

            return SendBytes( ref bBytes, 0, bBytes.Length );
		}// SendText()
	

		//---------------------------------------------------------------------
		// Setup()
		//---------------------------------------------------------------------	
		public void Setup( string pstrPortname, int piBaudrate ) 
		{
            portName = pstrPortname;
            baudrate = piBaudrate;           
		}// Setup()	

	}// Class: clsds30LoaderPortVector
}
