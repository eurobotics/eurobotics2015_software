#ifndef _AX12_CONFIG_H_
#define _AX12_CONFIG_H_

#define AX12_MAX_PARAMS 32


#endif/*_AX12_CONFIG_H_*/
